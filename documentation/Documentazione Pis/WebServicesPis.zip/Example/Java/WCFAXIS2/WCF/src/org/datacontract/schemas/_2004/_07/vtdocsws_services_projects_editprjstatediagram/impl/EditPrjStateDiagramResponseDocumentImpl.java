/*
 * An XML document type.
 * Localname: EditPrjStateDiagramResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.EditPrjStateDiagram
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.impl;
/**
 * A document containing one EditPrjStateDiagramResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.EditPrjStateDiagram) element.
 *
 * This is a complex type.
 */
public class EditPrjStateDiagramResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramResponseDocument
{
    
    public EditPrjStateDiagramResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EDITPRJSTATEDIAGRAMRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.EditPrjStateDiagram", "EditPrjStateDiagramResponse");
    
    
    /**
     * Gets the "EditPrjStateDiagramResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramResponse getEditPrjStateDiagramResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramResponse)get_store().find_element_user(EDITPRJSTATEDIAGRAMRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "EditPrjStateDiagramResponse" element
     */
    public boolean isNilEditPrjStateDiagramResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramResponse)get_store().find_element_user(EDITPRJSTATEDIAGRAMRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "EditPrjStateDiagramResponse" element
     */
    public void setEditPrjStateDiagramResponse(org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramResponse editPrjStateDiagramResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramResponse)get_store().find_element_user(EDITPRJSTATEDIAGRAMRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramResponse)get_store().add_element_user(EDITPRJSTATEDIAGRAMRESPONSE$0);
            }
            target.set(editPrjStateDiagramResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "EditPrjStateDiagramResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramResponse addNewEditPrjStateDiagramResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramResponse)get_store().add_element_user(EDITPRJSTATEDIAGRAMRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "EditPrjStateDiagramResponse" element
     */
    public void setNilEditPrjStateDiagramResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramResponse)get_store().find_element_user(EDITPRJSTATEDIAGRAMRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramResponse)get_store().add_element_user(EDITPRJSTATEDIAGRAMRESPONSE$0);
            }
            target.setNil();
        }
    }
}
