/*
 * An XML document type.
 * Localname: EditProjectResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.EditProject
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.impl;
/**
 * A document containing one EditProjectResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.EditProject) element.
 *
 * This is a complex type.
 */
public class EditProjectResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectResponseDocument
{
    
    public EditProjectResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EDITPROJECTRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.EditProject", "EditProjectResponse");
    
    
    /**
     * Gets the "EditProjectResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectResponse getEditProjectResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectResponse)get_store().find_element_user(EDITPROJECTRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "EditProjectResponse" element
     */
    public boolean isNilEditProjectResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectResponse)get_store().find_element_user(EDITPROJECTRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "EditProjectResponse" element
     */
    public void setEditProjectResponse(org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectResponse editProjectResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectResponse)get_store().find_element_user(EDITPROJECTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectResponse)get_store().add_element_user(EDITPROJECTRESPONSE$0);
            }
            target.set(editProjectResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "EditProjectResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectResponse addNewEditProjectResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectResponse)get_store().add_element_user(EDITPROJECTRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "EditProjectResponse" element
     */
    public void setNilEditProjectResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectResponse)get_store().find_element_user(EDITPROJECTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectResponse)get_store().add_element_user(EDITPROJECTRESPONSE$0);
            }
            target.setNil();
        }
    }
}
