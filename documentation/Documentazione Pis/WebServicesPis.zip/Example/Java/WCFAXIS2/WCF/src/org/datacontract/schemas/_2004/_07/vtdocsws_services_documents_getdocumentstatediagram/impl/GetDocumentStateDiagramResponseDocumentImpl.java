/*
 * An XML document type.
 * Localname: GetDocumentStateDiagramResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetDocumentStateDiagram
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.impl;
/**
 * A document containing one GetDocumentStateDiagramResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetDocumentStateDiagram) element.
 *
 * This is a complex type.
 */
public class GetDocumentStateDiagramResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramResponseDocument
{
    
    public GetDocumentStateDiagramResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETDOCUMENTSTATEDIAGRAMRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetDocumentStateDiagram", "GetDocumentStateDiagramResponse");
    
    
    /**
     * Gets the "GetDocumentStateDiagramResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramResponse getGetDocumentStateDiagramResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramResponse)get_store().find_element_user(GETDOCUMENTSTATEDIAGRAMRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetDocumentStateDiagramResponse" element
     */
    public boolean isNilGetDocumentStateDiagramResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramResponse)get_store().find_element_user(GETDOCUMENTSTATEDIAGRAMRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetDocumentStateDiagramResponse" element
     */
    public void setGetDocumentStateDiagramResponse(org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramResponse getDocumentStateDiagramResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramResponse)get_store().find_element_user(GETDOCUMENTSTATEDIAGRAMRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramResponse)get_store().add_element_user(GETDOCUMENTSTATEDIAGRAMRESPONSE$0);
            }
            target.set(getDocumentStateDiagramResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "GetDocumentStateDiagramResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramResponse addNewGetDocumentStateDiagramResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramResponse)get_store().add_element_user(GETDOCUMENTSTATEDIAGRAMRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetDocumentStateDiagramResponse" element
     */
    public void setNilGetDocumentStateDiagramResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramResponse)get_store().find_element_user(GETDOCUMENTSTATEDIAGRAMRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramResponse)get_store().add_element_user(GETDOCUMENTSTATEDIAGRAMRESPONSE$0);
            }
            target.setNil();
        }
    }
}
