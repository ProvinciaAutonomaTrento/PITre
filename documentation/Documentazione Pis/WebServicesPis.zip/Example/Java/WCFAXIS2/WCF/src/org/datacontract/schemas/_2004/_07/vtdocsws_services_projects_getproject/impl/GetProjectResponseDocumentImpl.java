/*
 * An XML document type.
 * Localname: GetProjectResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProject
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.impl;
/**
 * A document containing one GetProjectResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProject) element.
 *
 * This is a complex type.
 */
public class GetProjectResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectResponseDocument
{
    
    public GetProjectResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETPROJECTRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProject", "GetProjectResponse");
    
    
    /**
     * Gets the "GetProjectResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectResponse getGetProjectResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectResponse)get_store().find_element_user(GETPROJECTRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetProjectResponse" element
     */
    public boolean isNilGetProjectResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectResponse)get_store().find_element_user(GETPROJECTRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetProjectResponse" element
     */
    public void setGetProjectResponse(org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectResponse getProjectResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectResponse)get_store().find_element_user(GETPROJECTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectResponse)get_store().add_element_user(GETPROJECTRESPONSE$0);
            }
            target.set(getProjectResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "GetProjectResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectResponse addNewGetProjectResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectResponse)get_store().add_element_user(GETPROJECTRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetProjectResponse" element
     */
    public void setNilGetProjectResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectResponse)get_store().find_element_user(GETPROJECTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectResponse)get_store().add_element_user(GETPROJECTRESPONSE$0);
            }
            target.setNil();
        }
    }
}
