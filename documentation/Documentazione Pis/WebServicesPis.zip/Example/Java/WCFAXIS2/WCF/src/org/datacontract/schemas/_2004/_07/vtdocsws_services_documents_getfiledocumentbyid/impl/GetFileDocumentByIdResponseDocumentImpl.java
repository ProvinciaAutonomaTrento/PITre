/*
 * An XML document type.
 * Localname: GetFileDocumentByIdResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetFileDocumentById
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfiledocumentbyid.GetFileDocumentByIdResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfiledocumentbyid.impl;
/**
 * A document containing one GetFileDocumentByIdResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetFileDocumentById) element.
 *
 * This is a complex type.
 */
public class GetFileDocumentByIdResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfiledocumentbyid.GetFileDocumentByIdResponseDocument
{
    
    public GetFileDocumentByIdResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFILEDOCUMENTBYIDRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetFileDocumentById", "GetFileDocumentByIdResponse");
    
    
    /**
     * Gets the "GetFileDocumentByIdResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfiledocumentbyid.GetFileDocumentByIdResponse getGetFileDocumentByIdResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfiledocumentbyid.GetFileDocumentByIdResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfiledocumentbyid.GetFileDocumentByIdResponse)get_store().find_element_user(GETFILEDOCUMENTBYIDRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetFileDocumentByIdResponse" element
     */
    public boolean isNilGetFileDocumentByIdResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfiledocumentbyid.GetFileDocumentByIdResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfiledocumentbyid.GetFileDocumentByIdResponse)get_store().find_element_user(GETFILEDOCUMENTBYIDRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetFileDocumentByIdResponse" element
     */
    public void setGetFileDocumentByIdResponse(org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfiledocumentbyid.GetFileDocumentByIdResponse getFileDocumentByIdResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfiledocumentbyid.GetFileDocumentByIdResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfiledocumentbyid.GetFileDocumentByIdResponse)get_store().find_element_user(GETFILEDOCUMENTBYIDRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfiledocumentbyid.GetFileDocumentByIdResponse)get_store().add_element_user(GETFILEDOCUMENTBYIDRESPONSE$0);
            }
            target.set(getFileDocumentByIdResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "GetFileDocumentByIdResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfiledocumentbyid.GetFileDocumentByIdResponse addNewGetFileDocumentByIdResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfiledocumentbyid.GetFileDocumentByIdResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfiledocumentbyid.GetFileDocumentByIdResponse)get_store().add_element_user(GETFILEDOCUMENTBYIDRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetFileDocumentByIdResponse" element
     */
    public void setNilGetFileDocumentByIdResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfiledocumentbyid.GetFileDocumentByIdResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfiledocumentbyid.GetFileDocumentByIdResponse)get_store().find_element_user(GETFILEDOCUMENTBYIDRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfiledocumentbyid.GetFileDocumentByIdResponse)get_store().add_element_user(GETFILEDOCUMENTBYIDRESPONSE$0);
            }
            target.setNil();
        }
    }
}
