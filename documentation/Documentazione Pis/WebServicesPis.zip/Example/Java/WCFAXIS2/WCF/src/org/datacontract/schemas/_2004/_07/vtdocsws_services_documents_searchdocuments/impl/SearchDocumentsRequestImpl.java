/*
 * XML Type:  SearchDocumentsRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.SearchDocuments
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsRequest
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.impl;
/**
 * An XML SearchDocumentsRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.SearchDocuments).
 *
 * This is a complex type.
 */
public class SearchDocumentsRequestImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.RequestImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsRequest
{
    
    public SearchDocumentsRequestImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ELEMENTSINPAGE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.SearchDocuments", "ElementsInPage");
    private static final javax.xml.namespace.QName FILTERS$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.SearchDocuments", "Filters");
    private static final javax.xml.namespace.QName PAGENUMBER$4 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.SearchDocuments", "PageNumber");
    
    
    /**
     * Gets the "ElementsInPage" element
     */
    public java.lang.String getElementsInPage()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ELEMENTSINPAGE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "ElementsInPage" element
     */
    public org.apache.xmlbeans.XmlString xgetElementsInPage()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ELEMENTSINPAGE$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "ElementsInPage" element
     */
    public boolean isNilElementsInPage()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ELEMENTSINPAGE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ElementsInPage" element
     */
    public boolean isSetElementsInPage()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ELEMENTSINPAGE$0) != 0;
        }
    }
    
    /**
     * Sets the "ElementsInPage" element
     */
    public void setElementsInPage(java.lang.String elementsInPage)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ELEMENTSINPAGE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ELEMENTSINPAGE$0);
            }
            target.setStringValue(elementsInPage);
        }
    }
    
    /**
     * Sets (as xml) the "ElementsInPage" element
     */
    public void xsetElementsInPage(org.apache.xmlbeans.XmlString elementsInPage)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ELEMENTSINPAGE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ELEMENTSINPAGE$0);
            }
            target.set(elementsInPage);
        }
    }
    
    /**
     * Nils the "ElementsInPage" element
     */
    public void setNilElementsInPage()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ELEMENTSINPAGE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ELEMENTSINPAGE$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ElementsInPage" element
     */
    public void unsetElementsInPage()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ELEMENTSINPAGE$0, 0);
        }
    }
    
    /**
     * Gets the "Filters" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter getFilters()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter)get_store().find_element_user(FILTERS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Filters" element
     */
    public boolean isNilFilters()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter)get_store().find_element_user(FILTERS$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Filters" element
     */
    public boolean isSetFilters()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FILTERS$2) != 0;
        }
    }
    
    /**
     * Sets the "Filters" element
     */
    public void setFilters(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter filters)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter)get_store().find_element_user(FILTERS$2, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter)get_store().add_element_user(FILTERS$2);
            }
            target.set(filters);
        }
    }
    
    /**
     * Appends and returns a new empty "Filters" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter addNewFilters()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter)get_store().add_element_user(FILTERS$2);
            return target;
        }
    }
    
    /**
     * Nils the "Filters" element
     */
    public void setNilFilters()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter)get_store().find_element_user(FILTERS$2, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter)get_store().add_element_user(FILTERS$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Filters" element
     */
    public void unsetFilters()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FILTERS$2, 0);
        }
    }
    
    /**
     * Gets the "PageNumber" element
     */
    public java.lang.String getPageNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PAGENUMBER$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "PageNumber" element
     */
    public org.apache.xmlbeans.XmlString xgetPageNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PAGENUMBER$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "PageNumber" element
     */
    public boolean isNilPageNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PAGENUMBER$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "PageNumber" element
     */
    public boolean isSetPageNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PAGENUMBER$4) != 0;
        }
    }
    
    /**
     * Sets the "PageNumber" element
     */
    public void setPageNumber(java.lang.String pageNumber)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PAGENUMBER$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PAGENUMBER$4);
            }
            target.setStringValue(pageNumber);
        }
    }
    
    /**
     * Sets (as xml) the "PageNumber" element
     */
    public void xsetPageNumber(org.apache.xmlbeans.XmlString pageNumber)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PAGENUMBER$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PAGENUMBER$4);
            }
            target.set(pageNumber);
        }
    }
    
    /**
     * Nils the "PageNumber" element
     */
    public void setNilPageNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PAGENUMBER$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PAGENUMBER$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "PageNumber" element
     */
    public void unsetPageNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PAGENUMBER$4, 0);
        }
    }
}
