/*
 * An XML document type.
 * Localname: GetFileWithSignatureOrStampResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetFileWithSignatureOrStamp
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.impl;
/**
 * A document containing one GetFileWithSignatureOrStampResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetFileWithSignatureOrStamp) element.
 *
 * This is a complex type.
 */
public class GetFileWithSignatureOrStampResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampResponseDocument
{
    
    public GetFileWithSignatureOrStampResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFILEWITHSIGNATUREORSTAMPRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetFileWithSignatureOrStamp", "GetFileWithSignatureOrStampResponse");
    
    
    /**
     * Gets the "GetFileWithSignatureOrStampResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampResponse getGetFileWithSignatureOrStampResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampResponse)get_store().find_element_user(GETFILEWITHSIGNATUREORSTAMPRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetFileWithSignatureOrStampResponse" element
     */
    public boolean isNilGetFileWithSignatureOrStampResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampResponse)get_store().find_element_user(GETFILEWITHSIGNATUREORSTAMPRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetFileWithSignatureOrStampResponse" element
     */
    public void setGetFileWithSignatureOrStampResponse(org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampResponse getFileWithSignatureOrStampResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampResponse)get_store().find_element_user(GETFILEWITHSIGNATUREORSTAMPRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampResponse)get_store().add_element_user(GETFILEWITHSIGNATUREORSTAMPRESPONSE$0);
            }
            target.set(getFileWithSignatureOrStampResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "GetFileWithSignatureOrStampResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampResponse addNewGetFileWithSignatureOrStampResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampResponse)get_store().add_element_user(GETFILEWITHSIGNATUREORSTAMPRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetFileWithSignatureOrStampResponse" element
     */
    public void setNilGetFileWithSignatureOrStampResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampResponse)get_store().find_element_user(GETFILEWITHSIGNATUREORSTAMPRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampResponse)get_store().add_element_user(GETFILEWITHSIGNATUREORSTAMPRESPONSE$0);
            }
            target.setNil();
        }
    }
}
