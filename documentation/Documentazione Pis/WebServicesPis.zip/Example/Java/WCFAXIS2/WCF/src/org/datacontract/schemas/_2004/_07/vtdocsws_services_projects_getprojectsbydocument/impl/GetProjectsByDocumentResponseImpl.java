/*
 * XML Type:  GetProjectsByDocumentResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProjectsByDocument
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentResponse
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.impl;
/**
 * An XML GetProjectsByDocumentResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProjectsByDocument).
 *
 * This is a complex type.
 */
public class GetProjectsByDocumentResponseImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.ResponseImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentResponse
{
    
    public GetProjectsByDocumentResponseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PROJECTS$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProjectsByDocument", "Projects");
    
    
    /**
     * Gets the "Projects" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject getProjects()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject)get_store().find_element_user(PROJECTS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Projects" element
     */
    public boolean isNilProjects()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject)get_store().find_element_user(PROJECTS$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Projects" element
     */
    public boolean isSetProjects()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROJECTS$0) != 0;
        }
    }
    
    /**
     * Sets the "Projects" element
     */
    public void setProjects(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject projects)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject)get_store().find_element_user(PROJECTS$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject)get_store().add_element_user(PROJECTS$0);
            }
            target.set(projects);
        }
    }
    
    /**
     * Appends and returns a new empty "Projects" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject addNewProjects()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject)get_store().add_element_user(PROJECTS$0);
            return target;
        }
    }
    
    /**
     * Nils the "Projects" element
     */
    public void setNilProjects()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject)get_store().find_element_user(PROJECTS$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject)get_store().add_element_user(PROJECTS$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Projects" element
     */
    public void unsetProjects()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROJECTS$0, 0);
        }
    }
}
