/*
 * XML Type:  ArrayOfTemplate
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfTemplate
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * An XML ArrayOfTemplate(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain).
 *
 * This is a complex type.
 */
public class ArrayOfTemplateImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfTemplate
{
    
    public ArrayOfTemplateImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TEMPLATE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Template");
    
    
    /**
     * Gets array of all "Template" elements
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Template[] getTemplateArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(TEMPLATE$0, targetList);
            org.datacontract.schemas._2004._07.vtdocsws_domain.Template[] result = new org.datacontract.schemas._2004._07.vtdocsws_domain.Template[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "Template" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Template getTemplateArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Template target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().find_element_user(TEMPLATE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Tests for nil ith "Template" element
     */
    public boolean isNilTemplateArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Template target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().find_element_user(TEMPLATE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "Template" element
     */
    public int sizeOfTemplateArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TEMPLATE$0);
        }
    }
    
    /**
     * Sets array of all "Template" element
     */
    public void setTemplateArray(org.datacontract.schemas._2004._07.vtdocsws_domain.Template[] templateArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(templateArray, TEMPLATE$0);
        }
    }
    
    /**
     * Sets ith "Template" element
     */
    public void setTemplateArray(int i, org.datacontract.schemas._2004._07.vtdocsws_domain.Template template)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Template target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().find_element_user(TEMPLATE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(template);
        }
    }
    
    /**
     * Nils the ith "Template" element
     */
    public void setNilTemplateArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Template target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().find_element_user(TEMPLATE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "Template" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Template insertNewTemplate(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Template target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().insert_element_user(TEMPLATE$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "Template" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Template addNewTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Template target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().add_element_user(TEMPLATE$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "Template" element
     */
    public void removeTemplate(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TEMPLATE$0, i);
        }
    }
}
