/*
 * XML Type:  Project
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.Project
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * An XML Project(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain).
 *
 * This is a complex type.
 */
public class ProjectImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.Project
{
    
    public ProjectImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CLASSIFICATIONSCHEME$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "ClassificationScheme");
    private static final javax.xml.namespace.QName CLOSUREDATE$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "ClosureDate");
    private static final javax.xml.namespace.QName CODE$4 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Code");
    private static final javax.xml.namespace.QName CODENODECLASSIFICATION$6 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "CodeNodeClassification");
    private static final javax.xml.namespace.QName COLLOCATIONDATE$8 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "CollocationDate");
    private static final javax.xml.namespace.QName CONTROLLED$10 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Controlled");
    private static final javax.xml.namespace.QName CREATIONDATE$12 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "CreationDate");
    private static final javax.xml.namespace.QName DESCRIPTION$14 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Description");
    private static final javax.xml.namespace.QName ID$16 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Id");
    private static final javax.xml.namespace.QName IDPARENT$18 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "IdParent");
    private static final javax.xml.namespace.QName NOTE$20 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Note");
    private static final javax.xml.namespace.QName NUMBER$22 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Number");
    private static final javax.xml.namespace.QName OPEN$24 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Open");
    private static final javax.xml.namespace.QName PAPER$26 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Paper");
    private static final javax.xml.namespace.QName PHYSICSCOLLOCATION$28 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "PhysicsCollocation");
    private static final javax.xml.namespace.QName PRIVATE$30 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Private");
    private static final javax.xml.namespace.QName REGISTER$32 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Register");
    private static final javax.xml.namespace.QName TEMPLATE$34 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Template");
    private static final javax.xml.namespace.QName TYPE$36 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Type");
    
    
    /**
     * Gets the "ClassificationScheme" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme getClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().find_element_user(CLASSIFICATIONSCHEME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ClassificationScheme" element
     */
    public boolean isNilClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().find_element_user(CLASSIFICATIONSCHEME$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ClassificationScheme" element
     */
    public boolean isSetClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CLASSIFICATIONSCHEME$0) != 0;
        }
    }
    
    /**
     * Sets the "ClassificationScheme" element
     */
    public void setClassificationScheme(org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme classificationScheme)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().find_element_user(CLASSIFICATIONSCHEME$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().add_element_user(CLASSIFICATIONSCHEME$0);
            }
            target.set(classificationScheme);
        }
    }
    
    /**
     * Appends and returns a new empty "ClassificationScheme" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme addNewClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().add_element_user(CLASSIFICATIONSCHEME$0);
            return target;
        }
    }
    
    /**
     * Nils the "ClassificationScheme" element
     */
    public void setNilClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().find_element_user(CLASSIFICATIONSCHEME$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().add_element_user(CLASSIFICATIONSCHEME$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ClassificationScheme" element
     */
    public void unsetClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CLASSIFICATIONSCHEME$0, 0);
        }
    }
    
    /**
     * Gets the "ClosureDate" element
     */
    public java.lang.String getClosureDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CLOSUREDATE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "ClosureDate" element
     */
    public org.apache.xmlbeans.XmlString xgetClosureDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CLOSUREDATE$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "ClosureDate" element
     */
    public boolean isNilClosureDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CLOSUREDATE$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ClosureDate" element
     */
    public boolean isSetClosureDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CLOSUREDATE$2) != 0;
        }
    }
    
    /**
     * Sets the "ClosureDate" element
     */
    public void setClosureDate(java.lang.String closureDate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CLOSUREDATE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CLOSUREDATE$2);
            }
            target.setStringValue(closureDate);
        }
    }
    
    /**
     * Sets (as xml) the "ClosureDate" element
     */
    public void xsetClosureDate(org.apache.xmlbeans.XmlString closureDate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CLOSUREDATE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CLOSUREDATE$2);
            }
            target.set(closureDate);
        }
    }
    
    /**
     * Nils the "ClosureDate" element
     */
    public void setNilClosureDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CLOSUREDATE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CLOSUREDATE$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ClosureDate" element
     */
    public void unsetClosureDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CLOSUREDATE$2, 0);
        }
    }
    
    /**
     * Gets the "Code" element
     */
    public java.lang.String getCode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODE$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Code" element
     */
    public org.apache.xmlbeans.XmlString xgetCode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODE$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Code" element
     */
    public boolean isNilCode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODE$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Code" element
     */
    public boolean isSetCode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODE$4) != 0;
        }
    }
    
    /**
     * Sets the "Code" element
     */
    public void setCode(java.lang.String code)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODE$4);
            }
            target.setStringValue(code);
        }
    }
    
    /**
     * Sets (as xml) the "Code" element
     */
    public void xsetCode(org.apache.xmlbeans.XmlString code)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODE$4);
            }
            target.set(code);
        }
    }
    
    /**
     * Nils the "Code" element
     */
    public void setNilCode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODE$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Code" element
     */
    public void unsetCode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODE$4, 0);
        }
    }
    
    /**
     * Gets the "CodeNodeClassification" element
     */
    public java.lang.String getCodeNodeClassification()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODENODECLASSIFICATION$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodeNodeClassification" element
     */
    public org.apache.xmlbeans.XmlString xgetCodeNodeClassification()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODENODECLASSIFICATION$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CodeNodeClassification" element
     */
    public boolean isNilCodeNodeClassification()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODENODECLASSIFICATION$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CodeNodeClassification" element
     */
    public boolean isSetCodeNodeClassification()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODENODECLASSIFICATION$6) != 0;
        }
    }
    
    /**
     * Sets the "CodeNodeClassification" element
     */
    public void setCodeNodeClassification(java.lang.String codeNodeClassification)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODENODECLASSIFICATION$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODENODECLASSIFICATION$6);
            }
            target.setStringValue(codeNodeClassification);
        }
    }
    
    /**
     * Sets (as xml) the "CodeNodeClassification" element
     */
    public void xsetCodeNodeClassification(org.apache.xmlbeans.XmlString codeNodeClassification)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODENODECLASSIFICATION$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODENODECLASSIFICATION$6);
            }
            target.set(codeNodeClassification);
        }
    }
    
    /**
     * Nils the "CodeNodeClassification" element
     */
    public void setNilCodeNodeClassification()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODENODECLASSIFICATION$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODENODECLASSIFICATION$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CodeNodeClassification" element
     */
    public void unsetCodeNodeClassification()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODENODECLASSIFICATION$6, 0);
        }
    }
    
    /**
     * Gets the "CollocationDate" element
     */
    public java.lang.String getCollocationDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(COLLOCATIONDATE$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CollocationDate" element
     */
    public org.apache.xmlbeans.XmlString xgetCollocationDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(COLLOCATIONDATE$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CollocationDate" element
     */
    public boolean isNilCollocationDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(COLLOCATIONDATE$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CollocationDate" element
     */
    public boolean isSetCollocationDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(COLLOCATIONDATE$8) != 0;
        }
    }
    
    /**
     * Sets the "CollocationDate" element
     */
    public void setCollocationDate(java.lang.String collocationDate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(COLLOCATIONDATE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(COLLOCATIONDATE$8);
            }
            target.setStringValue(collocationDate);
        }
    }
    
    /**
     * Sets (as xml) the "CollocationDate" element
     */
    public void xsetCollocationDate(org.apache.xmlbeans.XmlString collocationDate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(COLLOCATIONDATE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(COLLOCATIONDATE$8);
            }
            target.set(collocationDate);
        }
    }
    
    /**
     * Nils the "CollocationDate" element
     */
    public void setNilCollocationDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(COLLOCATIONDATE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(COLLOCATIONDATE$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CollocationDate" element
     */
    public void unsetCollocationDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(COLLOCATIONDATE$8, 0);
        }
    }
    
    /**
     * Gets the "Controlled" element
     */
    public boolean getControlled()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONTROLLED$10, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "Controlled" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetControlled()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(CONTROLLED$10, 0);
            return target;
        }
    }
    
    /**
     * True if has "Controlled" element
     */
    public boolean isSetControlled()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONTROLLED$10) != 0;
        }
    }
    
    /**
     * Sets the "Controlled" element
     */
    public void setControlled(boolean controlled)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONTROLLED$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CONTROLLED$10);
            }
            target.setBooleanValue(controlled);
        }
    }
    
    /**
     * Sets (as xml) the "Controlled" element
     */
    public void xsetControlled(org.apache.xmlbeans.XmlBoolean controlled)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(CONTROLLED$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(CONTROLLED$10);
            }
            target.set(controlled);
        }
    }
    
    /**
     * Unsets the "Controlled" element
     */
    public void unsetControlled()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONTROLLED$10, 0);
        }
    }
    
    /**
     * Gets the "CreationDate" element
     */
    public java.lang.String getCreationDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CREATIONDATE$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CreationDate" element
     */
    public org.apache.xmlbeans.XmlString xgetCreationDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CREATIONDATE$12, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CreationDate" element
     */
    public boolean isNilCreationDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CREATIONDATE$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CreationDate" element
     */
    public boolean isSetCreationDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CREATIONDATE$12) != 0;
        }
    }
    
    /**
     * Sets the "CreationDate" element
     */
    public void setCreationDate(java.lang.String creationDate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CREATIONDATE$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CREATIONDATE$12);
            }
            target.setStringValue(creationDate);
        }
    }
    
    /**
     * Sets (as xml) the "CreationDate" element
     */
    public void xsetCreationDate(org.apache.xmlbeans.XmlString creationDate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CREATIONDATE$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CREATIONDATE$12);
            }
            target.set(creationDate);
        }
    }
    
    /**
     * Nils the "CreationDate" element
     */
    public void setNilCreationDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CREATIONDATE$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CREATIONDATE$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CreationDate" element
     */
    public void unsetCreationDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CREATIONDATE$12, 0);
        }
    }
    
    /**
     * Gets the "Description" element
     */
    public java.lang.String getDescription()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESCRIPTION$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Description" element
     */
    public org.apache.xmlbeans.XmlString xgetDescription()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCRIPTION$14, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Description" element
     */
    public boolean isNilDescription()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCRIPTION$14, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Description" element
     */
    public boolean isSetDescription()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DESCRIPTION$14) != 0;
        }
    }
    
    /**
     * Sets the "Description" element
     */
    public void setDescription(java.lang.String description)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESCRIPTION$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DESCRIPTION$14);
            }
            target.setStringValue(description);
        }
    }
    
    /**
     * Sets (as xml) the "Description" element
     */
    public void xsetDescription(org.apache.xmlbeans.XmlString description)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCRIPTION$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DESCRIPTION$14);
            }
            target.set(description);
        }
    }
    
    /**
     * Nils the "Description" element
     */
    public void setNilDescription()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCRIPTION$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DESCRIPTION$14);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Description" element
     */
    public void unsetDescription()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DESCRIPTION$14, 0);
        }
    }
    
    /**
     * Gets the "Id" element
     */
    public java.lang.String getId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ID$16, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Id" element
     */
    public org.apache.xmlbeans.XmlString xgetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ID$16, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Id" element
     */
    public boolean isNilId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ID$16, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Id" element
     */
    public boolean isSetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ID$16) != 0;
        }
    }
    
    /**
     * Sets the "Id" element
     */
    public void setId(java.lang.String id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ID$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ID$16);
            }
            target.setStringValue(id);
        }
    }
    
    /**
     * Sets (as xml) the "Id" element
     */
    public void xsetId(org.apache.xmlbeans.XmlString id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ID$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ID$16);
            }
            target.set(id);
        }
    }
    
    /**
     * Nils the "Id" element
     */
    public void setNilId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ID$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ID$16);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Id" element
     */
    public void unsetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ID$16, 0);
        }
    }
    
    /**
     * Gets the "IdParent" element
     */
    public java.lang.String getIdParent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDPARENT$18, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "IdParent" element
     */
    public org.apache.xmlbeans.XmlString xgetIdParent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDPARENT$18, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "IdParent" element
     */
    public boolean isNilIdParent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDPARENT$18, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "IdParent" element
     */
    public boolean isSetIdParent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(IDPARENT$18) != 0;
        }
    }
    
    /**
     * Sets the "IdParent" element
     */
    public void setIdParent(java.lang.String idParent)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDPARENT$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(IDPARENT$18);
            }
            target.setStringValue(idParent);
        }
    }
    
    /**
     * Sets (as xml) the "IdParent" element
     */
    public void xsetIdParent(org.apache.xmlbeans.XmlString idParent)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDPARENT$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(IDPARENT$18);
            }
            target.set(idParent);
        }
    }
    
    /**
     * Nils the "IdParent" element
     */
    public void setNilIdParent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDPARENT$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(IDPARENT$18);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "IdParent" element
     */
    public void unsetIdParent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(IDPARENT$18, 0);
        }
    }
    
    /**
     * Gets the "Note" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote getNote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote)get_store().find_element_user(NOTE$20, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Note" element
     */
    public boolean isNilNote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote)get_store().find_element_user(NOTE$20, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Note" element
     */
    public boolean isSetNote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NOTE$20) != 0;
        }
    }
    
    /**
     * Sets the "Note" element
     */
    public void setNote(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote note)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote)get_store().find_element_user(NOTE$20, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote)get_store().add_element_user(NOTE$20);
            }
            target.set(note);
        }
    }
    
    /**
     * Appends and returns a new empty "Note" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote addNewNote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote)get_store().add_element_user(NOTE$20);
            return target;
        }
    }
    
    /**
     * Nils the "Note" element
     */
    public void setNilNote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote)get_store().find_element_user(NOTE$20, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote)get_store().add_element_user(NOTE$20);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Note" element
     */
    public void unsetNote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NOTE$20, 0);
        }
    }
    
    /**
     * Gets the "Number" element
     */
    public java.lang.String getNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMBER$22, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Number" element
     */
    public org.apache.xmlbeans.XmlString xgetNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMBER$22, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Number" element
     */
    public boolean isNilNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMBER$22, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Number" element
     */
    public boolean isSetNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NUMBER$22) != 0;
        }
    }
    
    /**
     * Sets the "Number" element
     */
    public void setNumber(java.lang.String number)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMBER$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMBER$22);
            }
            target.setStringValue(number);
        }
    }
    
    /**
     * Sets (as xml) the "Number" element
     */
    public void xsetNumber(org.apache.xmlbeans.XmlString number)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMBER$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NUMBER$22);
            }
            target.set(number);
        }
    }
    
    /**
     * Nils the "Number" element
     */
    public void setNilNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMBER$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NUMBER$22);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Number" element
     */
    public void unsetNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NUMBER$22, 0);
        }
    }
    
    /**
     * Gets the "Open" element
     */
    public boolean getOpen()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OPEN$24, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "Open" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetOpen()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(OPEN$24, 0);
            return target;
        }
    }
    
    /**
     * True if has "Open" element
     */
    public boolean isSetOpen()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OPEN$24) != 0;
        }
    }
    
    /**
     * Sets the "Open" element
     */
    public void setOpen(boolean open)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OPEN$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OPEN$24);
            }
            target.setBooleanValue(open);
        }
    }
    
    /**
     * Sets (as xml) the "Open" element
     */
    public void xsetOpen(org.apache.xmlbeans.XmlBoolean open)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(OPEN$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(OPEN$24);
            }
            target.set(open);
        }
    }
    
    /**
     * Unsets the "Open" element
     */
    public void unsetOpen()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OPEN$24, 0);
        }
    }
    
    /**
     * Gets the "Paper" element
     */
    public boolean getPaper()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PAPER$26, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "Paper" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetPaper()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(PAPER$26, 0);
            return target;
        }
    }
    
    /**
     * True if has "Paper" element
     */
    public boolean isSetPaper()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PAPER$26) != 0;
        }
    }
    
    /**
     * Sets the "Paper" element
     */
    public void setPaper(boolean paper)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PAPER$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PAPER$26);
            }
            target.setBooleanValue(paper);
        }
    }
    
    /**
     * Sets (as xml) the "Paper" element
     */
    public void xsetPaper(org.apache.xmlbeans.XmlBoolean paper)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(PAPER$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(PAPER$26);
            }
            target.set(paper);
        }
    }
    
    /**
     * Unsets the "Paper" element
     */
    public void unsetPaper()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PAPER$26, 0);
        }
    }
    
    /**
     * Gets the "PhysicsCollocation" element
     */
    public java.lang.String getPhysicsCollocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PHYSICSCOLLOCATION$28, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "PhysicsCollocation" element
     */
    public org.apache.xmlbeans.XmlString xgetPhysicsCollocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PHYSICSCOLLOCATION$28, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "PhysicsCollocation" element
     */
    public boolean isNilPhysicsCollocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PHYSICSCOLLOCATION$28, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "PhysicsCollocation" element
     */
    public boolean isSetPhysicsCollocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PHYSICSCOLLOCATION$28) != 0;
        }
    }
    
    /**
     * Sets the "PhysicsCollocation" element
     */
    public void setPhysicsCollocation(java.lang.String physicsCollocation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PHYSICSCOLLOCATION$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PHYSICSCOLLOCATION$28);
            }
            target.setStringValue(physicsCollocation);
        }
    }
    
    /**
     * Sets (as xml) the "PhysicsCollocation" element
     */
    public void xsetPhysicsCollocation(org.apache.xmlbeans.XmlString physicsCollocation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PHYSICSCOLLOCATION$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PHYSICSCOLLOCATION$28);
            }
            target.set(physicsCollocation);
        }
    }
    
    /**
     * Nils the "PhysicsCollocation" element
     */
    public void setNilPhysicsCollocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PHYSICSCOLLOCATION$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PHYSICSCOLLOCATION$28);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "PhysicsCollocation" element
     */
    public void unsetPhysicsCollocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PHYSICSCOLLOCATION$28, 0);
        }
    }
    
    /**
     * Gets the "Private" element
     */
    public boolean getPrivate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRIVATE$30, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "Private" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetPrivate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(PRIVATE$30, 0);
            return target;
        }
    }
    
    /**
     * True if has "Private" element
     */
    public boolean isSetPrivate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PRIVATE$30) != 0;
        }
    }
    
    /**
     * Sets the "Private" element
     */
    public void setPrivate(boolean xprivate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRIVATE$30, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PRIVATE$30);
            }
            target.setBooleanValue(xprivate);
        }
    }
    
    /**
     * Sets (as xml) the "Private" element
     */
    public void xsetPrivate(org.apache.xmlbeans.XmlBoolean xprivate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(PRIVATE$30, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(PRIVATE$30);
            }
            target.set(xprivate);
        }
    }
    
    /**
     * Unsets the "Private" element
     */
    public void unsetPrivate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PRIVATE$30, 0);
        }
    }
    
    /**
     * Gets the "Register" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Register getRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Register target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().find_element_user(REGISTER$32, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Register" element
     */
    public boolean isNilRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Register target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().find_element_user(REGISTER$32, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Register" element
     */
    public boolean isSetRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(REGISTER$32) != 0;
        }
    }
    
    /**
     * Sets the "Register" element
     */
    public void setRegister(org.datacontract.schemas._2004._07.vtdocsws_domain.Register register)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Register target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().find_element_user(REGISTER$32, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().add_element_user(REGISTER$32);
            }
            target.set(register);
        }
    }
    
    /**
     * Appends and returns a new empty "Register" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Register addNewRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Register target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().add_element_user(REGISTER$32);
            return target;
        }
    }
    
    /**
     * Nils the "Register" element
     */
    public void setNilRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Register target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().find_element_user(REGISTER$32, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().add_element_user(REGISTER$32);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Register" element
     */
    public void unsetRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(REGISTER$32, 0);
        }
    }
    
    /**
     * Gets the "Template" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Template getTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Template target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().find_element_user(TEMPLATE$34, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Template" element
     */
    public boolean isNilTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Template target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().find_element_user(TEMPLATE$34, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Template" element
     */
    public boolean isSetTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TEMPLATE$34) != 0;
        }
    }
    
    /**
     * Sets the "Template" element
     */
    public void setTemplate(org.datacontract.schemas._2004._07.vtdocsws_domain.Template template)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Template target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().find_element_user(TEMPLATE$34, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().add_element_user(TEMPLATE$34);
            }
            target.set(template);
        }
    }
    
    /**
     * Appends and returns a new empty "Template" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Template addNewTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Template target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().add_element_user(TEMPLATE$34);
            return target;
        }
    }
    
    /**
     * Nils the "Template" element
     */
    public void setNilTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Template target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().find_element_user(TEMPLATE$34, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().add_element_user(TEMPLATE$34);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Template" element
     */
    public void unsetTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TEMPLATE$34, 0);
        }
    }
    
    /**
     * Gets the "Type" element
     */
    public java.lang.String getType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TYPE$36, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Type" element
     */
    public org.apache.xmlbeans.XmlString xgetType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TYPE$36, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Type" element
     */
    public boolean isNilType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TYPE$36, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Type" element
     */
    public boolean isSetType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TYPE$36) != 0;
        }
    }
    
    /**
     * Sets the "Type" element
     */
    public void setType(java.lang.String type)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TYPE$36, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TYPE$36);
            }
            target.setStringValue(type);
        }
    }
    
    /**
     * Sets (as xml) the "Type" element
     */
    public void xsetType(org.apache.xmlbeans.XmlString type)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TYPE$36, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TYPE$36);
            }
            target.set(type);
        }
    }
    
    /**
     * Nils the "Type" element
     */
    public void setNilType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TYPE$36, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TYPE$36);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Type" element
     */
    public void unsetType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TYPE$36, 0);
        }
    }
}
