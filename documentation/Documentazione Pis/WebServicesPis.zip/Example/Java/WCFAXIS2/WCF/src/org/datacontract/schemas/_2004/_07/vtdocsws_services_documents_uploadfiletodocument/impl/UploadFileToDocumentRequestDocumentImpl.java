/*
 * An XML document type.
 * Localname: UploadFileToDocumentRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.UploadFileToDocument
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.impl;
/**
 * A document containing one UploadFileToDocumentRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.UploadFileToDocument) element.
 *
 * This is a complex type.
 */
public class UploadFileToDocumentRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentRequestDocument
{
    
    public UploadFileToDocumentRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName UPLOADFILETODOCUMENTREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.UploadFileToDocument", "UploadFileToDocumentRequest");
    
    
    /**
     * Gets the "UploadFileToDocumentRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentRequest getUploadFileToDocumentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentRequest)get_store().find_element_user(UPLOADFILETODOCUMENTREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "UploadFileToDocumentRequest" element
     */
    public boolean isNilUploadFileToDocumentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentRequest)get_store().find_element_user(UPLOADFILETODOCUMENTREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "UploadFileToDocumentRequest" element
     */
    public void setUploadFileToDocumentRequest(org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentRequest uploadFileToDocumentRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentRequest)get_store().find_element_user(UPLOADFILETODOCUMENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentRequest)get_store().add_element_user(UPLOADFILETODOCUMENTREQUEST$0);
            }
            target.set(uploadFileToDocumentRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "UploadFileToDocumentRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentRequest addNewUploadFileToDocumentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentRequest)get_store().add_element_user(UPLOADFILETODOCUMENTREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "UploadFileToDocumentRequest" element
     */
    public void setNilUploadFileToDocumentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentRequest)get_store().find_element_user(UPLOADFILETODOCUMENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentRequest)get_store().add_element_user(UPLOADFILETODOCUMENTREQUEST$0);
            }
            target.setNil();
        }
    }
}
