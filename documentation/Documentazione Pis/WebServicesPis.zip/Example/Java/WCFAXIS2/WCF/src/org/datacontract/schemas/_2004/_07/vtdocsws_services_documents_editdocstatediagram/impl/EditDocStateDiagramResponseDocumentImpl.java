/*
 * An XML document type.
 * Localname: EditDocStateDiagramResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.EditDocStateDiagram
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.impl;
/**
 * A document containing one EditDocStateDiagramResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.EditDocStateDiagram) element.
 *
 * This is a complex type.
 */
public class EditDocStateDiagramResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramResponseDocument
{
    
    public EditDocStateDiagramResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EDITDOCSTATEDIAGRAMRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.EditDocStateDiagram", "EditDocStateDiagramResponse");
    
    
    /**
     * Gets the "EditDocStateDiagramResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramResponse getEditDocStateDiagramResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramResponse)get_store().find_element_user(EDITDOCSTATEDIAGRAMRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "EditDocStateDiagramResponse" element
     */
    public boolean isNilEditDocStateDiagramResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramResponse)get_store().find_element_user(EDITDOCSTATEDIAGRAMRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "EditDocStateDiagramResponse" element
     */
    public void setEditDocStateDiagramResponse(org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramResponse editDocStateDiagramResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramResponse)get_store().find_element_user(EDITDOCSTATEDIAGRAMRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramResponse)get_store().add_element_user(EDITDOCSTATEDIAGRAMRESPONSE$0);
            }
            target.set(editDocStateDiagramResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "EditDocStateDiagramResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramResponse addNewEditDocStateDiagramResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramResponse)get_store().add_element_user(EDITDOCSTATEDIAGRAMRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "EditDocStateDiagramResponse" element
     */
    public void setNilEditDocStateDiagramResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramResponse)get_store().find_element_user(EDITDOCSTATEDIAGRAMRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramResponse)get_store().add_element_user(EDITDOCSTATEDIAGRAMRESPONSE$0);
            }
            target.setNil();
        }
    }
}
