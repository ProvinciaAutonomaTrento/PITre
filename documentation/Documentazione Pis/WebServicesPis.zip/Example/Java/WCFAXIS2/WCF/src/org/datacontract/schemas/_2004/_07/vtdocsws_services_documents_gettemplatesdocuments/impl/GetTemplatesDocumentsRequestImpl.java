/*
 * XML Type:  GetTemplatesDocumentsRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetTemplatesDocuments
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsRequest
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.impl;
/**
 * An XML GetTemplatesDocumentsRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetTemplatesDocuments).
 *
 * This is a complex type.
 */
public class GetTemplatesDocumentsRequestImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.RequestImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsRequest
{
    
    public GetTemplatesDocumentsRequestImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
