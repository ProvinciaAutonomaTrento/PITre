/*
 * XML Type:  ArrayOfTransmissionModel
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfTransmissionModel
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * An XML ArrayOfTransmissionModel(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain).
 *
 * This is a complex type.
 */
public class ArrayOfTransmissionModelImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfTransmissionModel
{
    
    public ArrayOfTransmissionModelImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TRANSMISSIONMODEL$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "TransmissionModel");
    
    
    /**
     * Gets array of all "TransmissionModel" elements
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel[] getTransmissionModelArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(TRANSMISSIONMODEL$0, targetList);
            org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel[] result = new org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "TransmissionModel" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel getTransmissionModelArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel)get_store().find_element_user(TRANSMISSIONMODEL$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Tests for nil ith "TransmissionModel" element
     */
    public boolean isNilTransmissionModelArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel)get_store().find_element_user(TRANSMISSIONMODEL$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "TransmissionModel" element
     */
    public int sizeOfTransmissionModelArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TRANSMISSIONMODEL$0);
        }
    }
    
    /**
     * Sets array of all "TransmissionModel" element
     */
    public void setTransmissionModelArray(org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel[] transmissionModelArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(transmissionModelArray, TRANSMISSIONMODEL$0);
        }
    }
    
    /**
     * Sets ith "TransmissionModel" element
     */
    public void setTransmissionModelArray(int i, org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel transmissionModel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel)get_store().find_element_user(TRANSMISSIONMODEL$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(transmissionModel);
        }
    }
    
    /**
     * Nils the ith "TransmissionModel" element
     */
    public void setNilTransmissionModelArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel)get_store().find_element_user(TRANSMISSIONMODEL$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "TransmissionModel" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel insertNewTransmissionModel(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel)get_store().insert_element_user(TRANSMISSIONMODEL$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "TransmissionModel" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel addNewTransmissionModel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel)get_store().add_element_user(TRANSMISSIONMODEL$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "TransmissionModel" element
     */
    public void removeTransmissionModel(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TRANSMISSIONMODEL$0, i);
        }
    }
}
