/*
 * XML Type:  GetClassificationSchemeByIdResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetClassificationSchemeById
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdResponse
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.impl;
/**
 * An XML GetClassificationSchemeByIdResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetClassificationSchemeById).
 *
 * This is a complex type.
 */
public class GetClassificationSchemeByIdResponseImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.ResponseImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdResponse
{
    
    public GetClassificationSchemeByIdResponseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CLASSIFICATIONSCHEME$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetClassificationSchemeById", "ClassificationScheme");
    
    
    /**
     * Gets the "ClassificationScheme" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme getClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().find_element_user(CLASSIFICATIONSCHEME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ClassificationScheme" element
     */
    public boolean isNilClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().find_element_user(CLASSIFICATIONSCHEME$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ClassificationScheme" element
     */
    public boolean isSetClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CLASSIFICATIONSCHEME$0) != 0;
        }
    }
    
    /**
     * Sets the "ClassificationScheme" element
     */
    public void setClassificationScheme(org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme classificationScheme)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().find_element_user(CLASSIFICATIONSCHEME$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().add_element_user(CLASSIFICATIONSCHEME$0);
            }
            target.set(classificationScheme);
        }
    }
    
    /**
     * Appends and returns a new empty "ClassificationScheme" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme addNewClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().add_element_user(CLASSIFICATIONSCHEME$0);
            return target;
        }
    }
    
    /**
     * Nils the "ClassificationScheme" element
     */
    public void setNilClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().find_element_user(CLASSIFICATIONSCHEME$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().add_element_user(CLASSIFICATIONSCHEME$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ClassificationScheme" element
     */
    public void unsetClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CLASSIFICATIONSCHEME$0, 0);
        }
    }
}
