/*
 * XML Type:  GetFileDocumentByIdRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetFileDocumentById
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfiledocumentbyid.GetFileDocumentByIdRequest
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfiledocumentbyid.impl;
/**
 * An XML GetFileDocumentByIdRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetFileDocumentById).
 *
 * This is a complex type.
 */
public class GetFileDocumentByIdRequestImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.RequestImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfiledocumentbyid.GetFileDocumentByIdRequest
{
    
    public GetFileDocumentByIdRequestImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName IDDOCUMENT$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetFileDocumentById", "IdDocument");
    private static final javax.xml.namespace.QName VERSIONID$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetFileDocumentById", "VersionId");
    
    
    /**
     * Gets the "IdDocument" element
     */
    public java.lang.String getIdDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDDOCUMENT$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "IdDocument" element
     */
    public org.apache.xmlbeans.XmlString xgetIdDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDDOCUMENT$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "IdDocument" element
     */
    public boolean isNilIdDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDDOCUMENT$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "IdDocument" element
     */
    public boolean isSetIdDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(IDDOCUMENT$0) != 0;
        }
    }
    
    /**
     * Sets the "IdDocument" element
     */
    public void setIdDocument(java.lang.String idDocument)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDDOCUMENT$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(IDDOCUMENT$0);
            }
            target.setStringValue(idDocument);
        }
    }
    
    /**
     * Sets (as xml) the "IdDocument" element
     */
    public void xsetIdDocument(org.apache.xmlbeans.XmlString idDocument)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDDOCUMENT$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(IDDOCUMENT$0);
            }
            target.set(idDocument);
        }
    }
    
    /**
     * Nils the "IdDocument" element
     */
    public void setNilIdDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDDOCUMENT$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(IDDOCUMENT$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "IdDocument" element
     */
    public void unsetIdDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(IDDOCUMENT$0, 0);
        }
    }
    
    /**
     * Gets the "VersionId" element
     */
    public java.lang.String getVersionId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VERSIONID$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "VersionId" element
     */
    public org.apache.xmlbeans.XmlString xgetVersionId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VERSIONID$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "VersionId" element
     */
    public boolean isNilVersionId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VERSIONID$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "VersionId" element
     */
    public boolean isSetVersionId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VERSIONID$2) != 0;
        }
    }
    
    /**
     * Sets the "VersionId" element
     */
    public void setVersionId(java.lang.String versionId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VERSIONID$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VERSIONID$2);
            }
            target.setStringValue(versionId);
        }
    }
    
    /**
     * Sets (as xml) the "VersionId" element
     */
    public void xsetVersionId(org.apache.xmlbeans.XmlString versionId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VERSIONID$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(VERSIONID$2);
            }
            target.set(versionId);
        }
    }
    
    /**
     * Nils the "VersionId" element
     */
    public void setNilVersionId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VERSIONID$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(VERSIONID$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "VersionId" element
     */
    public void unsetVersionId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VERSIONID$2, 0);
        }
    }
}
