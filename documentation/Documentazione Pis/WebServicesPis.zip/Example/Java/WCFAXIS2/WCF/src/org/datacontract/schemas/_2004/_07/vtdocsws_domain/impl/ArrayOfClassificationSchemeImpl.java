/*
 * XML Type:  ArrayOfClassificationScheme
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * An XML ArrayOfClassificationScheme(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain).
 *
 * This is a complex type.
 */
public class ArrayOfClassificationSchemeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme
{
    
    public ArrayOfClassificationSchemeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CLASSIFICATIONSCHEME$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "ClassificationScheme");
    
    
    /**
     * Gets array of all "ClassificationScheme" elements
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme[] getClassificationSchemeArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(CLASSIFICATIONSCHEME$0, targetList);
            org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme[] result = new org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "ClassificationScheme" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme getClassificationSchemeArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().find_element_user(CLASSIFICATIONSCHEME$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Tests for nil ith "ClassificationScheme" element
     */
    public boolean isNilClassificationSchemeArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().find_element_user(CLASSIFICATIONSCHEME$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "ClassificationScheme" element
     */
    public int sizeOfClassificationSchemeArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CLASSIFICATIONSCHEME$0);
        }
    }
    
    /**
     * Sets array of all "ClassificationScheme" element
     */
    public void setClassificationSchemeArray(org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme[] classificationSchemeArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(classificationSchemeArray, CLASSIFICATIONSCHEME$0);
        }
    }
    
    /**
     * Sets ith "ClassificationScheme" element
     */
    public void setClassificationSchemeArray(int i, org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme classificationScheme)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().find_element_user(CLASSIFICATIONSCHEME$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(classificationScheme);
        }
    }
    
    /**
     * Nils the ith "ClassificationScheme" element
     */
    public void setNilClassificationSchemeArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().find_element_user(CLASSIFICATIONSCHEME$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "ClassificationScheme" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme insertNewClassificationScheme(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().insert_element_user(CLASSIFICATIONSCHEME$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "ClassificationScheme" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme addNewClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().add_element_user(CLASSIFICATIONSCHEME$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "ClassificationScheme" element
     */
    public void removeClassificationScheme(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CLASSIFICATIONSCHEME$0, i);
        }
    }
}
