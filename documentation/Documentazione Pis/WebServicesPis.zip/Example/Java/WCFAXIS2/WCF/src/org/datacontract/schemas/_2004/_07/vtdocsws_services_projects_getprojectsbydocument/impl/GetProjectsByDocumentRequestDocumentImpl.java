/*
 * An XML document type.
 * Localname: GetProjectsByDocumentRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProjectsByDocument
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.impl;
/**
 * A document containing one GetProjectsByDocumentRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProjectsByDocument) element.
 *
 * This is a complex type.
 */
public class GetProjectsByDocumentRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentRequestDocument
{
    
    public GetProjectsByDocumentRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETPROJECTSBYDOCUMENTREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProjectsByDocument", "GetProjectsByDocumentRequest");
    
    
    /**
     * Gets the "GetProjectsByDocumentRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentRequest getGetProjectsByDocumentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentRequest)get_store().find_element_user(GETPROJECTSBYDOCUMENTREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetProjectsByDocumentRequest" element
     */
    public boolean isNilGetProjectsByDocumentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentRequest)get_store().find_element_user(GETPROJECTSBYDOCUMENTREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetProjectsByDocumentRequest" element
     */
    public void setGetProjectsByDocumentRequest(org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentRequest getProjectsByDocumentRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentRequest)get_store().find_element_user(GETPROJECTSBYDOCUMENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentRequest)get_store().add_element_user(GETPROJECTSBYDOCUMENTREQUEST$0);
            }
            target.set(getProjectsByDocumentRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "GetProjectsByDocumentRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentRequest addNewGetProjectsByDocumentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentRequest)get_store().add_element_user(GETPROJECTSBYDOCUMENTREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetProjectsByDocumentRequest" element
     */
    public void setNilGetProjectsByDocumentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentRequest)get_store().find_element_user(GETPROJECTSBYDOCUMENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentRequest)get_store().add_element_user(GETPROJECTSBYDOCUMENTREQUEST$0);
            }
            target.setNil();
        }
    }
}
