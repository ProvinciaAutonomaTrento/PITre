/*
 * An XML document type.
 * Localname: SendDocumentRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.SendDocument
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.impl;
/**
 * A document containing one SendDocumentRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.SendDocument) element.
 *
 * This is a complex type.
 */
public class SendDocumentRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentRequestDocument
{
    
    public SendDocumentRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SENDDOCUMENTREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.SendDocument", "SendDocumentRequest");
    
    
    /**
     * Gets the "SendDocumentRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentRequest getSendDocumentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentRequest)get_store().find_element_user(SENDDOCUMENTREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "SendDocumentRequest" element
     */
    public boolean isNilSendDocumentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentRequest)get_store().find_element_user(SENDDOCUMENTREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "SendDocumentRequest" element
     */
    public void setSendDocumentRequest(org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentRequest sendDocumentRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentRequest)get_store().find_element_user(SENDDOCUMENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentRequest)get_store().add_element_user(SENDDOCUMENTREQUEST$0);
            }
            target.set(sendDocumentRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "SendDocumentRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentRequest addNewSendDocumentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentRequest)get_store().add_element_user(SENDDOCUMENTREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "SendDocumentRequest" element
     */
    public void setNilSendDocumentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentRequest)get_store().find_element_user(SENDDOCUMENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentRequest)get_store().add_element_user(SENDDOCUMENTREQUEST$0);
            }
            target.setNil();
        }
    }
}
