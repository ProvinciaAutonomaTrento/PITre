/*
 * XML Type:  ArrayOfDocument
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * An XML ArrayOfDocument(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain).
 *
 * This is a complex type.
 */
public class ArrayOfDocument1Impl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1
{
    
    public ArrayOfDocument1Impl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DOCUMENT$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Document");
    
    
    /**
     * Gets array of all "Document" elements
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Document[] getDocumentArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(DOCUMENT$0, targetList);
            org.datacontract.schemas._2004._07.vtdocsws_domain.Document[] result = new org.datacontract.schemas._2004._07.vtdocsws_domain.Document[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "Document" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Document getDocumentArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Document target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Document)get_store().find_element_user(DOCUMENT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Tests for nil ith "Document" element
     */
    public boolean isNilDocumentArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Document target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Document)get_store().find_element_user(DOCUMENT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "Document" element
     */
    public int sizeOfDocumentArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DOCUMENT$0);
        }
    }
    
    /**
     * Sets array of all "Document" element
     */
    public void setDocumentArray(org.datacontract.schemas._2004._07.vtdocsws_domain.Document[] documentArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(documentArray, DOCUMENT$0);
        }
    }
    
    /**
     * Sets ith "Document" element
     */
    public void setDocumentArray(int i, org.datacontract.schemas._2004._07.vtdocsws_domain.Document document)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Document target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Document)get_store().find_element_user(DOCUMENT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(document);
        }
    }
    
    /**
     * Nils the ith "Document" element
     */
    public void setNilDocumentArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Document target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Document)get_store().find_element_user(DOCUMENT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "Document" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Document insertNewDocument(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Document target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Document)get_store().insert_element_user(DOCUMENT$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "Document" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Document addNewDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Document target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Document)get_store().add_element_user(DOCUMENT$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "Document" element
     */
    public void removeDocument(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DOCUMENT$0, i);
        }
    }
}
