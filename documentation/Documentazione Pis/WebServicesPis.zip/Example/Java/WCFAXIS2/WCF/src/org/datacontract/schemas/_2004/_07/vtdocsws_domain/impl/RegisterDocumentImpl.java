/*
 * An XML document type.
 * Localname: Register
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.RegisterDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one Register(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class RegisterDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.RegisterDocument
{
    
    public RegisterDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName REGISTER$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Register");
    
    
    /**
     * Gets the "Register" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Register getRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Register target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().find_element_user(REGISTER$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Register" element
     */
    public boolean isNilRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Register target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().find_element_user(REGISTER$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "Register" element
     */
    public void setRegister(org.datacontract.schemas._2004._07.vtdocsws_domain.Register register)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Register target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().find_element_user(REGISTER$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().add_element_user(REGISTER$0);
            }
            target.set(register);
        }
    }
    
    /**
     * Appends and returns a new empty "Register" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Register addNewRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Register target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().add_element_user(REGISTER$0);
            return target;
        }
    }
    
    /**
     * Nils the "Register" element
     */
    public void setNilRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Register target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().find_element_user(REGISTER$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().add_element_user(REGISTER$0);
            }
            target.setNil();
        }
    }
}
