/*
 * XML Type:  DeleteCorrespondentResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.DeleteCorrespondent
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentResponse
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.impl;
/**
 * An XML DeleteCorrespondentResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.DeleteCorrespondent).
 *
 * This is a complex type.
 */
public class DeleteCorrespondentResponseImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.ResponseImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentResponse
{
    
    public DeleteCorrespondentResponseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
