/*
 * XML Type:  GetTemplateDocRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetTemplateDoc
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc;


/**
 * An XML GetTemplateDocRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetTemplateDoc).
 *
 * This is a complex type.
 */
public interface GetTemplateDocRequest extends org.datacontract.schemas._2004._07.vtdocsws_services.Request
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(GetTemplateDocRequest.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s618A4BF965398050DC6199178E6A766E").resolveHandle("gettemplatedocrequestbcc1type");
    
    /**
     * Gets the "DescriptionTemplate" element
     */
    java.lang.String getDescriptionTemplate();
    
    /**
     * Gets (as xml) the "DescriptionTemplate" element
     */
    org.apache.xmlbeans.XmlString xgetDescriptionTemplate();
    
    /**
     * Tests for nil "DescriptionTemplate" element
     */
    boolean isNilDescriptionTemplate();
    
    /**
     * True if has "DescriptionTemplate" element
     */
    boolean isSetDescriptionTemplate();
    
    /**
     * Sets the "DescriptionTemplate" element
     */
    void setDescriptionTemplate(java.lang.String descriptionTemplate);
    
    /**
     * Sets (as xml) the "DescriptionTemplate" element
     */
    void xsetDescriptionTemplate(org.apache.xmlbeans.XmlString descriptionTemplate);
    
    /**
     * Nils the "DescriptionTemplate" element
     */
    void setNilDescriptionTemplate();
    
    /**
     * Unsets the "DescriptionTemplate" element
     */
    void unsetDescriptionTemplate();
    
    /**
     * Gets the "IdTemplate" element
     */
    java.lang.String getIdTemplate();
    
    /**
     * Gets (as xml) the "IdTemplate" element
     */
    org.apache.xmlbeans.XmlString xgetIdTemplate();
    
    /**
     * Tests for nil "IdTemplate" element
     */
    boolean isNilIdTemplate();
    
    /**
     * True if has "IdTemplate" element
     */
    boolean isSetIdTemplate();
    
    /**
     * Sets the "IdTemplate" element
     */
    void setIdTemplate(java.lang.String idTemplate);
    
    /**
     * Sets (as xml) the "IdTemplate" element
     */
    void xsetIdTemplate(org.apache.xmlbeans.XmlString idTemplate);
    
    /**
     * Nils the "IdTemplate" element
     */
    void setNilIdTemplate();
    
    /**
     * Unsets the "IdTemplate" element
     */
    void unsetIdTemplate();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest newInstance() {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatedoc.GetTemplateDocRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
