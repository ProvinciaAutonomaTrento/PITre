/*
 * XML Type:  CreateProjectResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.CreateProject
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectResponse
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.impl;
/**
 * An XML CreateProjectResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.CreateProject).
 *
 * This is a complex type.
 */
public class CreateProjectResponseImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.ResponseImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectResponse
{
    
    public CreateProjectResponseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PROJECT$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.CreateProject", "Project");
    
    
    /**
     * Gets the "Project" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Project getProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Project target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Project)get_store().find_element_user(PROJECT$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Project" element
     */
    public boolean isNilProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Project target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Project)get_store().find_element_user(PROJECT$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Project" element
     */
    public boolean isSetProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROJECT$0) != 0;
        }
    }
    
    /**
     * Sets the "Project" element
     */
    public void setProject(org.datacontract.schemas._2004._07.vtdocsws_domain.Project project)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Project target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Project)get_store().find_element_user(PROJECT$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Project)get_store().add_element_user(PROJECT$0);
            }
            target.set(project);
        }
    }
    
    /**
     * Appends and returns a new empty "Project" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Project addNewProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Project target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Project)get_store().add_element_user(PROJECT$0);
            return target;
        }
    }
    
    /**
     * Nils the "Project" element
     */
    public void setNilProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Project target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Project)get_store().find_element_user(PROJECT$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Project)get_store().add_element_user(PROJECT$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Project" element
     */
    public void unsetProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROJECT$0, 0);
        }
    }
}
