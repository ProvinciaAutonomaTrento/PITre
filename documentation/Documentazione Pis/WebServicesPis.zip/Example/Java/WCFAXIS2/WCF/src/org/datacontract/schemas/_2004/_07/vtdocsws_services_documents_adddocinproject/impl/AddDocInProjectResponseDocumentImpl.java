/*
 * An XML document type.
 * Localname: AddDocInProjectResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.AddDocInProject
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.impl;
/**
 * A document containing one AddDocInProjectResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.AddDocInProject) element.
 *
 * This is a complex type.
 */
public class AddDocInProjectResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectResponseDocument
{
    
    public AddDocInProjectResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ADDDOCINPROJECTRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.AddDocInProject", "AddDocInProjectResponse");
    
    
    /**
     * Gets the "AddDocInProjectResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectResponse getAddDocInProjectResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectResponse)get_store().find_element_user(ADDDOCINPROJECTRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "AddDocInProjectResponse" element
     */
    public boolean isNilAddDocInProjectResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectResponse)get_store().find_element_user(ADDDOCINPROJECTRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "AddDocInProjectResponse" element
     */
    public void setAddDocInProjectResponse(org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectResponse addDocInProjectResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectResponse)get_store().find_element_user(ADDDOCINPROJECTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectResponse)get_store().add_element_user(ADDDOCINPROJECTRESPONSE$0);
            }
            target.set(addDocInProjectResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "AddDocInProjectResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectResponse addNewAddDocInProjectResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectResponse)get_store().add_element_user(ADDDOCINPROJECTRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "AddDocInProjectResponse" element
     */
    public void setNilAddDocInProjectResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectResponse)get_store().find_element_user(ADDDOCINPROJECTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectResponse)get_store().add_element_user(ADDDOCINPROJECTRESPONSE$0);
            }
            target.setNil();
        }
    }
}
