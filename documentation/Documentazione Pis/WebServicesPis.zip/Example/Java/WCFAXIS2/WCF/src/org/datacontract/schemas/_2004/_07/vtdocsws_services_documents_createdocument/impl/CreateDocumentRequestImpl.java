/*
 * XML Type:  CreateDocumentRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.CreateDocument
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.impl;
/**
 * An XML CreateDocumentRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.CreateDocument).
 *
 * This is a complex type.
 */
public class CreateDocumentRequestImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.RequestImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest
{
    
    public CreateDocumentRequestImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CODERF$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.CreateDocument", "CodeRF");
    private static final javax.xml.namespace.QName CODEREGISTER$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.CreateDocument", "CodeRegister");
    private static final javax.xml.namespace.QName DOCUMENT$4 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.CreateDocument", "Document");
    
    
    /**
     * Gets the "CodeRF" element
     */
    public java.lang.String getCodeRF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODERF$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodeRF" element
     */
    public org.apache.xmlbeans.XmlString xgetCodeRF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODERF$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CodeRF" element
     */
    public boolean isNilCodeRF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODERF$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CodeRF" element
     */
    public boolean isSetCodeRF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODERF$0) != 0;
        }
    }
    
    /**
     * Sets the "CodeRF" element
     */
    public void setCodeRF(java.lang.String codeRF)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODERF$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODERF$0);
            }
            target.setStringValue(codeRF);
        }
    }
    
    /**
     * Sets (as xml) the "CodeRF" element
     */
    public void xsetCodeRF(org.apache.xmlbeans.XmlString codeRF)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODERF$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODERF$0);
            }
            target.set(codeRF);
        }
    }
    
    /**
     * Nils the "CodeRF" element
     */
    public void setNilCodeRF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODERF$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODERF$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CodeRF" element
     */
    public void unsetCodeRF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODERF$0, 0);
        }
    }
    
    /**
     * Gets the "CodeRegister" element
     */
    public java.lang.String getCodeRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODEREGISTER$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodeRegister" element
     */
    public org.apache.xmlbeans.XmlString xgetCodeRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEREGISTER$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CodeRegister" element
     */
    public boolean isNilCodeRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEREGISTER$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CodeRegister" element
     */
    public boolean isSetCodeRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODEREGISTER$2) != 0;
        }
    }
    
    /**
     * Sets the "CodeRegister" element
     */
    public void setCodeRegister(java.lang.String codeRegister)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODEREGISTER$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODEREGISTER$2);
            }
            target.setStringValue(codeRegister);
        }
    }
    
    /**
     * Sets (as xml) the "CodeRegister" element
     */
    public void xsetCodeRegister(org.apache.xmlbeans.XmlString codeRegister)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEREGISTER$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODEREGISTER$2);
            }
            target.set(codeRegister);
        }
    }
    
    /**
     * Nils the "CodeRegister" element
     */
    public void setNilCodeRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEREGISTER$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODEREGISTER$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CodeRegister" element
     */
    public void unsetCodeRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODEREGISTER$2, 0);
        }
    }
    
    /**
     * Gets the "Document" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Document getDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Document target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Document)get_store().find_element_user(DOCUMENT$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Document" element
     */
    public boolean isNilDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Document target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Document)get_store().find_element_user(DOCUMENT$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Document" element
     */
    public boolean isSetDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DOCUMENT$4) != 0;
        }
    }
    
    /**
     * Sets the "Document" element
     */
    public void setDocument(org.datacontract.schemas._2004._07.vtdocsws_domain.Document document)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Document target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Document)get_store().find_element_user(DOCUMENT$4, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Document)get_store().add_element_user(DOCUMENT$4);
            }
            target.set(document);
        }
    }
    
    /**
     * Appends and returns a new empty "Document" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Document addNewDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Document target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Document)get_store().add_element_user(DOCUMENT$4);
            return target;
        }
    }
    
    /**
     * Nils the "Document" element
     */
    public void setNilDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Document target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Document)get_store().find_element_user(DOCUMENT$4, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Document)get_store().add_element_user(DOCUMENT$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Document" element
     */
    public void unsetDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DOCUMENT$4, 0);
        }
    }
}
