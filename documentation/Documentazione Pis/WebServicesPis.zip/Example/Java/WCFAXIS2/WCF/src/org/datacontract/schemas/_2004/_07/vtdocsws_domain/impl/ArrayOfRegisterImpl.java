/*
 * XML Type:  ArrayOfRegister
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRegister
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * An XML ArrayOfRegister(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain).
 *
 * This is a complex type.
 */
public class ArrayOfRegisterImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRegister
{
    
    public ArrayOfRegisterImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName REGISTER$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Register");
    
    
    /**
     * Gets array of all "Register" elements
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Register[] getRegisterArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(REGISTER$0, targetList);
            org.datacontract.schemas._2004._07.vtdocsws_domain.Register[] result = new org.datacontract.schemas._2004._07.vtdocsws_domain.Register[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "Register" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Register getRegisterArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Register target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().find_element_user(REGISTER$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Tests for nil ith "Register" element
     */
    public boolean isNilRegisterArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Register target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().find_element_user(REGISTER$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "Register" element
     */
    public int sizeOfRegisterArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(REGISTER$0);
        }
    }
    
    /**
     * Sets array of all "Register" element
     */
    public void setRegisterArray(org.datacontract.schemas._2004._07.vtdocsws_domain.Register[] registerArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(registerArray, REGISTER$0);
        }
    }
    
    /**
     * Sets ith "Register" element
     */
    public void setRegisterArray(int i, org.datacontract.schemas._2004._07.vtdocsws_domain.Register register)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Register target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().find_element_user(REGISTER$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(register);
        }
    }
    
    /**
     * Nils the ith "Register" element
     */
    public void setNilRegisterArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Register target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().find_element_user(REGISTER$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "Register" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Register insertNewRegister(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Register target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().insert_element_user(REGISTER$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "Register" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Register addNewRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Register target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().add_element_user(REGISTER$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "Register" element
     */
    public void removeRegister(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(REGISTER$0, i);
        }
    }
}
