/*
 * XML Type:  GetAllClassificationSchemesResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetAllClassificationSchemes
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesResponse
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.impl;
/**
 * An XML GetAllClassificationSchemesResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetAllClassificationSchemes).
 *
 * This is a complex type.
 */
public class GetAllClassificationSchemesResponseImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.ResponseImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesResponse
{
    
    public GetAllClassificationSchemesResponseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CLASSIFICATIONSCHEMES$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetAllClassificationSchemes", "ClassificationSchemes");
    
    
    /**
     * Gets the "ClassificationSchemes" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme getClassificationSchemes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme)get_store().find_element_user(CLASSIFICATIONSCHEMES$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ClassificationSchemes" element
     */
    public boolean isNilClassificationSchemes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme)get_store().find_element_user(CLASSIFICATIONSCHEMES$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ClassificationSchemes" element
     */
    public boolean isSetClassificationSchemes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CLASSIFICATIONSCHEMES$0) != 0;
        }
    }
    
    /**
     * Sets the "ClassificationSchemes" element
     */
    public void setClassificationSchemes(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme classificationSchemes)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme)get_store().find_element_user(CLASSIFICATIONSCHEMES$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme)get_store().add_element_user(CLASSIFICATIONSCHEMES$0);
            }
            target.set(classificationSchemes);
        }
    }
    
    /**
     * Appends and returns a new empty "ClassificationSchemes" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme addNewClassificationSchemes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme)get_store().add_element_user(CLASSIFICATIONSCHEMES$0);
            return target;
        }
    }
    
    /**
     * Nils the "ClassificationSchemes" element
     */
    public void setNilClassificationSchemes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme)get_store().find_element_user(CLASSIFICATIONSCHEMES$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme)get_store().add_element_user(CLASSIFICATIONSCHEMES$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ClassificationSchemes" element
     */
    public void unsetClassificationSchemes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CLASSIFICATIONSCHEMES$0, 0);
        }
    }
}
