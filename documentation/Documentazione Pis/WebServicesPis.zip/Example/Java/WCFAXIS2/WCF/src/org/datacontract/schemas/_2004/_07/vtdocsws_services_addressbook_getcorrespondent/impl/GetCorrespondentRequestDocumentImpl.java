/*
 * An XML document type.
 * Localname: GetCorrespondentRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.GetCorrespondent
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_getcorrespondent.GetCorrespondentRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_getcorrespondent.impl;
/**
 * A document containing one GetCorrespondentRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.GetCorrespondent) element.
 *
 * This is a complex type.
 */
public class GetCorrespondentRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_getcorrespondent.GetCorrespondentRequestDocument
{
    
    public GetCorrespondentRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETCORRESPONDENTREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.GetCorrespondent", "GetCorrespondentRequest");
    
    
    /**
     * Gets the "GetCorrespondentRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_getcorrespondent.GetCorrespondentRequest getGetCorrespondentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_getcorrespondent.GetCorrespondentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_getcorrespondent.GetCorrespondentRequest)get_store().find_element_user(GETCORRESPONDENTREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetCorrespondentRequest" element
     */
    public boolean isNilGetCorrespondentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_getcorrespondent.GetCorrespondentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_getcorrespondent.GetCorrespondentRequest)get_store().find_element_user(GETCORRESPONDENTREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetCorrespondentRequest" element
     */
    public void setGetCorrespondentRequest(org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_getcorrespondent.GetCorrespondentRequest getCorrespondentRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_getcorrespondent.GetCorrespondentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_getcorrespondent.GetCorrespondentRequest)get_store().find_element_user(GETCORRESPONDENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_getcorrespondent.GetCorrespondentRequest)get_store().add_element_user(GETCORRESPONDENTREQUEST$0);
            }
            target.set(getCorrespondentRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "GetCorrespondentRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_getcorrespondent.GetCorrespondentRequest addNewGetCorrespondentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_getcorrespondent.GetCorrespondentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_getcorrespondent.GetCorrespondentRequest)get_store().add_element_user(GETCORRESPONDENTREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetCorrespondentRequest" element
     */
    public void setNilGetCorrespondentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_getcorrespondent.GetCorrespondentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_getcorrespondent.GetCorrespondentRequest)get_store().find_element_user(GETCORRESPONDENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_getcorrespondent.GetCorrespondentRequest)get_store().add_element_user(GETCORRESPONDENTREQUEST$0);
            }
            target.setNil();
        }
    }
}
