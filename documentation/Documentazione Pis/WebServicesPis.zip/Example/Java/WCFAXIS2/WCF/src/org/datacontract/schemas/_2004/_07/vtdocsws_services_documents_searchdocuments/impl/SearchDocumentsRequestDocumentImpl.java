/*
 * An XML document type.
 * Localname: SearchDocumentsRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.SearchDocuments
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.impl;
/**
 * A document containing one SearchDocumentsRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.SearchDocuments) element.
 *
 * This is a complex type.
 */
public class SearchDocumentsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsRequestDocument
{
    
    public SearchDocumentsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SEARCHDOCUMENTSREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.SearchDocuments", "SearchDocumentsRequest");
    
    
    /**
     * Gets the "SearchDocumentsRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsRequest getSearchDocumentsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsRequest)get_store().find_element_user(SEARCHDOCUMENTSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "SearchDocumentsRequest" element
     */
    public boolean isNilSearchDocumentsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsRequest)get_store().find_element_user(SEARCHDOCUMENTSREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "SearchDocumentsRequest" element
     */
    public void setSearchDocumentsRequest(org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsRequest searchDocumentsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsRequest)get_store().find_element_user(SEARCHDOCUMENTSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsRequest)get_store().add_element_user(SEARCHDOCUMENTSREQUEST$0);
            }
            target.set(searchDocumentsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "SearchDocumentsRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsRequest addNewSearchDocumentsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsRequest)get_store().add_element_user(SEARCHDOCUMENTSREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "SearchDocumentsRequest" element
     */
    public void setNilSearchDocumentsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsRequest)get_store().find_element_user(SEARCHDOCUMENTSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsRequest)get_store().add_element_user(SEARCHDOCUMENTSREQUEST$0);
            }
            target.setNil();
        }
    }
}
