/*
 * An XML document type.
 * Localname: Filter
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.FilterDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one Filter(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class FilterDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.FilterDocument
{
    
    public FilterDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName FILTER$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Filter");
    
    
    /**
     * Gets the "Filter" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Filter getFilter()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Filter target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Filter)get_store().find_element_user(FILTER$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Filter" element
     */
    public boolean isNilFilter()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Filter target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Filter)get_store().find_element_user(FILTER$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "Filter" element
     */
    public void setFilter(org.datacontract.schemas._2004._07.vtdocsws_domain.Filter filter)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Filter target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Filter)get_store().find_element_user(FILTER$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Filter)get_store().add_element_user(FILTER$0);
            }
            target.set(filter);
        }
    }
    
    /**
     * Appends and returns a new empty "Filter" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Filter addNewFilter()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Filter target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Filter)get_store().add_element_user(FILTER$0);
            return target;
        }
    }
    
    /**
     * Nils the "Filter" element
     */
    public void setNilFilter()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Filter target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Filter)get_store().find_element_user(FILTER$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Filter)get_store().add_element_user(FILTER$0);
            }
            target.setNil();
        }
    }
}
