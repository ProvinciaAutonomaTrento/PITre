/*
 * XML Type:  Document
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.Document
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain;


/**
 * An XML Document(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain).
 *
 * This is a complex type.
 */
public interface Document extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(Document.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s618A4BF965398050DC6199178E6A766E").resolveHandle("documentaa17type");
    
    /**
     * Gets the "Annulled" element
     */
    boolean getAnnulled();
    
    /**
     * Gets (as xml) the "Annulled" element
     */
    org.apache.xmlbeans.XmlBoolean xgetAnnulled();
    
    /**
     * True if has "Annulled" element
     */
    boolean isSetAnnulled();
    
    /**
     * Sets the "Annulled" element
     */
    void setAnnulled(boolean annulled);
    
    /**
     * Sets (as xml) the "Annulled" element
     */
    void xsetAnnulled(org.apache.xmlbeans.XmlBoolean annulled);
    
    /**
     * Unsets the "Annulled" element
     */
    void unsetAnnulled();
    
    /**
     * Gets the "ArrivalDate" element
     */
    java.lang.String getArrivalDate();
    
    /**
     * Gets (as xml) the "ArrivalDate" element
     */
    org.apache.xmlbeans.XmlString xgetArrivalDate();
    
    /**
     * Tests for nil "ArrivalDate" element
     */
    boolean isNilArrivalDate();
    
    /**
     * True if has "ArrivalDate" element
     */
    boolean isSetArrivalDate();
    
    /**
     * Sets the "ArrivalDate" element
     */
    void setArrivalDate(java.lang.String arrivalDate);
    
    /**
     * Sets (as xml) the "ArrivalDate" element
     */
    void xsetArrivalDate(org.apache.xmlbeans.XmlString arrivalDate);
    
    /**
     * Nils the "ArrivalDate" element
     */
    void setNilArrivalDate();
    
    /**
     * Unsets the "ArrivalDate" element
     */
    void unsetArrivalDate();
    
    /**
     * Gets the "Attachments" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile getAttachments();
    
    /**
     * Tests for nil "Attachments" element
     */
    boolean isNilAttachments();
    
    /**
     * True if has "Attachments" element
     */
    boolean isSetAttachments();
    
    /**
     * Sets the "Attachments" element
     */
    void setAttachments(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile attachments);
    
    /**
     * Appends and returns a new empty "Attachments" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile addNewAttachments();
    
    /**
     * Nils the "Attachments" element
     */
    void setNilAttachments();
    
    /**
     * Unsets the "Attachments" element
     */
    void unsetAttachments();
    
    /**
     * Gets the "ConsolidationState" element
     */
    java.lang.String getConsolidationState();
    
    /**
     * Gets (as xml) the "ConsolidationState" element
     */
    org.apache.xmlbeans.XmlString xgetConsolidationState();
    
    /**
     * Tests for nil "ConsolidationState" element
     */
    boolean isNilConsolidationState();
    
    /**
     * True if has "ConsolidationState" element
     */
    boolean isSetConsolidationState();
    
    /**
     * Sets the "ConsolidationState" element
     */
    void setConsolidationState(java.lang.String consolidationState);
    
    /**
     * Sets (as xml) the "ConsolidationState" element
     */
    void xsetConsolidationState(org.apache.xmlbeans.XmlString consolidationState);
    
    /**
     * Nils the "ConsolidationState" element
     */
    void setNilConsolidationState();
    
    /**
     * Unsets the "ConsolidationState" element
     */
    void unsetConsolidationState();
    
    /**
     * Gets the "CreationDate" element
     */
    java.lang.String getCreationDate();
    
    /**
     * Gets (as xml) the "CreationDate" element
     */
    org.apache.xmlbeans.XmlString xgetCreationDate();
    
    /**
     * Tests for nil "CreationDate" element
     */
    boolean isNilCreationDate();
    
    /**
     * True if has "CreationDate" element
     */
    boolean isSetCreationDate();
    
    /**
     * Sets the "CreationDate" element
     */
    void setCreationDate(java.lang.String creationDate);
    
    /**
     * Sets (as xml) the "CreationDate" element
     */
    void xsetCreationDate(org.apache.xmlbeans.XmlString creationDate);
    
    /**
     * Nils the "CreationDate" element
     */
    void setNilCreationDate();
    
    /**
     * Unsets the "CreationDate" element
     */
    void unsetCreationDate();
    
    /**
     * Gets the "DataProtocolSender" element
     */
    java.lang.String getDataProtocolSender();
    
    /**
     * Gets (as xml) the "DataProtocolSender" element
     */
    org.apache.xmlbeans.XmlString xgetDataProtocolSender();
    
    /**
     * Tests for nil "DataProtocolSender" element
     */
    boolean isNilDataProtocolSender();
    
    /**
     * True if has "DataProtocolSender" element
     */
    boolean isSetDataProtocolSender();
    
    /**
     * Sets the "DataProtocolSender" element
     */
    void setDataProtocolSender(java.lang.String dataProtocolSender);
    
    /**
     * Sets (as xml) the "DataProtocolSender" element
     */
    void xsetDataProtocolSender(org.apache.xmlbeans.XmlString dataProtocolSender);
    
    /**
     * Nils the "DataProtocolSender" element
     */
    void setNilDataProtocolSender();
    
    /**
     * Unsets the "DataProtocolSender" element
     */
    void unsetDataProtocolSender();
    
    /**
     * Gets the "DocNumber" element
     */
    java.lang.String getDocNumber();
    
    /**
     * Gets (as xml) the "DocNumber" element
     */
    org.apache.xmlbeans.XmlString xgetDocNumber();
    
    /**
     * Tests for nil "DocNumber" element
     */
    boolean isNilDocNumber();
    
    /**
     * True if has "DocNumber" element
     */
    boolean isSetDocNumber();
    
    /**
     * Sets the "DocNumber" element
     */
    void setDocNumber(java.lang.String docNumber);
    
    /**
     * Sets (as xml) the "DocNumber" element
     */
    void xsetDocNumber(org.apache.xmlbeans.XmlString docNumber);
    
    /**
     * Nils the "DocNumber" element
     */
    void setNilDocNumber();
    
    /**
     * Unsets the "DocNumber" element
     */
    void unsetDocNumber();
    
    /**
     * Gets the "DocumentType" element
     */
    java.lang.String getDocumentType();
    
    /**
     * Gets (as xml) the "DocumentType" element
     */
    org.apache.xmlbeans.XmlString xgetDocumentType();
    
    /**
     * Tests for nil "DocumentType" element
     */
    boolean isNilDocumentType();
    
    /**
     * True if has "DocumentType" element
     */
    boolean isSetDocumentType();
    
    /**
     * Sets the "DocumentType" element
     */
    void setDocumentType(java.lang.String documentType);
    
    /**
     * Sets (as xml) the "DocumentType" element
     */
    void xsetDocumentType(org.apache.xmlbeans.XmlString documentType);
    
    /**
     * Nils the "DocumentType" element
     */
    void setNilDocumentType();
    
    /**
     * Unsets the "DocumentType" element
     */
    void unsetDocumentType();
    
    /**
     * Gets the "Id" element
     */
    java.lang.String getId();
    
    /**
     * Gets (as xml) the "Id" element
     */
    org.apache.xmlbeans.XmlString xgetId();
    
    /**
     * Tests for nil "Id" element
     */
    boolean isNilId();
    
    /**
     * True if has "Id" element
     */
    boolean isSetId();
    
    /**
     * Sets the "Id" element
     */
    void setId(java.lang.String id);
    
    /**
     * Sets (as xml) the "Id" element
     */
    void xsetId(org.apache.xmlbeans.XmlString id);
    
    /**
     * Nils the "Id" element
     */
    void setNilId();
    
    /**
     * Unsets the "Id" element
     */
    void unsetId();
    
    /**
     * Gets the "IdParent" element
     */
    java.lang.String getIdParent();
    
    /**
     * Gets (as xml) the "IdParent" element
     */
    org.apache.xmlbeans.XmlString xgetIdParent();
    
    /**
     * Tests for nil "IdParent" element
     */
    boolean isNilIdParent();
    
    /**
     * True if has "IdParent" element
     */
    boolean isSetIdParent();
    
    /**
     * Sets the "IdParent" element
     */
    void setIdParent(java.lang.String idParent);
    
    /**
     * Sets (as xml) the "IdParent" element
     */
    void xsetIdParent(org.apache.xmlbeans.XmlString idParent);
    
    /**
     * Nils the "IdParent" element
     */
    void setNilIdParent();
    
    /**
     * Unsets the "IdParent" element
     */
    void unsetIdParent();
    
    /**
     * Gets the "InBasket" element
     */
    boolean getInBasket();
    
    /**
     * Gets (as xml) the "InBasket" element
     */
    org.apache.xmlbeans.XmlBoolean xgetInBasket();
    
    /**
     * True if has "InBasket" element
     */
    boolean isSetInBasket();
    
    /**
     * Sets the "InBasket" element
     */
    void setInBasket(boolean inBasket);
    
    /**
     * Sets (as xml) the "InBasket" element
     */
    void xsetInBasket(org.apache.xmlbeans.XmlBoolean inBasket);
    
    /**
     * Unsets the "InBasket" element
     */
    void unsetInBasket();
    
    /**
     * Gets the "IsAttachments" element
     */
    boolean getIsAttachments();
    
    /**
     * Gets (as xml) the "IsAttachments" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsAttachments();
    
    /**
     * True if has "IsAttachments" element
     */
    boolean isSetIsAttachments();
    
    /**
     * Sets the "IsAttachments" element
     */
    void setIsAttachments(boolean isAttachments);
    
    /**
     * Sets (as xml) the "IsAttachments" element
     */
    void xsetIsAttachments(org.apache.xmlbeans.XmlBoolean isAttachments);
    
    /**
     * Unsets the "IsAttachments" element
     */
    void unsetIsAttachments();
    
    /**
     * Gets the "MainDocument" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.File getMainDocument();
    
    /**
     * Tests for nil "MainDocument" element
     */
    boolean isNilMainDocument();
    
    /**
     * True if has "MainDocument" element
     */
    boolean isSetMainDocument();
    
    /**
     * Sets the "MainDocument" element
     */
    void setMainDocument(org.datacontract.schemas._2004._07.vtdocsws_domain.File mainDocument);
    
    /**
     * Appends and returns a new empty "MainDocument" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.File addNewMainDocument();
    
    /**
     * Nils the "MainDocument" element
     */
    void setNilMainDocument();
    
    /**
     * Unsets the "MainDocument" element
     */
    void unsetMainDocument();
    
    /**
     * Gets the "MeansOfSending" element
     */
    java.lang.String getMeansOfSending();
    
    /**
     * Gets (as xml) the "MeansOfSending" element
     */
    org.apache.xmlbeans.XmlString xgetMeansOfSending();
    
    /**
     * Tests for nil "MeansOfSending" element
     */
    boolean isNilMeansOfSending();
    
    /**
     * True if has "MeansOfSending" element
     */
    boolean isSetMeansOfSending();
    
    /**
     * Sets the "MeansOfSending" element
     */
    void setMeansOfSending(java.lang.String meansOfSending);
    
    /**
     * Sets (as xml) the "MeansOfSending" element
     */
    void xsetMeansOfSending(org.apache.xmlbeans.XmlString meansOfSending);
    
    /**
     * Nils the "MeansOfSending" element
     */
    void setNilMeansOfSending();
    
    /**
     * Unsets the "MeansOfSending" element
     */
    void unsetMeansOfSending();
    
    /**
     * Gets the "MultipleSenders" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent getMultipleSenders();
    
    /**
     * Tests for nil "MultipleSenders" element
     */
    boolean isNilMultipleSenders();
    
    /**
     * True if has "MultipleSenders" element
     */
    boolean isSetMultipleSenders();
    
    /**
     * Sets the "MultipleSenders" element
     */
    void setMultipleSenders(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent multipleSenders);
    
    /**
     * Appends and returns a new empty "MultipleSenders" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent addNewMultipleSenders();
    
    /**
     * Nils the "MultipleSenders" element
     */
    void setNilMultipleSenders();
    
    /**
     * Unsets the "MultipleSenders" element
     */
    void unsetMultipleSenders();
    
    /**
     * Gets the "Note" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote getNote();
    
    /**
     * Tests for nil "Note" element
     */
    boolean isNilNote();
    
    /**
     * True if has "Note" element
     */
    boolean isSetNote();
    
    /**
     * Sets the "Note" element
     */
    void setNote(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote note);
    
    /**
     * Appends and returns a new empty "Note" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote addNewNote();
    
    /**
     * Nils the "Note" element
     */
    void setNilNote();
    
    /**
     * Unsets the "Note" element
     */
    void unsetNote();
    
    /**
     * Gets the "Object" element
     */
    java.lang.String getObject();
    
    /**
     * Gets (as xml) the "Object" element
     */
    org.apache.xmlbeans.XmlString xgetObject();
    
    /**
     * Tests for nil "Object" element
     */
    boolean isNilObject();
    
    /**
     * True if has "Object" element
     */
    boolean isSetObject();
    
    /**
     * Sets the "Object" element
     */
    void setObject(java.lang.String object);
    
    /**
     * Sets (as xml) the "Object" element
     */
    void xsetObject(org.apache.xmlbeans.XmlString object);
    
    /**
     * Nils the "Object" element
     */
    void setNilObject();
    
    /**
     * Unsets the "Object" element
     */
    void unsetObject();
    
    /**
     * Gets the "Predisposed" element
     */
    boolean getPredisposed();
    
    /**
     * Gets (as xml) the "Predisposed" element
     */
    org.apache.xmlbeans.XmlBoolean xgetPredisposed();
    
    /**
     * True if has "Predisposed" element
     */
    boolean isSetPredisposed();
    
    /**
     * Sets the "Predisposed" element
     */
    void setPredisposed(boolean predisposed);
    
    /**
     * Sets (as xml) the "Predisposed" element
     */
    void xsetPredisposed(org.apache.xmlbeans.XmlBoolean predisposed);
    
    /**
     * Unsets the "Predisposed" element
     */
    void unsetPredisposed();
    
    /**
     * Gets the "PrivateDocument" element
     */
    boolean getPrivateDocument();
    
    /**
     * Gets (as xml) the "PrivateDocument" element
     */
    org.apache.xmlbeans.XmlBoolean xgetPrivateDocument();
    
    /**
     * True if has "PrivateDocument" element
     */
    boolean isSetPrivateDocument();
    
    /**
     * Sets the "PrivateDocument" element
     */
    void setPrivateDocument(boolean privateDocument);
    
    /**
     * Sets (as xml) the "PrivateDocument" element
     */
    void xsetPrivateDocument(org.apache.xmlbeans.XmlBoolean privateDocument);
    
    /**
     * Unsets the "PrivateDocument" element
     */
    void unsetPrivateDocument();
    
    /**
     * Gets the "ProtocolDate" element
     */
    java.lang.String getProtocolDate();
    
    /**
     * Gets (as xml) the "ProtocolDate" element
     */
    org.apache.xmlbeans.XmlString xgetProtocolDate();
    
    /**
     * Tests for nil "ProtocolDate" element
     */
    boolean isNilProtocolDate();
    
    /**
     * True if has "ProtocolDate" element
     */
    boolean isSetProtocolDate();
    
    /**
     * Sets the "ProtocolDate" element
     */
    void setProtocolDate(java.lang.String protocolDate);
    
    /**
     * Sets (as xml) the "ProtocolDate" element
     */
    void xsetProtocolDate(org.apache.xmlbeans.XmlString protocolDate);
    
    /**
     * Nils the "ProtocolDate" element
     */
    void setNilProtocolDate();
    
    /**
     * Unsets the "ProtocolDate" element
     */
    void unsetProtocolDate();
    
    /**
     * Gets the "ProtocolSender" element
     */
    java.lang.String getProtocolSender();
    
    /**
     * Gets (as xml) the "ProtocolSender" element
     */
    org.apache.xmlbeans.XmlString xgetProtocolSender();
    
    /**
     * Tests for nil "ProtocolSender" element
     */
    boolean isNilProtocolSender();
    
    /**
     * True if has "ProtocolSender" element
     */
    boolean isSetProtocolSender();
    
    /**
     * Sets the "ProtocolSender" element
     */
    void setProtocolSender(java.lang.String protocolSender);
    
    /**
     * Sets (as xml) the "ProtocolSender" element
     */
    void xsetProtocolSender(org.apache.xmlbeans.XmlString protocolSender);
    
    /**
     * Nils the "ProtocolSender" element
     */
    void setNilProtocolSender();
    
    /**
     * Unsets the "ProtocolSender" element
     */
    void unsetProtocolSender();
    
    /**
     * Gets the "Recipients" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent getRecipients();
    
    /**
     * Tests for nil "Recipients" element
     */
    boolean isNilRecipients();
    
    /**
     * True if has "Recipients" element
     */
    boolean isSetRecipients();
    
    /**
     * Sets the "Recipients" element
     */
    void setRecipients(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent recipients);
    
    /**
     * Appends and returns a new empty "Recipients" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent addNewRecipients();
    
    /**
     * Nils the "Recipients" element
     */
    void setNilRecipients();
    
    /**
     * Unsets the "Recipients" element
     */
    void unsetRecipients();
    
    /**
     * Gets the "RecipientsCC" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent getRecipientsCC();
    
    /**
     * Tests for nil "RecipientsCC" element
     */
    boolean isNilRecipientsCC();
    
    /**
     * True if has "RecipientsCC" element
     */
    boolean isSetRecipientsCC();
    
    /**
     * Sets the "RecipientsCC" element
     */
    void setRecipientsCC(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent recipientsCC);
    
    /**
     * Appends and returns a new empty "RecipientsCC" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent addNewRecipientsCC();
    
    /**
     * Nils the "RecipientsCC" element
     */
    void setNilRecipientsCC();
    
    /**
     * Unsets the "RecipientsCC" element
     */
    void unsetRecipientsCC();
    
    /**
     * Gets the "Register" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.Register getRegister();
    
    /**
     * Tests for nil "Register" element
     */
    boolean isNilRegister();
    
    /**
     * True if has "Register" element
     */
    boolean isSetRegister();
    
    /**
     * Sets the "Register" element
     */
    void setRegister(org.datacontract.schemas._2004._07.vtdocsws_domain.Register register);
    
    /**
     * Appends and returns a new empty "Register" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.Register addNewRegister();
    
    /**
     * Nils the "Register" element
     */
    void setNilRegister();
    
    /**
     * Unsets the "Register" element
     */
    void unsetRegister();
    
    /**
     * Gets the "Sender" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent getSender();
    
    /**
     * Tests for nil "Sender" element
     */
    boolean isNilSender();
    
    /**
     * True if has "Sender" element
     */
    boolean isSetSender();
    
    /**
     * Sets the "Sender" element
     */
    void setSender(org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent sender);
    
    /**
     * Appends and returns a new empty "Sender" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent addNewSender();
    
    /**
     * Nils the "Sender" element
     */
    void setNilSender();
    
    /**
     * Unsets the "Sender" element
     */
    void unsetSender();
    
    /**
     * Gets the "Signature" element
     */
    java.lang.String getSignature();
    
    /**
     * Gets (as xml) the "Signature" element
     */
    org.apache.xmlbeans.XmlString xgetSignature();
    
    /**
     * Tests for nil "Signature" element
     */
    boolean isNilSignature();
    
    /**
     * True if has "Signature" element
     */
    boolean isSetSignature();
    
    /**
     * Sets the "Signature" element
     */
    void setSignature(java.lang.String signature);
    
    /**
     * Sets (as xml) the "Signature" element
     */
    void xsetSignature(org.apache.xmlbeans.XmlString signature);
    
    /**
     * Nils the "Signature" element
     */
    void setNilSignature();
    
    /**
     * Unsets the "Signature" element
     */
    void unsetSignature();
    
    /**
     * Gets the "Template" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.Template getTemplate();
    
    /**
     * Tests for nil "Template" element
     */
    boolean isNilTemplate();
    
    /**
     * True if has "Template" element
     */
    boolean isSetTemplate();
    
    /**
     * Sets the "Template" element
     */
    void setTemplate(org.datacontract.schemas._2004._07.vtdocsws_domain.Template template);
    
    /**
     * Appends and returns a new empty "Template" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.Template addNewTemplate();
    
    /**
     * Nils the "Template" element
     */
    void setNilTemplate();
    
    /**
     * Unsets the "Template" element
     */
    void unsetTemplate();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Document newInstance() {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Document) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Document newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Document) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Document parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Document) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Document parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Document) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Document parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Document) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Document parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Document) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Document parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Document) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Document parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Document) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Document parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Document) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Document parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Document) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Document parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Document) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Document parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Document) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Document parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Document) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Document parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Document) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Document parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Document) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Document parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Document) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Document parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Document) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Document parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Document) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
