/*
 * An XML document type.
 * Localname: EditPrjStateDiagramRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.EditPrjStateDiagram
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.impl;
/**
 * A document containing one EditPrjStateDiagramRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.EditPrjStateDiagram) element.
 *
 * This is a complex type.
 */
public class EditPrjStateDiagramRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramRequestDocument
{
    
    public EditPrjStateDiagramRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EDITPRJSTATEDIAGRAMREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.EditPrjStateDiagram", "EditPrjStateDiagramRequest");
    
    
    /**
     * Gets the "EditPrjStateDiagramRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramRequest getEditPrjStateDiagramRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramRequest)get_store().find_element_user(EDITPRJSTATEDIAGRAMREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "EditPrjStateDiagramRequest" element
     */
    public boolean isNilEditPrjStateDiagramRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramRequest)get_store().find_element_user(EDITPRJSTATEDIAGRAMREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "EditPrjStateDiagramRequest" element
     */
    public void setEditPrjStateDiagramRequest(org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramRequest editPrjStateDiagramRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramRequest)get_store().find_element_user(EDITPRJSTATEDIAGRAMREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramRequest)get_store().add_element_user(EDITPRJSTATEDIAGRAMREQUEST$0);
            }
            target.set(editPrjStateDiagramRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "EditPrjStateDiagramRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramRequest addNewEditPrjStateDiagramRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramRequest)get_store().add_element_user(EDITPRJSTATEDIAGRAMREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "EditPrjStateDiagramRequest" element
     */
    public void setNilEditPrjStateDiagramRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramRequest)get_store().find_element_user(EDITPRJSTATEDIAGRAMREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramRequest)get_store().add_element_user(EDITPRJSTATEDIAGRAMREQUEST$0);
            }
            target.setNil();
        }
    }
}
