/*
 * XML Type:  GetTemplatePrjRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetTemplatePrj
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_projects_gettemplateprj.GetTemplatePrjRequest
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_projects_gettemplateprj.impl;
/**
 * An XML GetTemplatePrjRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetTemplatePrj).
 *
 * This is a complex type.
 */
public class GetTemplatePrjRequestImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.RequestImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_projects_gettemplateprj.GetTemplatePrjRequest
{
    
    public GetTemplatePrjRequestImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DESCRIPTIONTEMPLATE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetTemplatePrj", "DescriptionTemplate");
    private static final javax.xml.namespace.QName IDTEMPLATE$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetTemplatePrj", "IdTemplate");
    
    
    /**
     * Gets the "DescriptionTemplate" element
     */
    public java.lang.String getDescriptionTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESCRIPTIONTEMPLATE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "DescriptionTemplate" element
     */
    public org.apache.xmlbeans.XmlString xgetDescriptionTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCRIPTIONTEMPLATE$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DescriptionTemplate" element
     */
    public boolean isNilDescriptionTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCRIPTIONTEMPLATE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DescriptionTemplate" element
     */
    public boolean isSetDescriptionTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DESCRIPTIONTEMPLATE$0) != 0;
        }
    }
    
    /**
     * Sets the "DescriptionTemplate" element
     */
    public void setDescriptionTemplate(java.lang.String descriptionTemplate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESCRIPTIONTEMPLATE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DESCRIPTIONTEMPLATE$0);
            }
            target.setStringValue(descriptionTemplate);
        }
    }
    
    /**
     * Sets (as xml) the "DescriptionTemplate" element
     */
    public void xsetDescriptionTemplate(org.apache.xmlbeans.XmlString descriptionTemplate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCRIPTIONTEMPLATE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DESCRIPTIONTEMPLATE$0);
            }
            target.set(descriptionTemplate);
        }
    }
    
    /**
     * Nils the "DescriptionTemplate" element
     */
    public void setNilDescriptionTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCRIPTIONTEMPLATE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DESCRIPTIONTEMPLATE$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DescriptionTemplate" element
     */
    public void unsetDescriptionTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DESCRIPTIONTEMPLATE$0, 0);
        }
    }
    
    /**
     * Gets the "IdTemplate" element
     */
    public java.lang.String getIdTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDTEMPLATE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "IdTemplate" element
     */
    public org.apache.xmlbeans.XmlString xgetIdTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDTEMPLATE$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "IdTemplate" element
     */
    public boolean isNilIdTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDTEMPLATE$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "IdTemplate" element
     */
    public boolean isSetIdTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(IDTEMPLATE$2) != 0;
        }
    }
    
    /**
     * Sets the "IdTemplate" element
     */
    public void setIdTemplate(java.lang.String idTemplate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDTEMPLATE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(IDTEMPLATE$2);
            }
            target.setStringValue(idTemplate);
        }
    }
    
    /**
     * Sets (as xml) the "IdTemplate" element
     */
    public void xsetIdTemplate(org.apache.xmlbeans.XmlString idTemplate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDTEMPLATE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(IDTEMPLATE$2);
            }
            target.set(idTemplate);
        }
    }
    
    /**
     * Nils the "IdTemplate" element
     */
    public void setNilIdTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDTEMPLATE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(IDTEMPLATE$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "IdTemplate" element
     */
    public void unsetIdTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(IDTEMPLATE$2, 0);
        }
    }
}
