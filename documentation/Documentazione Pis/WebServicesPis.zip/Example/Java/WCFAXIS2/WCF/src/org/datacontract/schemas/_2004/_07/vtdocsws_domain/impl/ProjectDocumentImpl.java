/*
 * An XML document type.
 * Localname: Project
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ProjectDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one Project(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class ProjectDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ProjectDocument
{
    
    public ProjectDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PROJECT$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Project");
    
    
    /**
     * Gets the "Project" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Project getProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Project target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Project)get_store().find_element_user(PROJECT$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Project" element
     */
    public boolean isNilProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Project target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Project)get_store().find_element_user(PROJECT$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "Project" element
     */
    public void setProject(org.datacontract.schemas._2004._07.vtdocsws_domain.Project project)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Project target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Project)get_store().find_element_user(PROJECT$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Project)get_store().add_element_user(PROJECT$0);
            }
            target.set(project);
        }
    }
    
    /**
     * Appends and returns a new empty "Project" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Project addNewProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Project target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Project)get_store().add_element_user(PROJECT$0);
            return target;
        }
    }
    
    /**
     * Nils the "Project" element
     */
    public void setNilProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Project target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Project)get_store().find_element_user(PROJECT$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Project)get_store().add_element_user(PROJECT$0);
            }
            target.setNil();
        }
    }
}
