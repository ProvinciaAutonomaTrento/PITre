/*
 * An XML document type.
 * Localname: GetProjectsByDocumentResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProjectsByDocument
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.impl;
/**
 * A document containing one GetProjectsByDocumentResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProjectsByDocument) element.
 *
 * This is a complex type.
 */
public class GetProjectsByDocumentResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentResponseDocument
{
    
    public GetProjectsByDocumentResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETPROJECTSBYDOCUMENTRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProjectsByDocument", "GetProjectsByDocumentResponse");
    
    
    /**
     * Gets the "GetProjectsByDocumentResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentResponse getGetProjectsByDocumentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentResponse)get_store().find_element_user(GETPROJECTSBYDOCUMENTRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetProjectsByDocumentResponse" element
     */
    public boolean isNilGetProjectsByDocumentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentResponse)get_store().find_element_user(GETPROJECTSBYDOCUMENTRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetProjectsByDocumentResponse" element
     */
    public void setGetProjectsByDocumentResponse(org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentResponse getProjectsByDocumentResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentResponse)get_store().find_element_user(GETPROJECTSBYDOCUMENTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentResponse)get_store().add_element_user(GETPROJECTSBYDOCUMENTRESPONSE$0);
            }
            target.set(getProjectsByDocumentResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "GetProjectsByDocumentResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentResponse addNewGetProjectsByDocumentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentResponse)get_store().add_element_user(GETPROJECTSBYDOCUMENTRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetProjectsByDocumentResponse" element
     */
    public void setNilGetProjectsByDocumentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentResponse)get_store().find_element_user(GETPROJECTSBYDOCUMENTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentResponse)get_store().add_element_user(GETPROJECTSBYDOCUMENTRESPONSE$0);
            }
            target.setNil();
        }
    }
}
