/*
 * An XML document type.
 * Localname: ArrayOfStateOfDiagram
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfStateOfDiagramDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one ArrayOfStateOfDiagram(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class ArrayOfStateOfDiagramDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfStateOfDiagramDocument
{
    
    public ArrayOfStateOfDiagramDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ARRAYOFSTATEOFDIAGRAM$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "ArrayOfStateOfDiagram");
    
    
    /**
     * Gets the "ArrayOfStateOfDiagram" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfStateOfDiagram getArrayOfStateOfDiagram()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfStateOfDiagram target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfStateOfDiagram)get_store().find_element_user(ARRAYOFSTATEOFDIAGRAM$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ArrayOfStateOfDiagram" element
     */
    public boolean isNilArrayOfStateOfDiagram()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfStateOfDiagram target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfStateOfDiagram)get_store().find_element_user(ARRAYOFSTATEOFDIAGRAM$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ArrayOfStateOfDiagram" element
     */
    public void setArrayOfStateOfDiagram(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfStateOfDiagram arrayOfStateOfDiagram)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfStateOfDiagram target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfStateOfDiagram)get_store().find_element_user(ARRAYOFSTATEOFDIAGRAM$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfStateOfDiagram)get_store().add_element_user(ARRAYOFSTATEOFDIAGRAM$0);
            }
            target.set(arrayOfStateOfDiagram);
        }
    }
    
    /**
     * Appends and returns a new empty "ArrayOfStateOfDiagram" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfStateOfDiagram addNewArrayOfStateOfDiagram()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfStateOfDiagram target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfStateOfDiagram)get_store().add_element_user(ARRAYOFSTATEOFDIAGRAM$0);
            return target;
        }
    }
    
    /**
     * Nils the "ArrayOfStateOfDiagram" element
     */
    public void setNilArrayOfStateOfDiagram()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfStateOfDiagram target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfStateOfDiagram)get_store().find_element_user(ARRAYOFSTATEOFDIAGRAM$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfStateOfDiagram)get_store().add_element_user(ARRAYOFSTATEOFDIAGRAM$0);
            }
            target.setNil();
        }
    }
}
