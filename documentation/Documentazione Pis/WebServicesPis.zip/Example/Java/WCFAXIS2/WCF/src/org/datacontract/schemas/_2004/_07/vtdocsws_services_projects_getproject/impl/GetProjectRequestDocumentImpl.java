/*
 * An XML document type.
 * Localname: GetProjectRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProject
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.impl;
/**
 * A document containing one GetProjectRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProject) element.
 *
 * This is a complex type.
 */
public class GetProjectRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequestDocument
{
    
    public GetProjectRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETPROJECTREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProject", "GetProjectRequest");
    
    
    /**
     * Gets the "GetProjectRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest getGetProjectRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest)get_store().find_element_user(GETPROJECTREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetProjectRequest" element
     */
    public boolean isNilGetProjectRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest)get_store().find_element_user(GETPROJECTREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetProjectRequest" element
     */
    public void setGetProjectRequest(org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest getProjectRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest)get_store().find_element_user(GETPROJECTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest)get_store().add_element_user(GETPROJECTREQUEST$0);
            }
            target.set(getProjectRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "GetProjectRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest addNewGetProjectRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest)get_store().add_element_user(GETPROJECTREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetProjectRequest" element
     */
    public void setNilGetProjectRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest)get_store().find_element_user(GETPROJECTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest)get_store().add_element_user(GETPROJECTREQUEST$0);
            }
            target.setNil();
        }
    }
}
