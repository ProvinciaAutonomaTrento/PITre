/*
 * XML Type:  Request
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services.Request
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services.impl;
/**
 * An XML Request(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services).
 *
 * This is a complex type.
 */
public class RequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services.Request
{
    
    public RequestImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName AUTHENTICATIONTOKEN$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services", "AuthenticationToken");
    private static final javax.xml.namespace.QName CODEADM$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services", "CodeAdm");
    private static final javax.xml.namespace.QName CODEAPPLICATION$4 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services", "CodeApplication");
    private static final javax.xml.namespace.QName CODEROLELOGIN$6 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services", "CodeRoleLogin");
    private static final javax.xml.namespace.QName USERNAME$8 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services", "UserName");
    
    
    /**
     * Gets the "AuthenticationToken" element
     */
    public java.lang.String getAuthenticationToken()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(AUTHENTICATIONTOKEN$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "AuthenticationToken" element
     */
    public org.apache.xmlbeans.XmlString xgetAuthenticationToken()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(AUTHENTICATIONTOKEN$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "AuthenticationToken" element
     */
    public boolean isNilAuthenticationToken()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(AUTHENTICATIONTOKEN$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "AuthenticationToken" element
     */
    public boolean isSetAuthenticationToken()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(AUTHENTICATIONTOKEN$0) != 0;
        }
    }
    
    /**
     * Sets the "AuthenticationToken" element
     */
    public void setAuthenticationToken(java.lang.String authenticationToken)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(AUTHENTICATIONTOKEN$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(AUTHENTICATIONTOKEN$0);
            }
            target.setStringValue(authenticationToken);
        }
    }
    
    /**
     * Sets (as xml) the "AuthenticationToken" element
     */
    public void xsetAuthenticationToken(org.apache.xmlbeans.XmlString authenticationToken)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(AUTHENTICATIONTOKEN$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(AUTHENTICATIONTOKEN$0);
            }
            target.set(authenticationToken);
        }
    }
    
    /**
     * Nils the "AuthenticationToken" element
     */
    public void setNilAuthenticationToken()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(AUTHENTICATIONTOKEN$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(AUTHENTICATIONTOKEN$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "AuthenticationToken" element
     */
    public void unsetAuthenticationToken()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(AUTHENTICATIONTOKEN$0, 0);
        }
    }
    
    /**
     * Gets the "CodeAdm" element
     */
    public java.lang.String getCodeAdm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODEADM$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodeAdm" element
     */
    public org.apache.xmlbeans.XmlString xgetCodeAdm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEADM$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CodeAdm" element
     */
    public boolean isNilCodeAdm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEADM$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CodeAdm" element
     */
    public boolean isSetCodeAdm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODEADM$2) != 0;
        }
    }
    
    /**
     * Sets the "CodeAdm" element
     */
    public void setCodeAdm(java.lang.String codeAdm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODEADM$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODEADM$2);
            }
            target.setStringValue(codeAdm);
        }
    }
    
    /**
     * Sets (as xml) the "CodeAdm" element
     */
    public void xsetCodeAdm(org.apache.xmlbeans.XmlString codeAdm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEADM$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODEADM$2);
            }
            target.set(codeAdm);
        }
    }
    
    /**
     * Nils the "CodeAdm" element
     */
    public void setNilCodeAdm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEADM$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODEADM$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CodeAdm" element
     */
    public void unsetCodeAdm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODEADM$2, 0);
        }
    }
    
    /**
     * Gets the "CodeApplication" element
     */
    public java.lang.String getCodeApplication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODEAPPLICATION$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodeApplication" element
     */
    public org.apache.xmlbeans.XmlString xgetCodeApplication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEAPPLICATION$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CodeApplication" element
     */
    public boolean isNilCodeApplication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEAPPLICATION$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CodeApplication" element
     */
    public boolean isSetCodeApplication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODEAPPLICATION$4) != 0;
        }
    }
    
    /**
     * Sets the "CodeApplication" element
     */
    public void setCodeApplication(java.lang.String codeApplication)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODEAPPLICATION$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODEAPPLICATION$4);
            }
            target.setStringValue(codeApplication);
        }
    }
    
    /**
     * Sets (as xml) the "CodeApplication" element
     */
    public void xsetCodeApplication(org.apache.xmlbeans.XmlString codeApplication)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEAPPLICATION$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODEAPPLICATION$4);
            }
            target.set(codeApplication);
        }
    }
    
    /**
     * Nils the "CodeApplication" element
     */
    public void setNilCodeApplication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEAPPLICATION$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODEAPPLICATION$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CodeApplication" element
     */
    public void unsetCodeApplication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODEAPPLICATION$4, 0);
        }
    }
    
    /**
     * Gets the "CodeRoleLogin" element
     */
    public java.lang.String getCodeRoleLogin()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODEROLELOGIN$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodeRoleLogin" element
     */
    public org.apache.xmlbeans.XmlString xgetCodeRoleLogin()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEROLELOGIN$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CodeRoleLogin" element
     */
    public boolean isNilCodeRoleLogin()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEROLELOGIN$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CodeRoleLogin" element
     */
    public boolean isSetCodeRoleLogin()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODEROLELOGIN$6) != 0;
        }
    }
    
    /**
     * Sets the "CodeRoleLogin" element
     */
    public void setCodeRoleLogin(java.lang.String codeRoleLogin)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODEROLELOGIN$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODEROLELOGIN$6);
            }
            target.setStringValue(codeRoleLogin);
        }
    }
    
    /**
     * Sets (as xml) the "CodeRoleLogin" element
     */
    public void xsetCodeRoleLogin(org.apache.xmlbeans.XmlString codeRoleLogin)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEROLELOGIN$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODEROLELOGIN$6);
            }
            target.set(codeRoleLogin);
        }
    }
    
    /**
     * Nils the "CodeRoleLogin" element
     */
    public void setNilCodeRoleLogin()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEROLELOGIN$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODEROLELOGIN$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CodeRoleLogin" element
     */
    public void unsetCodeRoleLogin()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODEROLELOGIN$6, 0);
        }
    }
    
    /**
     * Gets the "UserName" element
     */
    public java.lang.String getUserName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(USERNAME$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "UserName" element
     */
    public org.apache.xmlbeans.XmlString xgetUserName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(USERNAME$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "UserName" element
     */
    public boolean isNilUserName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(USERNAME$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "UserName" element
     */
    public boolean isSetUserName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(USERNAME$8) != 0;
        }
    }
    
    /**
     * Sets the "UserName" element
     */
    public void setUserName(java.lang.String userName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(USERNAME$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(USERNAME$8);
            }
            target.setStringValue(userName);
        }
    }
    
    /**
     * Sets (as xml) the "UserName" element
     */
    public void xsetUserName(org.apache.xmlbeans.XmlString userName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(USERNAME$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(USERNAME$8);
            }
            target.set(userName);
        }
    }
    
    /**
     * Nils the "UserName" element
     */
    public void setNilUserName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(USERNAME$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(USERNAME$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "UserName" element
     */
    public void unsetUserName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(USERNAME$8, 0);
        }
    }
}
