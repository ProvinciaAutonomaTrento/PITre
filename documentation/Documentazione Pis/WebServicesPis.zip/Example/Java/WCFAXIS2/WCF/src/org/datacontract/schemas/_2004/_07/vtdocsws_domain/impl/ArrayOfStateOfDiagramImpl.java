/*
 * XML Type:  ArrayOfStateOfDiagram
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfStateOfDiagram
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * An XML ArrayOfStateOfDiagram(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain).
 *
 * This is a complex type.
 */
public class ArrayOfStateOfDiagramImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfStateOfDiagram
{
    
    public ArrayOfStateOfDiagramImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName STATEOFDIAGRAM$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "StateOfDiagram");
    
    
    /**
     * Gets array of all "StateOfDiagram" elements
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram[] getStateOfDiagramArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(STATEOFDIAGRAM$0, targetList);
            org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram[] result = new org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "StateOfDiagram" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram getStateOfDiagramArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram)get_store().find_element_user(STATEOFDIAGRAM$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Tests for nil ith "StateOfDiagram" element
     */
    public boolean isNilStateOfDiagramArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram)get_store().find_element_user(STATEOFDIAGRAM$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "StateOfDiagram" element
     */
    public int sizeOfStateOfDiagramArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(STATEOFDIAGRAM$0);
        }
    }
    
    /**
     * Sets array of all "StateOfDiagram" element
     */
    public void setStateOfDiagramArray(org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram[] stateOfDiagramArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(stateOfDiagramArray, STATEOFDIAGRAM$0);
        }
    }
    
    /**
     * Sets ith "StateOfDiagram" element
     */
    public void setStateOfDiagramArray(int i, org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram stateOfDiagram)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram)get_store().find_element_user(STATEOFDIAGRAM$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(stateOfDiagram);
        }
    }
    
    /**
     * Nils the ith "StateOfDiagram" element
     */
    public void setNilStateOfDiagramArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram)get_store().find_element_user(STATEOFDIAGRAM$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "StateOfDiagram" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram insertNewStateOfDiagram(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram)get_store().insert_element_user(STATEOFDIAGRAM$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "StateOfDiagram" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram addNewStateOfDiagram()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram)get_store().add_element_user(STATEOFDIAGRAM$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "StateOfDiagram" element
     */
    public void removeStateOfDiagram(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(STATEOFDIAGRAM$0, i);
        }
    }
}
