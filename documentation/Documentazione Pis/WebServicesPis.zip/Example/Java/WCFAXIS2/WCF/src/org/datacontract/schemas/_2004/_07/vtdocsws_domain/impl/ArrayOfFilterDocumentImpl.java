/*
 * An XML document type.
 * Localname: ArrayOfFilter
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilterDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one ArrayOfFilter(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class ArrayOfFilterDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilterDocument
{
    
    public ArrayOfFilterDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ARRAYOFFILTER$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "ArrayOfFilter");
    
    
    /**
     * Gets the "ArrayOfFilter" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter getArrayOfFilter()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter)get_store().find_element_user(ARRAYOFFILTER$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ArrayOfFilter" element
     */
    public boolean isNilArrayOfFilter()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter)get_store().find_element_user(ARRAYOFFILTER$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ArrayOfFilter" element
     */
    public void setArrayOfFilter(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter arrayOfFilter)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter)get_store().find_element_user(ARRAYOFFILTER$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter)get_store().add_element_user(ARRAYOFFILTER$0);
            }
            target.set(arrayOfFilter);
        }
    }
    
    /**
     * Appends and returns a new empty "ArrayOfFilter" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter addNewArrayOfFilter()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter)get_store().add_element_user(ARRAYOFFILTER$0);
            return target;
        }
    }
    
    /**
     * Nils the "ArrayOfFilter" element
     */
    public void setNilArrayOfFilter()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter)get_store().find_element_user(ARRAYOFFILTER$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter)get_store().add_element_user(ARRAYOFFILTER$0);
            }
            target.setNil();
        }
    }
}
