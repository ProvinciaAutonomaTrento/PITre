/*
 * XML Type:  EditPrjStateDiagramResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.EditPrjStateDiagram
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramResponse
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.impl;
/**
 * An XML EditPrjStateDiagramResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.EditPrjStateDiagram).
 *
 * This is a complex type.
 */
public class EditPrjStateDiagramResponseImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.ResponseImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_projects_editprjstatediagram.EditPrjStateDiagramResponse
{
    
    public EditPrjStateDiagramResponseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
