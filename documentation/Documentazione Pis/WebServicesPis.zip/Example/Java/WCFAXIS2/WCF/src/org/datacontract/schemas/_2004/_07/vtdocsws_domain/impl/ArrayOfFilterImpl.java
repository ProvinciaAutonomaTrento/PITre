/*
 * XML Type:  ArrayOfFilter
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * An XML ArrayOfFilter(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain).
 *
 * This is a complex type.
 */
public class ArrayOfFilterImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFilter
{
    
    public ArrayOfFilterImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName FILTER$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Filter");
    
    
    /**
     * Gets array of all "Filter" elements
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Filter[] getFilterArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(FILTER$0, targetList);
            org.datacontract.schemas._2004._07.vtdocsws_domain.Filter[] result = new org.datacontract.schemas._2004._07.vtdocsws_domain.Filter[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "Filter" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Filter getFilterArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Filter target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Filter)get_store().find_element_user(FILTER$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Tests for nil ith "Filter" element
     */
    public boolean isNilFilterArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Filter target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Filter)get_store().find_element_user(FILTER$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "Filter" element
     */
    public int sizeOfFilterArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FILTER$0);
        }
    }
    
    /**
     * Sets array of all "Filter" element
     */
    public void setFilterArray(org.datacontract.schemas._2004._07.vtdocsws_domain.Filter[] filterArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(filterArray, FILTER$0);
        }
    }
    
    /**
     * Sets ith "Filter" element
     */
    public void setFilterArray(int i, org.datacontract.schemas._2004._07.vtdocsws_domain.Filter filter)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Filter target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Filter)get_store().find_element_user(FILTER$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(filter);
        }
    }
    
    /**
     * Nils the ith "Filter" element
     */
    public void setNilFilterArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Filter target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Filter)get_store().find_element_user(FILTER$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "Filter" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Filter insertNewFilter(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Filter target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Filter)get_store().insert_element_user(FILTER$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "Filter" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Filter addNewFilter()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Filter target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Filter)get_store().add_element_user(FILTER$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "Filter" element
     */
    public void removeFilter(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FILTER$0, i);
        }
    }
}
