/*
 * An XML document type.
 * Localname: UploadFileToDocumentResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.UploadFileToDocument
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.impl;
/**
 * A document containing one UploadFileToDocumentResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.UploadFileToDocument) element.
 *
 * This is a complex type.
 */
public class UploadFileToDocumentResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentResponseDocument
{
    
    public UploadFileToDocumentResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName UPLOADFILETODOCUMENTRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.UploadFileToDocument", "UploadFileToDocumentResponse");
    
    
    /**
     * Gets the "UploadFileToDocumentResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentResponse getUploadFileToDocumentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentResponse)get_store().find_element_user(UPLOADFILETODOCUMENTRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "UploadFileToDocumentResponse" element
     */
    public boolean isNilUploadFileToDocumentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentResponse)get_store().find_element_user(UPLOADFILETODOCUMENTRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "UploadFileToDocumentResponse" element
     */
    public void setUploadFileToDocumentResponse(org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentResponse uploadFileToDocumentResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentResponse)get_store().find_element_user(UPLOADFILETODOCUMENTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentResponse)get_store().add_element_user(UPLOADFILETODOCUMENTRESPONSE$0);
            }
            target.set(uploadFileToDocumentResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "UploadFileToDocumentResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentResponse addNewUploadFileToDocumentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentResponse)get_store().add_element_user(UPLOADFILETODOCUMENTRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "UploadFileToDocumentResponse" element
     */
    public void setNilUploadFileToDocumentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentResponse)get_store().find_element_user(UPLOADFILETODOCUMENTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentResponse)get_store().add_element_user(UPLOADFILETODOCUMENTRESPONSE$0);
            }
            target.setNil();
        }
    }
}
