/*
 * XML Type:  UploadFileToDocumentRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.UploadFileToDocument
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentRequest
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.impl;
/**
 * An XML UploadFileToDocumentRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.UploadFileToDocument).
 *
 * This is a complex type.
 */
public class UploadFileToDocumentRequestImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.RequestImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentRequest
{
    
    public UploadFileToDocumentRequestImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName COVERTTOPDFA$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.UploadFileToDocument", "CovertToPDFA");
    private static final javax.xml.namespace.QName CREATEATTACHMENT$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.UploadFileToDocument", "CreateAttachment");
    private static final javax.xml.namespace.QName DESCRIPTION$4 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.UploadFileToDocument", "Description");
    private static final javax.xml.namespace.QName FILE$6 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.UploadFileToDocument", "File");
    private static final javax.xml.namespace.QName IDDOCUMENT$8 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.UploadFileToDocument", "IdDocument");
    
    
    /**
     * Gets the "CovertToPDFA" element
     */
    public boolean getCovertToPDFA()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(COVERTTOPDFA$0, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "CovertToPDFA" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetCovertToPDFA()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(COVERTTOPDFA$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "CovertToPDFA" element
     */
    public boolean isSetCovertToPDFA()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(COVERTTOPDFA$0) != 0;
        }
    }
    
    /**
     * Sets the "CovertToPDFA" element
     */
    public void setCovertToPDFA(boolean covertToPDFA)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(COVERTTOPDFA$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(COVERTTOPDFA$0);
            }
            target.setBooleanValue(covertToPDFA);
        }
    }
    
    /**
     * Sets (as xml) the "CovertToPDFA" element
     */
    public void xsetCovertToPDFA(org.apache.xmlbeans.XmlBoolean covertToPDFA)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(COVERTTOPDFA$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(COVERTTOPDFA$0);
            }
            target.set(covertToPDFA);
        }
    }
    
    /**
     * Unsets the "CovertToPDFA" element
     */
    public void unsetCovertToPDFA()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(COVERTTOPDFA$0, 0);
        }
    }
    
    /**
     * Gets the "CreateAttachment" element
     */
    public boolean getCreateAttachment()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CREATEATTACHMENT$2, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "CreateAttachment" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetCreateAttachment()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(CREATEATTACHMENT$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "CreateAttachment" element
     */
    public boolean isSetCreateAttachment()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CREATEATTACHMENT$2) != 0;
        }
    }
    
    /**
     * Sets the "CreateAttachment" element
     */
    public void setCreateAttachment(boolean createAttachment)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CREATEATTACHMENT$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CREATEATTACHMENT$2);
            }
            target.setBooleanValue(createAttachment);
        }
    }
    
    /**
     * Sets (as xml) the "CreateAttachment" element
     */
    public void xsetCreateAttachment(org.apache.xmlbeans.XmlBoolean createAttachment)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(CREATEATTACHMENT$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(CREATEATTACHMENT$2);
            }
            target.set(createAttachment);
        }
    }
    
    /**
     * Unsets the "CreateAttachment" element
     */
    public void unsetCreateAttachment()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CREATEATTACHMENT$2, 0);
        }
    }
    
    /**
     * Gets the "Description" element
     */
    public java.lang.String getDescription()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESCRIPTION$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Description" element
     */
    public org.apache.xmlbeans.XmlString xgetDescription()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCRIPTION$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Description" element
     */
    public boolean isNilDescription()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCRIPTION$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Description" element
     */
    public boolean isSetDescription()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DESCRIPTION$4) != 0;
        }
    }
    
    /**
     * Sets the "Description" element
     */
    public void setDescription(java.lang.String description)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESCRIPTION$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DESCRIPTION$4);
            }
            target.setStringValue(description);
        }
    }
    
    /**
     * Sets (as xml) the "Description" element
     */
    public void xsetDescription(org.apache.xmlbeans.XmlString description)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCRIPTION$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DESCRIPTION$4);
            }
            target.set(description);
        }
    }
    
    /**
     * Nils the "Description" element
     */
    public void setNilDescription()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCRIPTION$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DESCRIPTION$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Description" element
     */
    public void unsetDescription()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DESCRIPTION$4, 0);
        }
    }
    
    /**
     * Gets the "File" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.File getFile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().find_element_user(FILE$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "File" element
     */
    public boolean isNilFile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().find_element_user(FILE$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "File" element
     */
    public boolean isSetFile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FILE$6) != 0;
        }
    }
    
    /**
     * Sets the "File" element
     */
    public void setFile(org.datacontract.schemas._2004._07.vtdocsws_domain.File file)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().find_element_user(FILE$6, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().add_element_user(FILE$6);
            }
            target.set(file);
        }
    }
    
    /**
     * Appends and returns a new empty "File" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.File addNewFile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().add_element_user(FILE$6);
            return target;
        }
    }
    
    /**
     * Nils the "File" element
     */
    public void setNilFile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().find_element_user(FILE$6, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().add_element_user(FILE$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "File" element
     */
    public void unsetFile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FILE$6, 0);
        }
    }
    
    /**
     * Gets the "IdDocument" element
     */
    public java.lang.String getIdDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDDOCUMENT$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "IdDocument" element
     */
    public org.apache.xmlbeans.XmlString xgetIdDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDDOCUMENT$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "IdDocument" element
     */
    public boolean isNilIdDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDDOCUMENT$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "IdDocument" element
     */
    public boolean isSetIdDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(IDDOCUMENT$8) != 0;
        }
    }
    
    /**
     * Sets the "IdDocument" element
     */
    public void setIdDocument(java.lang.String idDocument)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDDOCUMENT$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(IDDOCUMENT$8);
            }
            target.setStringValue(idDocument);
        }
    }
    
    /**
     * Sets (as xml) the "IdDocument" element
     */
    public void xsetIdDocument(org.apache.xmlbeans.XmlString idDocument)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDDOCUMENT$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(IDDOCUMENT$8);
            }
            target.set(idDocument);
        }
    }
    
    /**
     * Nils the "IdDocument" element
     */
    public void setNilIdDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDDOCUMENT$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(IDDOCUMENT$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "IdDocument" element
     */
    public void unsetIdDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(IDDOCUMENT$8, 0);
        }
    }
}
