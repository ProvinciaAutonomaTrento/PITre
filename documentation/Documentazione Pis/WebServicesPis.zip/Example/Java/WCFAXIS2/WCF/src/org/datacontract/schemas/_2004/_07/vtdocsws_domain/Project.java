/*
 * XML Type:  Project
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.Project
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain;


/**
 * An XML Project(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain).
 *
 * This is a complex type.
 */
public interface Project extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(Project.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s4E8A12153D12D8BC5B823C971B9DCCB1").resolveHandle("project0fe3type");
    
    /**
     * Gets the "ClassificationScheme" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme getClassificationScheme();
    
    /**
     * Tests for nil "ClassificationScheme" element
     */
    boolean isNilClassificationScheme();
    
    /**
     * True if has "ClassificationScheme" element
     */
    boolean isSetClassificationScheme();
    
    /**
     * Sets the "ClassificationScheme" element
     */
    void setClassificationScheme(org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme classificationScheme);
    
    /**
     * Appends and returns a new empty "ClassificationScheme" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme addNewClassificationScheme();
    
    /**
     * Nils the "ClassificationScheme" element
     */
    void setNilClassificationScheme();
    
    /**
     * Unsets the "ClassificationScheme" element
     */
    void unsetClassificationScheme();
    
    /**
     * Gets the "ClosureDate" element
     */
    java.lang.String getClosureDate();
    
    /**
     * Gets (as xml) the "ClosureDate" element
     */
    org.apache.xmlbeans.XmlString xgetClosureDate();
    
    /**
     * Tests for nil "ClosureDate" element
     */
    boolean isNilClosureDate();
    
    /**
     * True if has "ClosureDate" element
     */
    boolean isSetClosureDate();
    
    /**
     * Sets the "ClosureDate" element
     */
    void setClosureDate(java.lang.String closureDate);
    
    /**
     * Sets (as xml) the "ClosureDate" element
     */
    void xsetClosureDate(org.apache.xmlbeans.XmlString closureDate);
    
    /**
     * Nils the "ClosureDate" element
     */
    void setNilClosureDate();
    
    /**
     * Unsets the "ClosureDate" element
     */
    void unsetClosureDate();
    
    /**
     * Gets the "Code" element
     */
    java.lang.String getCode();
    
    /**
     * Gets (as xml) the "Code" element
     */
    org.apache.xmlbeans.XmlString xgetCode();
    
    /**
     * Tests for nil "Code" element
     */
    boolean isNilCode();
    
    /**
     * True if has "Code" element
     */
    boolean isSetCode();
    
    /**
     * Sets the "Code" element
     */
    void setCode(java.lang.String code);
    
    /**
     * Sets (as xml) the "Code" element
     */
    void xsetCode(org.apache.xmlbeans.XmlString code);
    
    /**
     * Nils the "Code" element
     */
    void setNilCode();
    
    /**
     * Unsets the "Code" element
     */
    void unsetCode();
    
    /**
     * Gets the "CodeNodeClassification" element
     */
    java.lang.String getCodeNodeClassification();
    
    /**
     * Gets (as xml) the "CodeNodeClassification" element
     */
    org.apache.xmlbeans.XmlString xgetCodeNodeClassification();
    
    /**
     * Tests for nil "CodeNodeClassification" element
     */
    boolean isNilCodeNodeClassification();
    
    /**
     * True if has "CodeNodeClassification" element
     */
    boolean isSetCodeNodeClassification();
    
    /**
     * Sets the "CodeNodeClassification" element
     */
    void setCodeNodeClassification(java.lang.String codeNodeClassification);
    
    /**
     * Sets (as xml) the "CodeNodeClassification" element
     */
    void xsetCodeNodeClassification(org.apache.xmlbeans.XmlString codeNodeClassification);
    
    /**
     * Nils the "CodeNodeClassification" element
     */
    void setNilCodeNodeClassification();
    
    /**
     * Unsets the "CodeNodeClassification" element
     */
    void unsetCodeNodeClassification();
    
    /**
     * Gets the "CollocationDate" element
     */
    java.lang.String getCollocationDate();
    
    /**
     * Gets (as xml) the "CollocationDate" element
     */
    org.apache.xmlbeans.XmlString xgetCollocationDate();
    
    /**
     * Tests for nil "CollocationDate" element
     */
    boolean isNilCollocationDate();
    
    /**
     * True if has "CollocationDate" element
     */
    boolean isSetCollocationDate();
    
    /**
     * Sets the "CollocationDate" element
     */
    void setCollocationDate(java.lang.String collocationDate);
    
    /**
     * Sets (as xml) the "CollocationDate" element
     */
    void xsetCollocationDate(org.apache.xmlbeans.XmlString collocationDate);
    
    /**
     * Nils the "CollocationDate" element
     */
    void setNilCollocationDate();
    
    /**
     * Unsets the "CollocationDate" element
     */
    void unsetCollocationDate();
    
    /**
     * Gets the "Controlled" element
     */
    boolean getControlled();
    
    /**
     * Gets (as xml) the "Controlled" element
     */
    org.apache.xmlbeans.XmlBoolean xgetControlled();
    
    /**
     * True if has "Controlled" element
     */
    boolean isSetControlled();
    
    /**
     * Sets the "Controlled" element
     */
    void setControlled(boolean controlled);
    
    /**
     * Sets (as xml) the "Controlled" element
     */
    void xsetControlled(org.apache.xmlbeans.XmlBoolean controlled);
    
    /**
     * Unsets the "Controlled" element
     */
    void unsetControlled();
    
    /**
     * Gets the "CreationDate" element
     */
    java.lang.String getCreationDate();
    
    /**
     * Gets (as xml) the "CreationDate" element
     */
    org.apache.xmlbeans.XmlString xgetCreationDate();
    
    /**
     * Tests for nil "CreationDate" element
     */
    boolean isNilCreationDate();
    
    /**
     * True if has "CreationDate" element
     */
    boolean isSetCreationDate();
    
    /**
     * Sets the "CreationDate" element
     */
    void setCreationDate(java.lang.String creationDate);
    
    /**
     * Sets (as xml) the "CreationDate" element
     */
    void xsetCreationDate(org.apache.xmlbeans.XmlString creationDate);
    
    /**
     * Nils the "CreationDate" element
     */
    void setNilCreationDate();
    
    /**
     * Unsets the "CreationDate" element
     */
    void unsetCreationDate();
    
    /**
     * Gets the "Description" element
     */
    java.lang.String getDescription();
    
    /**
     * Gets (as xml) the "Description" element
     */
    org.apache.xmlbeans.XmlString xgetDescription();
    
    /**
     * Tests for nil "Description" element
     */
    boolean isNilDescription();
    
    /**
     * True if has "Description" element
     */
    boolean isSetDescription();
    
    /**
     * Sets the "Description" element
     */
    void setDescription(java.lang.String description);
    
    /**
     * Sets (as xml) the "Description" element
     */
    void xsetDescription(org.apache.xmlbeans.XmlString description);
    
    /**
     * Nils the "Description" element
     */
    void setNilDescription();
    
    /**
     * Unsets the "Description" element
     */
    void unsetDescription();
    
    /**
     * Gets the "Id" element
     */
    java.lang.String getId();
    
    /**
     * Gets (as xml) the "Id" element
     */
    org.apache.xmlbeans.XmlString xgetId();
    
    /**
     * Tests for nil "Id" element
     */
    boolean isNilId();
    
    /**
     * True if has "Id" element
     */
    boolean isSetId();
    
    /**
     * Sets the "Id" element
     */
    void setId(java.lang.String id);
    
    /**
     * Sets (as xml) the "Id" element
     */
    void xsetId(org.apache.xmlbeans.XmlString id);
    
    /**
     * Nils the "Id" element
     */
    void setNilId();
    
    /**
     * Unsets the "Id" element
     */
    void unsetId();
    
    /**
     * Gets the "IdParent" element
     */
    java.lang.String getIdParent();
    
    /**
     * Gets (as xml) the "IdParent" element
     */
    org.apache.xmlbeans.XmlString xgetIdParent();
    
    /**
     * Tests for nil "IdParent" element
     */
    boolean isNilIdParent();
    
    /**
     * True if has "IdParent" element
     */
    boolean isSetIdParent();
    
    /**
     * Sets the "IdParent" element
     */
    void setIdParent(java.lang.String idParent);
    
    /**
     * Sets (as xml) the "IdParent" element
     */
    void xsetIdParent(org.apache.xmlbeans.XmlString idParent);
    
    /**
     * Nils the "IdParent" element
     */
    void setNilIdParent();
    
    /**
     * Unsets the "IdParent" element
     */
    void unsetIdParent();
    
    /**
     * Gets the "Note" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote getNote();
    
    /**
     * Tests for nil "Note" element
     */
    boolean isNilNote();
    
    /**
     * True if has "Note" element
     */
    boolean isSetNote();
    
    /**
     * Sets the "Note" element
     */
    void setNote(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote note);
    
    /**
     * Appends and returns a new empty "Note" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote addNewNote();
    
    /**
     * Nils the "Note" element
     */
    void setNilNote();
    
    /**
     * Unsets the "Note" element
     */
    void unsetNote();
    
    /**
     * Gets the "Number" element
     */
    java.lang.String getNumber();
    
    /**
     * Gets (as xml) the "Number" element
     */
    org.apache.xmlbeans.XmlString xgetNumber();
    
    /**
     * Tests for nil "Number" element
     */
    boolean isNilNumber();
    
    /**
     * True if has "Number" element
     */
    boolean isSetNumber();
    
    /**
     * Sets the "Number" element
     */
    void setNumber(java.lang.String number);
    
    /**
     * Sets (as xml) the "Number" element
     */
    void xsetNumber(org.apache.xmlbeans.XmlString number);
    
    /**
     * Nils the "Number" element
     */
    void setNilNumber();
    
    /**
     * Unsets the "Number" element
     */
    void unsetNumber();
    
    /**
     * Gets the "Open" element
     */
    boolean getOpen();
    
    /**
     * Gets (as xml) the "Open" element
     */
    org.apache.xmlbeans.XmlBoolean xgetOpen();
    
    /**
     * True if has "Open" element
     */
    boolean isSetOpen();
    
    /**
     * Sets the "Open" element
     */
    void setOpen(boolean open);
    
    /**
     * Sets (as xml) the "Open" element
     */
    void xsetOpen(org.apache.xmlbeans.XmlBoolean open);
    
    /**
     * Unsets the "Open" element
     */
    void unsetOpen();
    
    /**
     * Gets the "Paper" element
     */
    boolean getPaper();
    
    /**
     * Gets (as xml) the "Paper" element
     */
    org.apache.xmlbeans.XmlBoolean xgetPaper();
    
    /**
     * True if has "Paper" element
     */
    boolean isSetPaper();
    
    /**
     * Sets the "Paper" element
     */
    void setPaper(boolean paper);
    
    /**
     * Sets (as xml) the "Paper" element
     */
    void xsetPaper(org.apache.xmlbeans.XmlBoolean paper);
    
    /**
     * Unsets the "Paper" element
     */
    void unsetPaper();
    
    /**
     * Gets the "PhysicsCollocation" element
     */
    java.lang.String getPhysicsCollocation();
    
    /**
     * Gets (as xml) the "PhysicsCollocation" element
     */
    org.apache.xmlbeans.XmlString xgetPhysicsCollocation();
    
    /**
     * Tests for nil "PhysicsCollocation" element
     */
    boolean isNilPhysicsCollocation();
    
    /**
     * True if has "PhysicsCollocation" element
     */
    boolean isSetPhysicsCollocation();
    
    /**
     * Sets the "PhysicsCollocation" element
     */
    void setPhysicsCollocation(java.lang.String physicsCollocation);
    
    /**
     * Sets (as xml) the "PhysicsCollocation" element
     */
    void xsetPhysicsCollocation(org.apache.xmlbeans.XmlString physicsCollocation);
    
    /**
     * Nils the "PhysicsCollocation" element
     */
    void setNilPhysicsCollocation();
    
    /**
     * Unsets the "PhysicsCollocation" element
     */
    void unsetPhysicsCollocation();
    
    /**
     * Gets the "Private" element
     */
    boolean getPrivate();
    
    /**
     * Gets (as xml) the "Private" element
     */
    org.apache.xmlbeans.XmlBoolean xgetPrivate();
    
    /**
     * True if has "Private" element
     */
    boolean isSetPrivate();
    
    /**
     * Sets the "Private" element
     */
    void setPrivate(boolean xprivate);
    
    /**
     * Sets (as xml) the "Private" element
     */
    void xsetPrivate(org.apache.xmlbeans.XmlBoolean xprivate);
    
    /**
     * Unsets the "Private" element
     */
    void unsetPrivate();
    
    /**
     * Gets the "Register" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.Register getRegister();
    
    /**
     * Tests for nil "Register" element
     */
    boolean isNilRegister();
    
    /**
     * True if has "Register" element
     */
    boolean isSetRegister();
    
    /**
     * Sets the "Register" element
     */
    void setRegister(org.datacontract.schemas._2004._07.vtdocsws_domain.Register register);
    
    /**
     * Appends and returns a new empty "Register" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.Register addNewRegister();
    
    /**
     * Nils the "Register" element
     */
    void setNilRegister();
    
    /**
     * Unsets the "Register" element
     */
    void unsetRegister();
    
    /**
     * Gets the "Template" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.Template getTemplate();
    
    /**
     * Tests for nil "Template" element
     */
    boolean isNilTemplate();
    
    /**
     * True if has "Template" element
     */
    boolean isSetTemplate();
    
    /**
     * Sets the "Template" element
     */
    void setTemplate(org.datacontract.schemas._2004._07.vtdocsws_domain.Template template);
    
    /**
     * Appends and returns a new empty "Template" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.Template addNewTemplate();
    
    /**
     * Nils the "Template" element
     */
    void setNilTemplate();
    
    /**
     * Unsets the "Template" element
     */
    void unsetTemplate();
    
    /**
     * Gets the "Type" element
     */
    java.lang.String getType();
    
    /**
     * Gets (as xml) the "Type" element
     */
    org.apache.xmlbeans.XmlString xgetType();
    
    /**
     * Tests for nil "Type" element
     */
    boolean isNilType();
    
    /**
     * True if has "Type" element
     */
    boolean isSetType();
    
    /**
     * Sets the "Type" element
     */
    void setType(java.lang.String type);
    
    /**
     * Sets (as xml) the "Type" element
     */
    void xsetType(org.apache.xmlbeans.XmlString type);
    
    /**
     * Nils the "Type" element
     */
    void setNilType();
    
    /**
     * Unsets the "Type" element
     */
    void unsetType();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Project newInstance() {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Project) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Project newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Project) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Project parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Project) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Project parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Project) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Project parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Project) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Project parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Project) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Project parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Project) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Project parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Project) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Project parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Project) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Project parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Project) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Project parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Project) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Project parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Project) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Project parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Project) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Project parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Project) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Project parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Project) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Project parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Project) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Project parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Project) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Project parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Project) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
