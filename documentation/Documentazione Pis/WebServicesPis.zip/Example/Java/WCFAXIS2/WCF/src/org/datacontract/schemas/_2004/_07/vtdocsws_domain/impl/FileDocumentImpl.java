/*
 * An XML document type.
 * Localname: File
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.FileDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one File(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class FileDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.FileDocument
{
    
    public FileDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName FILE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "File");
    
    
    /**
     * Gets the "File" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.File getFile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().find_element_user(FILE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "File" element
     */
    public boolean isNilFile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().find_element_user(FILE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "File" element
     */
    public void setFile(org.datacontract.schemas._2004._07.vtdocsws_domain.File file)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().find_element_user(FILE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().add_element_user(FILE$0);
            }
            target.set(file);
        }
    }
    
    /**
     * Appends and returns a new empty "File" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.File addNewFile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().add_element_user(FILE$0);
            return target;
        }
    }
    
    /**
     * Nils the "File" element
     */
    public void setNilFile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().find_element_user(FILE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().add_element_user(FILE$0);
            }
            target.setNil();
        }
    }
}
