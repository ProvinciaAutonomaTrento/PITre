/*
 * An XML document type.
 * Localname: AddDocInProjectRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.AddDocInProject
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.impl;
/**
 * A document containing one AddDocInProjectRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.AddDocInProject) element.
 *
 * This is a complex type.
 */
public class AddDocInProjectRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectRequestDocument
{
    
    public AddDocInProjectRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ADDDOCINPROJECTREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.AddDocInProject", "AddDocInProjectRequest");
    
    
    /**
     * Gets the "AddDocInProjectRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectRequest getAddDocInProjectRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectRequest)get_store().find_element_user(ADDDOCINPROJECTREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "AddDocInProjectRequest" element
     */
    public boolean isNilAddDocInProjectRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectRequest)get_store().find_element_user(ADDDOCINPROJECTREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "AddDocInProjectRequest" element
     */
    public void setAddDocInProjectRequest(org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectRequest addDocInProjectRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectRequest)get_store().find_element_user(ADDDOCINPROJECTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectRequest)get_store().add_element_user(ADDDOCINPROJECTREQUEST$0);
            }
            target.set(addDocInProjectRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "AddDocInProjectRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectRequest addNewAddDocInProjectRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectRequest)get_store().add_element_user(ADDDOCINPROJECTREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "AddDocInProjectRequest" element
     */
    public void setNilAddDocInProjectRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectRequest)get_store().find_element_user(ADDDOCINPROJECTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectRequest)get_store().add_element_user(ADDDOCINPROJECTREQUEST$0);
            }
            target.setNil();
        }
    }
}
