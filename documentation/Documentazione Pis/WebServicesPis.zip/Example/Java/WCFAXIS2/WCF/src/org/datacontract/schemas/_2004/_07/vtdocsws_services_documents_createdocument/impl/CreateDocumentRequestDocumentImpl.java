/*
 * An XML document type.
 * Localname: CreateDocumentRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.CreateDocument
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.impl;
/**
 * A document containing one CreateDocumentRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.CreateDocument) element.
 *
 * This is a complex type.
 */
public class CreateDocumentRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequestDocument
{
    
    public CreateDocumentRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CREATEDOCUMENTREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.CreateDocument", "CreateDocumentRequest");
    
    
    /**
     * Gets the "CreateDocumentRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest getCreateDocumentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest)get_store().find_element_user(CREATEDOCUMENTREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "CreateDocumentRequest" element
     */
    public boolean isNilCreateDocumentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest)get_store().find_element_user(CREATEDOCUMENTREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "CreateDocumentRequest" element
     */
    public void setCreateDocumentRequest(org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest createDocumentRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest)get_store().find_element_user(CREATEDOCUMENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest)get_store().add_element_user(CREATEDOCUMENTREQUEST$0);
            }
            target.set(createDocumentRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "CreateDocumentRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest addNewCreateDocumentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest)get_store().add_element_user(CREATEDOCUMENTREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "CreateDocumentRequest" element
     */
    public void setNilCreateDocumentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest)get_store().find_element_user(CREATEDOCUMENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest)get_store().add_element_user(CREATEDOCUMENTREQUEST$0);
            }
            target.setNil();
        }
    }
}
