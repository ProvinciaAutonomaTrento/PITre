/*
 * An XML document type.
 * Localname: GetClassificationSchemeByIdRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetClassificationSchemeById
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.impl;
/**
 * A document containing one GetClassificationSchemeByIdRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetClassificationSchemeById) element.
 *
 * This is a complex type.
 */
public class GetClassificationSchemeByIdRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdRequestDocument
{
    
    public GetClassificationSchemeByIdRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETCLASSIFICATIONSCHEMEBYIDREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetClassificationSchemeById", "GetClassificationSchemeByIdRequest");
    
    
    /**
     * Gets the "GetClassificationSchemeByIdRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdRequest getGetClassificationSchemeByIdRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdRequest)get_store().find_element_user(GETCLASSIFICATIONSCHEMEBYIDREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetClassificationSchemeByIdRequest" element
     */
    public boolean isNilGetClassificationSchemeByIdRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdRequest)get_store().find_element_user(GETCLASSIFICATIONSCHEMEBYIDREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetClassificationSchemeByIdRequest" element
     */
    public void setGetClassificationSchemeByIdRequest(org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdRequest getClassificationSchemeByIdRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdRequest)get_store().find_element_user(GETCLASSIFICATIONSCHEMEBYIDREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdRequest)get_store().add_element_user(GETCLASSIFICATIONSCHEMEBYIDREQUEST$0);
            }
            target.set(getClassificationSchemeByIdRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "GetClassificationSchemeByIdRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdRequest addNewGetClassificationSchemeByIdRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdRequest)get_store().add_element_user(GETCLASSIFICATIONSCHEMEBYIDREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetClassificationSchemeByIdRequest" element
     */
    public void setNilGetClassificationSchemeByIdRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdRequest)get_store().find_element_user(GETCLASSIFICATIONSCHEMEBYIDREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdRequest)get_store().add_element_user(GETCLASSIFICATIONSCHEMEBYIDREQUEST$0);
            }
            target.setNil();
        }
    }
}
