/*
 * An XML document type.
 * Localname: CreateProjectRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.CreateProject
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.impl;
/**
 * A document containing one CreateProjectRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.CreateProject) element.
 *
 * This is a complex type.
 */
public class CreateProjectRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectRequestDocument
{
    
    public CreateProjectRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CREATEPROJECTREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.CreateProject", "CreateProjectRequest");
    
    
    /**
     * Gets the "CreateProjectRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectRequest getCreateProjectRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectRequest)get_store().find_element_user(CREATEPROJECTREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "CreateProjectRequest" element
     */
    public boolean isNilCreateProjectRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectRequest)get_store().find_element_user(CREATEPROJECTREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "CreateProjectRequest" element
     */
    public void setCreateProjectRequest(org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectRequest createProjectRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectRequest)get_store().find_element_user(CREATEPROJECTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectRequest)get_store().add_element_user(CREATEPROJECTREQUEST$0);
            }
            target.set(createProjectRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "CreateProjectRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectRequest addNewCreateProjectRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectRequest)get_store().add_element_user(CREATEPROJECTREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "CreateProjectRequest" element
     */
    public void setNilCreateProjectRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectRequest)get_store().find_element_user(CREATEPROJECTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectRequest)get_store().add_element_user(CREATEPROJECTREQUEST$0);
            }
            target.setNil();
        }
    }
}
