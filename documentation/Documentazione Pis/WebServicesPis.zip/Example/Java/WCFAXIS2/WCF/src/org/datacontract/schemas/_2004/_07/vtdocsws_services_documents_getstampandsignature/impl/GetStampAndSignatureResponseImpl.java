/*
 * XML Type:  GetStampAndSignatureResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetStampAndSignature
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureResponse
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.impl;
/**
 * An XML GetStampAndSignatureResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetStampAndSignature).
 *
 * This is a complex type.
 */
public class GetStampAndSignatureResponseImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.ResponseImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureResponse
{
    
    public GetStampAndSignatureResponseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName STAMP$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetStampAndSignature", "Stamp");
    
    
    /**
     * Gets the "Stamp" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp getStamp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp)get_store().find_element_user(STAMP$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Stamp" element
     */
    public boolean isNilStamp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp)get_store().find_element_user(STAMP$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Stamp" element
     */
    public boolean isSetStamp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(STAMP$0) != 0;
        }
    }
    
    /**
     * Sets the "Stamp" element
     */
    public void setStamp(org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp stamp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp)get_store().find_element_user(STAMP$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp)get_store().add_element_user(STAMP$0);
            }
            target.set(stamp);
        }
    }
    
    /**
     * Appends and returns a new empty "Stamp" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp addNewStamp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp)get_store().add_element_user(STAMP$0);
            return target;
        }
    }
    
    /**
     * Nils the "Stamp" element
     */
    public void setNilStamp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp)get_store().find_element_user(STAMP$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp)get_store().add_element_user(STAMP$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Stamp" element
     */
    public void unsetStamp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(STAMP$0, 0);
        }
    }
}
