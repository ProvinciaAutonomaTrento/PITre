/*
 * XML Type:  Correspondent
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain;


/**
 * An XML Correspondent(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain).
 *
 * This is a complex type.
 */
public interface Correspondent extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(Correspondent.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s618A4BF965398050DC6199178E6A766E").resolveHandle("correspondent38c6type");
    
    /**
     * Gets the "AOOCode" element
     */
    java.lang.String getAOOCode();
    
    /**
     * Gets (as xml) the "AOOCode" element
     */
    org.apache.xmlbeans.XmlString xgetAOOCode();
    
    /**
     * Tests for nil "AOOCode" element
     */
    boolean isNilAOOCode();
    
    /**
     * True if has "AOOCode" element
     */
    boolean isSetAOOCode();
    
    /**
     * Sets the "AOOCode" element
     */
    void setAOOCode(java.lang.String aooCode);
    
    /**
     * Sets (as xml) the "AOOCode" element
     */
    void xsetAOOCode(org.apache.xmlbeans.XmlString aooCode);
    
    /**
     * Nils the "AOOCode" element
     */
    void setNilAOOCode();
    
    /**
     * Unsets the "AOOCode" element
     */
    void unsetAOOCode();
    
    /**
     * Gets the "Address" element
     */
    java.lang.String getAddress();
    
    /**
     * Gets (as xml) the "Address" element
     */
    org.apache.xmlbeans.XmlString xgetAddress();
    
    /**
     * Tests for nil "Address" element
     */
    boolean isNilAddress();
    
    /**
     * True if has "Address" element
     */
    boolean isSetAddress();
    
    /**
     * Sets the "Address" element
     */
    void setAddress(java.lang.String address);
    
    /**
     * Sets (as xml) the "Address" element
     */
    void xsetAddress(org.apache.xmlbeans.XmlString address);
    
    /**
     * Nils the "Address" element
     */
    void setNilAddress();
    
    /**
     * Unsets the "Address" element
     */
    void unsetAddress();
    
    /**
     * Gets the "AdmCode" element
     */
    java.lang.String getAdmCode();
    
    /**
     * Gets (as xml) the "AdmCode" element
     */
    org.apache.xmlbeans.XmlString xgetAdmCode();
    
    /**
     * Tests for nil "AdmCode" element
     */
    boolean isNilAdmCode();
    
    /**
     * True if has "AdmCode" element
     */
    boolean isSetAdmCode();
    
    /**
     * Sets the "AdmCode" element
     */
    void setAdmCode(java.lang.String admCode);
    
    /**
     * Sets (as xml) the "AdmCode" element
     */
    void xsetAdmCode(org.apache.xmlbeans.XmlString admCode);
    
    /**
     * Nils the "AdmCode" element
     */
    void setNilAdmCode();
    
    /**
     * Unsets the "AdmCode" element
     */
    void unsetAdmCode();
    
    /**
     * Gets the "Cap" element
     */
    java.lang.String getCap();
    
    /**
     * Gets (as xml) the "Cap" element
     */
    org.apache.xmlbeans.XmlString xgetCap();
    
    /**
     * Tests for nil "Cap" element
     */
    boolean isNilCap();
    
    /**
     * True if has "Cap" element
     */
    boolean isSetCap();
    
    /**
     * Sets the "Cap" element
     */
    void setCap(java.lang.String cap);
    
    /**
     * Sets (as xml) the "Cap" element
     */
    void xsetCap(org.apache.xmlbeans.XmlString cap);
    
    /**
     * Nils the "Cap" element
     */
    void setNilCap();
    
    /**
     * Unsets the "Cap" element
     */
    void unsetCap();
    
    /**
     * Gets the "City" element
     */
    java.lang.String getCity();
    
    /**
     * Gets (as xml) the "City" element
     */
    org.apache.xmlbeans.XmlString xgetCity();
    
    /**
     * Tests for nil "City" element
     */
    boolean isNilCity();
    
    /**
     * True if has "City" element
     */
    boolean isSetCity();
    
    /**
     * Sets the "City" element
     */
    void setCity(java.lang.String city);
    
    /**
     * Sets (as xml) the "City" element
     */
    void xsetCity(org.apache.xmlbeans.XmlString city);
    
    /**
     * Nils the "City" element
     */
    void setNilCity();
    
    /**
     * Unsets the "City" element
     */
    void unsetCity();
    
    /**
     * Gets the "Code" element
     */
    java.lang.String getCode();
    
    /**
     * Gets (as xml) the "Code" element
     */
    org.apache.xmlbeans.XmlString xgetCode();
    
    /**
     * Tests for nil "Code" element
     */
    boolean isNilCode();
    
    /**
     * True if has "Code" element
     */
    boolean isSetCode();
    
    /**
     * Sets the "Code" element
     */
    void setCode(java.lang.String code);
    
    /**
     * Sets (as xml) the "Code" element
     */
    void xsetCode(org.apache.xmlbeans.XmlString code);
    
    /**
     * Nils the "Code" element
     */
    void setNilCode();
    
    /**
     * Unsets the "Code" element
     */
    void unsetCode();
    
    /**
     * Gets the "CodeRegisterOrRF" element
     */
    java.lang.String getCodeRegisterOrRF();
    
    /**
     * Gets (as xml) the "CodeRegisterOrRF" element
     */
    org.apache.xmlbeans.XmlString xgetCodeRegisterOrRF();
    
    /**
     * Tests for nil "CodeRegisterOrRF" element
     */
    boolean isNilCodeRegisterOrRF();
    
    /**
     * True if has "CodeRegisterOrRF" element
     */
    boolean isSetCodeRegisterOrRF();
    
    /**
     * Sets the "CodeRegisterOrRF" element
     */
    void setCodeRegisterOrRF(java.lang.String codeRegisterOrRF);
    
    /**
     * Sets (as xml) the "CodeRegisterOrRF" element
     */
    void xsetCodeRegisterOrRF(org.apache.xmlbeans.XmlString codeRegisterOrRF);
    
    /**
     * Nils the "CodeRegisterOrRF" element
     */
    void setNilCodeRegisterOrRF();
    
    /**
     * Unsets the "CodeRegisterOrRF" element
     */
    void unsetCodeRegisterOrRF();
    
    /**
     * Gets the "CorrespondentType" element
     */
    java.lang.String getCorrespondentType();
    
    /**
     * Gets (as xml) the "CorrespondentType" element
     */
    org.apache.xmlbeans.XmlString xgetCorrespondentType();
    
    /**
     * Tests for nil "CorrespondentType" element
     */
    boolean isNilCorrespondentType();
    
    /**
     * True if has "CorrespondentType" element
     */
    boolean isSetCorrespondentType();
    
    /**
     * Sets the "CorrespondentType" element
     */
    void setCorrespondentType(java.lang.String correspondentType);
    
    /**
     * Sets (as xml) the "CorrespondentType" element
     */
    void xsetCorrespondentType(org.apache.xmlbeans.XmlString correspondentType);
    
    /**
     * Nils the "CorrespondentType" element
     */
    void setNilCorrespondentType();
    
    /**
     * Unsets the "CorrespondentType" element
     */
    void unsetCorrespondentType();
    
    /**
     * Gets the "Description" element
     */
    java.lang.String getDescription();
    
    /**
     * Gets (as xml) the "Description" element
     */
    org.apache.xmlbeans.XmlString xgetDescription();
    
    /**
     * Tests for nil "Description" element
     */
    boolean isNilDescription();
    
    /**
     * True if has "Description" element
     */
    boolean isSetDescription();
    
    /**
     * Sets the "Description" element
     */
    void setDescription(java.lang.String description);
    
    /**
     * Sets (as xml) the "Description" element
     */
    void xsetDescription(org.apache.xmlbeans.XmlString description);
    
    /**
     * Nils the "Description" element
     */
    void setNilDescription();
    
    /**
     * Unsets the "Description" element
     */
    void unsetDescription();
    
    /**
     * Gets the "Email" element
     */
    java.lang.String getEmail();
    
    /**
     * Gets (as xml) the "Email" element
     */
    org.apache.xmlbeans.XmlString xgetEmail();
    
    /**
     * Tests for nil "Email" element
     */
    boolean isNilEmail();
    
    /**
     * True if has "Email" element
     */
    boolean isSetEmail();
    
    /**
     * Sets the "Email" element
     */
    void setEmail(java.lang.String email);
    
    /**
     * Sets (as xml) the "Email" element
     */
    void xsetEmail(org.apache.xmlbeans.XmlString email);
    
    /**
     * Nils the "Email" element
     */
    void setNilEmail();
    
    /**
     * Unsets the "Email" element
     */
    void unsetEmail();
    
    /**
     * Gets the "Fax" element
     */
    java.lang.String getFax();
    
    /**
     * Gets (as xml) the "Fax" element
     */
    org.apache.xmlbeans.XmlString xgetFax();
    
    /**
     * Tests for nil "Fax" element
     */
    boolean isNilFax();
    
    /**
     * True if has "Fax" element
     */
    boolean isSetFax();
    
    /**
     * Sets the "Fax" element
     */
    void setFax(java.lang.String fax);
    
    /**
     * Sets (as xml) the "Fax" element
     */
    void xsetFax(org.apache.xmlbeans.XmlString fax);
    
    /**
     * Nils the "Fax" element
     */
    void setNilFax();
    
    /**
     * Unsets the "Fax" element
     */
    void unsetFax();
    
    /**
     * Gets the "Id" element
     */
    java.lang.String getId();
    
    /**
     * Gets (as xml) the "Id" element
     */
    org.apache.xmlbeans.XmlString xgetId();
    
    /**
     * Tests for nil "Id" element
     */
    boolean isNilId();
    
    /**
     * True if has "Id" element
     */
    boolean isSetId();
    
    /**
     * Sets the "Id" element
     */
    void setId(java.lang.String id);
    
    /**
     * Sets (as xml) the "Id" element
     */
    void xsetId(org.apache.xmlbeans.XmlString id);
    
    /**
     * Nils the "Id" element
     */
    void setNilId();
    
    /**
     * Unsets the "Id" element
     */
    void unsetId();
    
    /**
     * Gets the "Location" element
     */
    java.lang.String getLocation();
    
    /**
     * Gets (as xml) the "Location" element
     */
    org.apache.xmlbeans.XmlString xgetLocation();
    
    /**
     * Tests for nil "Location" element
     */
    boolean isNilLocation();
    
    /**
     * True if has "Location" element
     */
    boolean isSetLocation();
    
    /**
     * Sets the "Location" element
     */
    void setLocation(java.lang.String location);
    
    /**
     * Sets (as xml) the "Location" element
     */
    void xsetLocation(org.apache.xmlbeans.XmlString location);
    
    /**
     * Nils the "Location" element
     */
    void setNilLocation();
    
    /**
     * Unsets the "Location" element
     */
    void unsetLocation();
    
    /**
     * Gets the "Name" element
     */
    java.lang.String getName();
    
    /**
     * Gets (as xml) the "Name" element
     */
    org.apache.xmlbeans.XmlString xgetName();
    
    /**
     * Tests for nil "Name" element
     */
    boolean isNilName();
    
    /**
     * True if has "Name" element
     */
    boolean isSetName();
    
    /**
     * Sets the "Name" element
     */
    void setName(java.lang.String name);
    
    /**
     * Sets (as xml) the "Name" element
     */
    void xsetName(org.apache.xmlbeans.XmlString name);
    
    /**
     * Nils the "Name" element
     */
    void setNilName();
    
    /**
     * Unsets the "Name" element
     */
    void unsetName();
    
    /**
     * Gets the "Nation" element
     */
    java.lang.String getNation();
    
    /**
     * Gets (as xml) the "Nation" element
     */
    org.apache.xmlbeans.XmlString xgetNation();
    
    /**
     * Tests for nil "Nation" element
     */
    boolean isNilNation();
    
    /**
     * True if has "Nation" element
     */
    boolean isSetNation();
    
    /**
     * Sets the "Nation" element
     */
    void setNation(java.lang.String nation);
    
    /**
     * Sets (as xml) the "Nation" element
     */
    void xsetNation(org.apache.xmlbeans.XmlString nation);
    
    /**
     * Nils the "Nation" element
     */
    void setNilNation();
    
    /**
     * Unsets the "Nation" element
     */
    void unsetNation();
    
    /**
     * Gets the "NationalIdentificationNumber" element
     */
    java.lang.String getNationalIdentificationNumber();
    
    /**
     * Gets (as xml) the "NationalIdentificationNumber" element
     */
    org.apache.xmlbeans.XmlString xgetNationalIdentificationNumber();
    
    /**
     * Tests for nil "NationalIdentificationNumber" element
     */
    boolean isNilNationalIdentificationNumber();
    
    /**
     * True if has "NationalIdentificationNumber" element
     */
    boolean isSetNationalIdentificationNumber();
    
    /**
     * Sets the "NationalIdentificationNumber" element
     */
    void setNationalIdentificationNumber(java.lang.String nationalIdentificationNumber);
    
    /**
     * Sets (as xml) the "NationalIdentificationNumber" element
     */
    void xsetNationalIdentificationNumber(org.apache.xmlbeans.XmlString nationalIdentificationNumber);
    
    /**
     * Nils the "NationalIdentificationNumber" element
     */
    void setNilNationalIdentificationNumber();
    
    /**
     * Unsets the "NationalIdentificationNumber" element
     */
    void unsetNationalIdentificationNumber();
    
    /**
     * Gets the "Note" element
     */
    java.lang.String getNote();
    
    /**
     * Gets (as xml) the "Note" element
     */
    org.apache.xmlbeans.XmlString xgetNote();
    
    /**
     * Tests for nil "Note" element
     */
    boolean isNilNote();
    
    /**
     * True if has "Note" element
     */
    boolean isSetNote();
    
    /**
     * Sets the "Note" element
     */
    void setNote(java.lang.String note);
    
    /**
     * Sets (as xml) the "Note" element
     */
    void xsetNote(org.apache.xmlbeans.XmlString note);
    
    /**
     * Nils the "Note" element
     */
    void setNilNote();
    
    /**
     * Unsets the "Note" element
     */
    void unsetNote();
    
    /**
     * Gets the "PhoneNumber" element
     */
    java.lang.String getPhoneNumber();
    
    /**
     * Gets (as xml) the "PhoneNumber" element
     */
    org.apache.xmlbeans.XmlString xgetPhoneNumber();
    
    /**
     * Tests for nil "PhoneNumber" element
     */
    boolean isNilPhoneNumber();
    
    /**
     * True if has "PhoneNumber" element
     */
    boolean isSetPhoneNumber();
    
    /**
     * Sets the "PhoneNumber" element
     */
    void setPhoneNumber(java.lang.String phoneNumber);
    
    /**
     * Sets (as xml) the "PhoneNumber" element
     */
    void xsetPhoneNumber(org.apache.xmlbeans.XmlString phoneNumber);
    
    /**
     * Nils the "PhoneNumber" element
     */
    void setNilPhoneNumber();
    
    /**
     * Unsets the "PhoneNumber" element
     */
    void unsetPhoneNumber();
    
    /**
     * Gets the "PreferredChannel" element
     */
    java.lang.String getPreferredChannel();
    
    /**
     * Gets (as xml) the "PreferredChannel" element
     */
    org.apache.xmlbeans.XmlString xgetPreferredChannel();
    
    /**
     * Tests for nil "PreferredChannel" element
     */
    boolean isNilPreferredChannel();
    
    /**
     * True if has "PreferredChannel" element
     */
    boolean isSetPreferredChannel();
    
    /**
     * Sets the "PreferredChannel" element
     */
    void setPreferredChannel(java.lang.String preferredChannel);
    
    /**
     * Sets (as xml) the "PreferredChannel" element
     */
    void xsetPreferredChannel(org.apache.xmlbeans.XmlString preferredChannel);
    
    /**
     * Nils the "PreferredChannel" element
     */
    void setNilPreferredChannel();
    
    /**
     * Unsets the "PreferredChannel" element
     */
    void unsetPreferredChannel();
    
    /**
     * Gets the "Province" element
     */
    java.lang.String getProvince();
    
    /**
     * Gets (as xml) the "Province" element
     */
    org.apache.xmlbeans.XmlString xgetProvince();
    
    /**
     * Tests for nil "Province" element
     */
    boolean isNilProvince();
    
    /**
     * True if has "Province" element
     */
    boolean isSetProvince();
    
    /**
     * Sets the "Province" element
     */
    void setProvince(java.lang.String province);
    
    /**
     * Sets (as xml) the "Province" element
     */
    void xsetProvince(org.apache.xmlbeans.XmlString province);
    
    /**
     * Nils the "Province" element
     */
    void setNilProvince();
    
    /**
     * Unsets the "Province" element
     */
    void unsetProvince();
    
    /**
     * Gets the "Surname" element
     */
    java.lang.String getSurname();
    
    /**
     * Gets (as xml) the "Surname" element
     */
    org.apache.xmlbeans.XmlString xgetSurname();
    
    /**
     * Tests for nil "Surname" element
     */
    boolean isNilSurname();
    
    /**
     * True if has "Surname" element
     */
    boolean isSetSurname();
    
    /**
     * Sets the "Surname" element
     */
    void setSurname(java.lang.String surname);
    
    /**
     * Sets (as xml) the "Surname" element
     */
    void xsetSurname(org.apache.xmlbeans.XmlString surname);
    
    /**
     * Nils the "Surname" element
     */
    void setNilSurname();
    
    /**
     * Unsets the "Surname" element
     */
    void unsetSurname();
    
    /**
     * Gets the "Type" element
     */
    java.lang.String getType();
    
    /**
     * Gets (as xml) the "Type" element
     */
    org.apache.xmlbeans.XmlString xgetType();
    
    /**
     * Tests for nil "Type" element
     */
    boolean isNilType();
    
    /**
     * True if has "Type" element
     */
    boolean isSetType();
    
    /**
     * Sets the "Type" element
     */
    void setType(java.lang.String type);
    
    /**
     * Sets (as xml) the "Type" element
     */
    void xsetType(org.apache.xmlbeans.XmlString type);
    
    /**
     * Nils the "Type" element
     */
    void setNilType();
    
    /**
     * Unsets the "Type" element
     */
    void unsetType();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent newInstance() {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
