/*
 * An XML document type.
 * Localname: ArrayOfNote
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNoteDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one ArrayOfNote(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class ArrayOfNoteDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNoteDocument
{
    
    public ArrayOfNoteDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ARRAYOFNOTE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "ArrayOfNote");
    
    
    /**
     * Gets the "ArrayOfNote" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote getArrayOfNote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote)get_store().find_element_user(ARRAYOFNOTE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ArrayOfNote" element
     */
    public boolean isNilArrayOfNote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote)get_store().find_element_user(ARRAYOFNOTE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ArrayOfNote" element
     */
    public void setArrayOfNote(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote arrayOfNote)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote)get_store().find_element_user(ARRAYOFNOTE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote)get_store().add_element_user(ARRAYOFNOTE$0);
            }
            target.set(arrayOfNote);
        }
    }
    
    /**
     * Appends and returns a new empty "ArrayOfNote" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote addNewArrayOfNote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote)get_store().add_element_user(ARRAYOFNOTE$0);
            return target;
        }
    }
    
    /**
     * Nils the "ArrayOfNote" element
     */
    public void setNilArrayOfNote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote)get_store().find_element_user(ARRAYOFNOTE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote)get_store().add_element_user(ARRAYOFNOTE$0);
            }
            target.setNil();
        }
    }
}
