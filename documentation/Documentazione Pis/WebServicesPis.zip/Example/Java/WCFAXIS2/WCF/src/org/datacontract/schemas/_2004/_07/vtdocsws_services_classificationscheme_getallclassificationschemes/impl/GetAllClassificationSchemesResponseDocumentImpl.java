/*
 * An XML document type.
 * Localname: GetAllClassificationSchemesResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetAllClassificationSchemes
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.impl;
/**
 * A document containing one GetAllClassificationSchemesResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetAllClassificationSchemes) element.
 *
 * This is a complex type.
 */
public class GetAllClassificationSchemesResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesResponseDocument
{
    
    public GetAllClassificationSchemesResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLCLASSIFICATIONSCHEMESRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetAllClassificationSchemes", "GetAllClassificationSchemesResponse");
    
    
    /**
     * Gets the "GetAllClassificationSchemesResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesResponse getGetAllClassificationSchemesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesResponse)get_store().find_element_user(GETALLCLASSIFICATIONSCHEMESRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetAllClassificationSchemesResponse" element
     */
    public boolean isNilGetAllClassificationSchemesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesResponse)get_store().find_element_user(GETALLCLASSIFICATIONSCHEMESRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetAllClassificationSchemesResponse" element
     */
    public void setGetAllClassificationSchemesResponse(org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesResponse getAllClassificationSchemesResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesResponse)get_store().find_element_user(GETALLCLASSIFICATIONSCHEMESRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesResponse)get_store().add_element_user(GETALLCLASSIFICATIONSCHEMESRESPONSE$0);
            }
            target.set(getAllClassificationSchemesResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "GetAllClassificationSchemesResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesResponse addNewGetAllClassificationSchemesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesResponse)get_store().add_element_user(GETALLCLASSIFICATIONSCHEMESRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetAllClassificationSchemesResponse" element
     */
    public void setNilGetAllClassificationSchemesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesResponse)get_store().find_element_user(GETALLCLASSIFICATIONSCHEMESRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesResponse)get_store().add_element_user(GETALLCLASSIFICATIONSCHEMESRESPONSE$0);
            }
            target.setNil();
        }
    }
}
