/*
 * XML Type:  Document
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.Document
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * An XML Document(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain).
 *
 * This is a complex type.
 */
public class DocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.Document
{
    
    public DocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ANNULLED$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Annulled");
    private static final javax.xml.namespace.QName ARRIVALDATE$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "ArrivalDate");
    private static final javax.xml.namespace.QName ATTACHMENTS$4 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Attachments");
    private static final javax.xml.namespace.QName CONSOLIDATIONSTATE$6 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "ConsolidationState");
    private static final javax.xml.namespace.QName CREATIONDATE$8 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "CreationDate");
    private static final javax.xml.namespace.QName DATAPROTOCOLSENDER$10 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "DataProtocolSender");
    private static final javax.xml.namespace.QName DOCNUMBER$12 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "DocNumber");
    private static final javax.xml.namespace.QName DOCUMENTTYPE$14 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "DocumentType");
    private static final javax.xml.namespace.QName ID$16 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Id");
    private static final javax.xml.namespace.QName IDPARENT$18 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "IdParent");
    private static final javax.xml.namespace.QName INBASKET$20 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "InBasket");
    private static final javax.xml.namespace.QName ISATTACHMENTS$22 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "IsAttachments");
    private static final javax.xml.namespace.QName MAINDOCUMENT$24 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "MainDocument");
    private static final javax.xml.namespace.QName MEANSOFSENDING$26 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "MeansOfSending");
    private static final javax.xml.namespace.QName MULTIPLESENDERS$28 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "MultipleSenders");
    private static final javax.xml.namespace.QName NOTE$30 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Note");
    private static final javax.xml.namespace.QName OBJECT$32 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Object");
    private static final javax.xml.namespace.QName PREDISPOSED$34 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Predisposed");
    private static final javax.xml.namespace.QName PRIVATEDOCUMENT$36 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "PrivateDocument");
    private static final javax.xml.namespace.QName PROTOCOLDATE$38 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "ProtocolDate");
    private static final javax.xml.namespace.QName PROTOCOLSENDER$40 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "ProtocolSender");
    private static final javax.xml.namespace.QName RECIPIENTS$42 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Recipients");
    private static final javax.xml.namespace.QName RECIPIENTSCC$44 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "RecipientsCC");
    private static final javax.xml.namespace.QName REGISTER$46 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Register");
    private static final javax.xml.namespace.QName SENDER$48 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Sender");
    private static final javax.xml.namespace.QName SIGNATURE$50 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Signature");
    private static final javax.xml.namespace.QName TEMPLATE$52 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Template");
    
    
    /**
     * Gets the "Annulled" element
     */
    public boolean getAnnulled()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ANNULLED$0, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "Annulled" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetAnnulled()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ANNULLED$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "Annulled" element
     */
    public boolean isSetAnnulled()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ANNULLED$0) != 0;
        }
    }
    
    /**
     * Sets the "Annulled" element
     */
    public void setAnnulled(boolean annulled)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ANNULLED$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ANNULLED$0);
            }
            target.setBooleanValue(annulled);
        }
    }
    
    /**
     * Sets (as xml) the "Annulled" element
     */
    public void xsetAnnulled(org.apache.xmlbeans.XmlBoolean annulled)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ANNULLED$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ANNULLED$0);
            }
            target.set(annulled);
        }
    }
    
    /**
     * Unsets the "Annulled" element
     */
    public void unsetAnnulled()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ANNULLED$0, 0);
        }
    }
    
    /**
     * Gets the "ArrivalDate" element
     */
    public java.lang.String getArrivalDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ARRIVALDATE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "ArrivalDate" element
     */
    public org.apache.xmlbeans.XmlString xgetArrivalDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ARRIVALDATE$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "ArrivalDate" element
     */
    public boolean isNilArrivalDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ARRIVALDATE$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ArrivalDate" element
     */
    public boolean isSetArrivalDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ARRIVALDATE$2) != 0;
        }
    }
    
    /**
     * Sets the "ArrivalDate" element
     */
    public void setArrivalDate(java.lang.String arrivalDate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ARRIVALDATE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ARRIVALDATE$2);
            }
            target.setStringValue(arrivalDate);
        }
    }
    
    /**
     * Sets (as xml) the "ArrivalDate" element
     */
    public void xsetArrivalDate(org.apache.xmlbeans.XmlString arrivalDate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ARRIVALDATE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ARRIVALDATE$2);
            }
            target.set(arrivalDate);
        }
    }
    
    /**
     * Nils the "ArrivalDate" element
     */
    public void setNilArrivalDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ARRIVALDATE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ARRIVALDATE$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ArrivalDate" element
     */
    public void unsetArrivalDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ARRIVALDATE$2, 0);
        }
    }
    
    /**
     * Gets the "Attachments" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile getAttachments()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile)get_store().find_element_user(ATTACHMENTS$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Attachments" element
     */
    public boolean isNilAttachments()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile)get_store().find_element_user(ATTACHMENTS$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Attachments" element
     */
    public boolean isSetAttachments()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ATTACHMENTS$4) != 0;
        }
    }
    
    /**
     * Sets the "Attachments" element
     */
    public void setAttachments(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile attachments)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile)get_store().find_element_user(ATTACHMENTS$4, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile)get_store().add_element_user(ATTACHMENTS$4);
            }
            target.set(attachments);
        }
    }
    
    /**
     * Appends and returns a new empty "Attachments" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile addNewAttachments()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile)get_store().add_element_user(ATTACHMENTS$4);
            return target;
        }
    }
    
    /**
     * Nils the "Attachments" element
     */
    public void setNilAttachments()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile)get_store().find_element_user(ATTACHMENTS$4, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile)get_store().add_element_user(ATTACHMENTS$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Attachments" element
     */
    public void unsetAttachments()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ATTACHMENTS$4, 0);
        }
    }
    
    /**
     * Gets the "ConsolidationState" element
     */
    public java.lang.String getConsolidationState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONSOLIDATIONSTATE$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "ConsolidationState" element
     */
    public org.apache.xmlbeans.XmlString xgetConsolidationState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONSOLIDATIONSTATE$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "ConsolidationState" element
     */
    public boolean isNilConsolidationState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONSOLIDATIONSTATE$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ConsolidationState" element
     */
    public boolean isSetConsolidationState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONSOLIDATIONSTATE$6) != 0;
        }
    }
    
    /**
     * Sets the "ConsolidationState" element
     */
    public void setConsolidationState(java.lang.String consolidationState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONSOLIDATIONSTATE$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CONSOLIDATIONSTATE$6);
            }
            target.setStringValue(consolidationState);
        }
    }
    
    /**
     * Sets (as xml) the "ConsolidationState" element
     */
    public void xsetConsolidationState(org.apache.xmlbeans.XmlString consolidationState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONSOLIDATIONSTATE$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONSOLIDATIONSTATE$6);
            }
            target.set(consolidationState);
        }
    }
    
    /**
     * Nils the "ConsolidationState" element
     */
    public void setNilConsolidationState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONSOLIDATIONSTATE$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONSOLIDATIONSTATE$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ConsolidationState" element
     */
    public void unsetConsolidationState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONSOLIDATIONSTATE$6, 0);
        }
    }
    
    /**
     * Gets the "CreationDate" element
     */
    public java.lang.String getCreationDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CREATIONDATE$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CreationDate" element
     */
    public org.apache.xmlbeans.XmlString xgetCreationDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CREATIONDATE$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CreationDate" element
     */
    public boolean isNilCreationDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CREATIONDATE$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CreationDate" element
     */
    public boolean isSetCreationDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CREATIONDATE$8) != 0;
        }
    }
    
    /**
     * Sets the "CreationDate" element
     */
    public void setCreationDate(java.lang.String creationDate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CREATIONDATE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CREATIONDATE$8);
            }
            target.setStringValue(creationDate);
        }
    }
    
    /**
     * Sets (as xml) the "CreationDate" element
     */
    public void xsetCreationDate(org.apache.xmlbeans.XmlString creationDate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CREATIONDATE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CREATIONDATE$8);
            }
            target.set(creationDate);
        }
    }
    
    /**
     * Nils the "CreationDate" element
     */
    public void setNilCreationDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CREATIONDATE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CREATIONDATE$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CreationDate" element
     */
    public void unsetCreationDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CREATIONDATE$8, 0);
        }
    }
    
    /**
     * Gets the "DataProtocolSender" element
     */
    public java.lang.String getDataProtocolSender()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAPROTOCOLSENDER$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataProtocolSender" element
     */
    public org.apache.xmlbeans.XmlString xgetDataProtocolSender()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATAPROTOCOLSENDER$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DataProtocolSender" element
     */
    public boolean isNilDataProtocolSender()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATAPROTOCOLSENDER$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DataProtocolSender" element
     */
    public boolean isSetDataProtocolSender()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DATAPROTOCOLSENDER$10) != 0;
        }
    }
    
    /**
     * Sets the "DataProtocolSender" element
     */
    public void setDataProtocolSender(java.lang.String dataProtocolSender)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAPROTOCOLSENDER$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATAPROTOCOLSENDER$10);
            }
            target.setStringValue(dataProtocolSender);
        }
    }
    
    /**
     * Sets (as xml) the "DataProtocolSender" element
     */
    public void xsetDataProtocolSender(org.apache.xmlbeans.XmlString dataProtocolSender)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATAPROTOCOLSENDER$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DATAPROTOCOLSENDER$10);
            }
            target.set(dataProtocolSender);
        }
    }
    
    /**
     * Nils the "DataProtocolSender" element
     */
    public void setNilDataProtocolSender()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATAPROTOCOLSENDER$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DATAPROTOCOLSENDER$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DataProtocolSender" element
     */
    public void unsetDataProtocolSender()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DATAPROTOCOLSENDER$10, 0);
        }
    }
    
    /**
     * Gets the "DocNumber" element
     */
    public java.lang.String getDocNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DOCNUMBER$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "DocNumber" element
     */
    public org.apache.xmlbeans.XmlString xgetDocNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DOCNUMBER$12, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DocNumber" element
     */
    public boolean isNilDocNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DOCNUMBER$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DocNumber" element
     */
    public boolean isSetDocNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DOCNUMBER$12) != 0;
        }
    }
    
    /**
     * Sets the "DocNumber" element
     */
    public void setDocNumber(java.lang.String docNumber)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DOCNUMBER$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DOCNUMBER$12);
            }
            target.setStringValue(docNumber);
        }
    }
    
    /**
     * Sets (as xml) the "DocNumber" element
     */
    public void xsetDocNumber(org.apache.xmlbeans.XmlString docNumber)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DOCNUMBER$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DOCNUMBER$12);
            }
            target.set(docNumber);
        }
    }
    
    /**
     * Nils the "DocNumber" element
     */
    public void setNilDocNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DOCNUMBER$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DOCNUMBER$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DocNumber" element
     */
    public void unsetDocNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DOCNUMBER$12, 0);
        }
    }
    
    /**
     * Gets the "DocumentType" element
     */
    public java.lang.String getDocumentType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DOCUMENTTYPE$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "DocumentType" element
     */
    public org.apache.xmlbeans.XmlString xgetDocumentType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DOCUMENTTYPE$14, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DocumentType" element
     */
    public boolean isNilDocumentType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DOCUMENTTYPE$14, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DocumentType" element
     */
    public boolean isSetDocumentType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DOCUMENTTYPE$14) != 0;
        }
    }
    
    /**
     * Sets the "DocumentType" element
     */
    public void setDocumentType(java.lang.String documentType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DOCUMENTTYPE$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DOCUMENTTYPE$14);
            }
            target.setStringValue(documentType);
        }
    }
    
    /**
     * Sets (as xml) the "DocumentType" element
     */
    public void xsetDocumentType(org.apache.xmlbeans.XmlString documentType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DOCUMENTTYPE$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DOCUMENTTYPE$14);
            }
            target.set(documentType);
        }
    }
    
    /**
     * Nils the "DocumentType" element
     */
    public void setNilDocumentType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DOCUMENTTYPE$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DOCUMENTTYPE$14);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DocumentType" element
     */
    public void unsetDocumentType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DOCUMENTTYPE$14, 0);
        }
    }
    
    /**
     * Gets the "Id" element
     */
    public java.lang.String getId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ID$16, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Id" element
     */
    public org.apache.xmlbeans.XmlString xgetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ID$16, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Id" element
     */
    public boolean isNilId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ID$16, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Id" element
     */
    public boolean isSetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ID$16) != 0;
        }
    }
    
    /**
     * Sets the "Id" element
     */
    public void setId(java.lang.String id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ID$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ID$16);
            }
            target.setStringValue(id);
        }
    }
    
    /**
     * Sets (as xml) the "Id" element
     */
    public void xsetId(org.apache.xmlbeans.XmlString id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ID$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ID$16);
            }
            target.set(id);
        }
    }
    
    /**
     * Nils the "Id" element
     */
    public void setNilId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ID$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ID$16);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Id" element
     */
    public void unsetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ID$16, 0);
        }
    }
    
    /**
     * Gets the "IdParent" element
     */
    public java.lang.String getIdParent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDPARENT$18, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "IdParent" element
     */
    public org.apache.xmlbeans.XmlString xgetIdParent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDPARENT$18, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "IdParent" element
     */
    public boolean isNilIdParent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDPARENT$18, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "IdParent" element
     */
    public boolean isSetIdParent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(IDPARENT$18) != 0;
        }
    }
    
    /**
     * Sets the "IdParent" element
     */
    public void setIdParent(java.lang.String idParent)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDPARENT$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(IDPARENT$18);
            }
            target.setStringValue(idParent);
        }
    }
    
    /**
     * Sets (as xml) the "IdParent" element
     */
    public void xsetIdParent(org.apache.xmlbeans.XmlString idParent)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDPARENT$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(IDPARENT$18);
            }
            target.set(idParent);
        }
    }
    
    /**
     * Nils the "IdParent" element
     */
    public void setNilIdParent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDPARENT$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(IDPARENT$18);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "IdParent" element
     */
    public void unsetIdParent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(IDPARENT$18, 0);
        }
    }
    
    /**
     * Gets the "InBasket" element
     */
    public boolean getInBasket()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INBASKET$20, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "InBasket" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetInBasket()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(INBASKET$20, 0);
            return target;
        }
    }
    
    /**
     * True if has "InBasket" element
     */
    public boolean isSetInBasket()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INBASKET$20) != 0;
        }
    }
    
    /**
     * Sets the "InBasket" element
     */
    public void setInBasket(boolean inBasket)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INBASKET$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INBASKET$20);
            }
            target.setBooleanValue(inBasket);
        }
    }
    
    /**
     * Sets (as xml) the "InBasket" element
     */
    public void xsetInBasket(org.apache.xmlbeans.XmlBoolean inBasket)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(INBASKET$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(INBASKET$20);
            }
            target.set(inBasket);
        }
    }
    
    /**
     * Unsets the "InBasket" element
     */
    public void unsetInBasket()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INBASKET$20, 0);
        }
    }
    
    /**
     * Gets the "IsAttachments" element
     */
    public boolean getIsAttachments()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISATTACHMENTS$22, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "IsAttachments" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsAttachments()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISATTACHMENTS$22, 0);
            return target;
        }
    }
    
    /**
     * True if has "IsAttachments" element
     */
    public boolean isSetIsAttachments()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISATTACHMENTS$22) != 0;
        }
    }
    
    /**
     * Sets the "IsAttachments" element
     */
    public void setIsAttachments(boolean isAttachments)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISATTACHMENTS$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISATTACHMENTS$22);
            }
            target.setBooleanValue(isAttachments);
        }
    }
    
    /**
     * Sets (as xml) the "IsAttachments" element
     */
    public void xsetIsAttachments(org.apache.xmlbeans.XmlBoolean isAttachments)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISATTACHMENTS$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISATTACHMENTS$22);
            }
            target.set(isAttachments);
        }
    }
    
    /**
     * Unsets the "IsAttachments" element
     */
    public void unsetIsAttachments()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISATTACHMENTS$22, 0);
        }
    }
    
    /**
     * Gets the "MainDocument" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.File getMainDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().find_element_user(MAINDOCUMENT$24, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "MainDocument" element
     */
    public boolean isNilMainDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().find_element_user(MAINDOCUMENT$24, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "MainDocument" element
     */
    public boolean isSetMainDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MAINDOCUMENT$24) != 0;
        }
    }
    
    /**
     * Sets the "MainDocument" element
     */
    public void setMainDocument(org.datacontract.schemas._2004._07.vtdocsws_domain.File mainDocument)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().find_element_user(MAINDOCUMENT$24, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().add_element_user(MAINDOCUMENT$24);
            }
            target.set(mainDocument);
        }
    }
    
    /**
     * Appends and returns a new empty "MainDocument" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.File addNewMainDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().add_element_user(MAINDOCUMENT$24);
            return target;
        }
    }
    
    /**
     * Nils the "MainDocument" element
     */
    public void setNilMainDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().find_element_user(MAINDOCUMENT$24, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().add_element_user(MAINDOCUMENT$24);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "MainDocument" element
     */
    public void unsetMainDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MAINDOCUMENT$24, 0);
        }
    }
    
    /**
     * Gets the "MeansOfSending" element
     */
    public java.lang.String getMeansOfSending()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MEANSOFSENDING$26, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "MeansOfSending" element
     */
    public org.apache.xmlbeans.XmlString xgetMeansOfSending()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MEANSOFSENDING$26, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "MeansOfSending" element
     */
    public boolean isNilMeansOfSending()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MEANSOFSENDING$26, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "MeansOfSending" element
     */
    public boolean isSetMeansOfSending()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MEANSOFSENDING$26) != 0;
        }
    }
    
    /**
     * Sets the "MeansOfSending" element
     */
    public void setMeansOfSending(java.lang.String meansOfSending)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MEANSOFSENDING$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MEANSOFSENDING$26);
            }
            target.setStringValue(meansOfSending);
        }
    }
    
    /**
     * Sets (as xml) the "MeansOfSending" element
     */
    public void xsetMeansOfSending(org.apache.xmlbeans.XmlString meansOfSending)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MEANSOFSENDING$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MEANSOFSENDING$26);
            }
            target.set(meansOfSending);
        }
    }
    
    /**
     * Nils the "MeansOfSending" element
     */
    public void setNilMeansOfSending()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MEANSOFSENDING$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MEANSOFSENDING$26);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "MeansOfSending" element
     */
    public void unsetMeansOfSending()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MEANSOFSENDING$26, 0);
        }
    }
    
    /**
     * Gets the "MultipleSenders" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent getMultipleSenders()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().find_element_user(MULTIPLESENDERS$28, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "MultipleSenders" element
     */
    public boolean isNilMultipleSenders()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().find_element_user(MULTIPLESENDERS$28, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "MultipleSenders" element
     */
    public boolean isSetMultipleSenders()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MULTIPLESENDERS$28) != 0;
        }
    }
    
    /**
     * Sets the "MultipleSenders" element
     */
    public void setMultipleSenders(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent multipleSenders)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().find_element_user(MULTIPLESENDERS$28, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().add_element_user(MULTIPLESENDERS$28);
            }
            target.set(multipleSenders);
        }
    }
    
    /**
     * Appends and returns a new empty "MultipleSenders" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent addNewMultipleSenders()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().add_element_user(MULTIPLESENDERS$28);
            return target;
        }
    }
    
    /**
     * Nils the "MultipleSenders" element
     */
    public void setNilMultipleSenders()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().find_element_user(MULTIPLESENDERS$28, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().add_element_user(MULTIPLESENDERS$28);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "MultipleSenders" element
     */
    public void unsetMultipleSenders()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MULTIPLESENDERS$28, 0);
        }
    }
    
    /**
     * Gets the "Note" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote getNote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote)get_store().find_element_user(NOTE$30, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Note" element
     */
    public boolean isNilNote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote)get_store().find_element_user(NOTE$30, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Note" element
     */
    public boolean isSetNote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NOTE$30) != 0;
        }
    }
    
    /**
     * Sets the "Note" element
     */
    public void setNote(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote note)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote)get_store().find_element_user(NOTE$30, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote)get_store().add_element_user(NOTE$30);
            }
            target.set(note);
        }
    }
    
    /**
     * Appends and returns a new empty "Note" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote addNewNote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote)get_store().add_element_user(NOTE$30);
            return target;
        }
    }
    
    /**
     * Nils the "Note" element
     */
    public void setNilNote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote)get_store().find_element_user(NOTE$30, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote)get_store().add_element_user(NOTE$30);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Note" element
     */
    public void unsetNote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NOTE$30, 0);
        }
    }
    
    /**
     * Gets the "Object" element
     */
    public java.lang.String getObject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OBJECT$32, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Object" element
     */
    public org.apache.xmlbeans.XmlString xgetObject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(OBJECT$32, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Object" element
     */
    public boolean isNilObject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(OBJECT$32, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Object" element
     */
    public boolean isSetObject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OBJECT$32) != 0;
        }
    }
    
    /**
     * Sets the "Object" element
     */
    public void setObject(java.lang.String object)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OBJECT$32, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OBJECT$32);
            }
            target.setStringValue(object);
        }
    }
    
    /**
     * Sets (as xml) the "Object" element
     */
    public void xsetObject(org.apache.xmlbeans.XmlString object)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(OBJECT$32, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(OBJECT$32);
            }
            target.set(object);
        }
    }
    
    /**
     * Nils the "Object" element
     */
    public void setNilObject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(OBJECT$32, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(OBJECT$32);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Object" element
     */
    public void unsetObject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OBJECT$32, 0);
        }
    }
    
    /**
     * Gets the "Predisposed" element
     */
    public boolean getPredisposed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PREDISPOSED$34, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "Predisposed" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetPredisposed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(PREDISPOSED$34, 0);
            return target;
        }
    }
    
    /**
     * True if has "Predisposed" element
     */
    public boolean isSetPredisposed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PREDISPOSED$34) != 0;
        }
    }
    
    /**
     * Sets the "Predisposed" element
     */
    public void setPredisposed(boolean predisposed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PREDISPOSED$34, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PREDISPOSED$34);
            }
            target.setBooleanValue(predisposed);
        }
    }
    
    /**
     * Sets (as xml) the "Predisposed" element
     */
    public void xsetPredisposed(org.apache.xmlbeans.XmlBoolean predisposed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(PREDISPOSED$34, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(PREDISPOSED$34);
            }
            target.set(predisposed);
        }
    }
    
    /**
     * Unsets the "Predisposed" element
     */
    public void unsetPredisposed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PREDISPOSED$34, 0);
        }
    }
    
    /**
     * Gets the "PrivateDocument" element
     */
    public boolean getPrivateDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRIVATEDOCUMENT$36, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "PrivateDocument" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetPrivateDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(PRIVATEDOCUMENT$36, 0);
            return target;
        }
    }
    
    /**
     * True if has "PrivateDocument" element
     */
    public boolean isSetPrivateDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PRIVATEDOCUMENT$36) != 0;
        }
    }
    
    /**
     * Sets the "PrivateDocument" element
     */
    public void setPrivateDocument(boolean privateDocument)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRIVATEDOCUMENT$36, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PRIVATEDOCUMENT$36);
            }
            target.setBooleanValue(privateDocument);
        }
    }
    
    /**
     * Sets (as xml) the "PrivateDocument" element
     */
    public void xsetPrivateDocument(org.apache.xmlbeans.XmlBoolean privateDocument)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(PRIVATEDOCUMENT$36, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(PRIVATEDOCUMENT$36);
            }
            target.set(privateDocument);
        }
    }
    
    /**
     * Unsets the "PrivateDocument" element
     */
    public void unsetPrivateDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PRIVATEDOCUMENT$36, 0);
        }
    }
    
    /**
     * Gets the "ProtocolDate" element
     */
    public java.lang.String getProtocolDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROTOCOLDATE$38, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "ProtocolDate" element
     */
    public org.apache.xmlbeans.XmlString xgetProtocolDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PROTOCOLDATE$38, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "ProtocolDate" element
     */
    public boolean isNilProtocolDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PROTOCOLDATE$38, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ProtocolDate" element
     */
    public boolean isSetProtocolDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTOCOLDATE$38) != 0;
        }
    }
    
    /**
     * Sets the "ProtocolDate" element
     */
    public void setProtocolDate(java.lang.String protocolDate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROTOCOLDATE$38, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PROTOCOLDATE$38);
            }
            target.setStringValue(protocolDate);
        }
    }
    
    /**
     * Sets (as xml) the "ProtocolDate" element
     */
    public void xsetProtocolDate(org.apache.xmlbeans.XmlString protocolDate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PROTOCOLDATE$38, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PROTOCOLDATE$38);
            }
            target.set(protocolDate);
        }
    }
    
    /**
     * Nils the "ProtocolDate" element
     */
    public void setNilProtocolDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PROTOCOLDATE$38, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PROTOCOLDATE$38);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ProtocolDate" element
     */
    public void unsetProtocolDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTOCOLDATE$38, 0);
        }
    }
    
    /**
     * Gets the "ProtocolSender" element
     */
    public java.lang.String getProtocolSender()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROTOCOLSENDER$40, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "ProtocolSender" element
     */
    public org.apache.xmlbeans.XmlString xgetProtocolSender()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PROTOCOLSENDER$40, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "ProtocolSender" element
     */
    public boolean isNilProtocolSender()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PROTOCOLSENDER$40, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ProtocolSender" element
     */
    public boolean isSetProtocolSender()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTOCOLSENDER$40) != 0;
        }
    }
    
    /**
     * Sets the "ProtocolSender" element
     */
    public void setProtocolSender(java.lang.String protocolSender)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROTOCOLSENDER$40, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PROTOCOLSENDER$40);
            }
            target.setStringValue(protocolSender);
        }
    }
    
    /**
     * Sets (as xml) the "ProtocolSender" element
     */
    public void xsetProtocolSender(org.apache.xmlbeans.XmlString protocolSender)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PROTOCOLSENDER$40, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PROTOCOLSENDER$40);
            }
            target.set(protocolSender);
        }
    }
    
    /**
     * Nils the "ProtocolSender" element
     */
    public void setNilProtocolSender()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PROTOCOLSENDER$40, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PROTOCOLSENDER$40);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ProtocolSender" element
     */
    public void unsetProtocolSender()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTOCOLSENDER$40, 0);
        }
    }
    
    /**
     * Gets the "Recipients" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent getRecipients()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().find_element_user(RECIPIENTS$42, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Recipients" element
     */
    public boolean isNilRecipients()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().find_element_user(RECIPIENTS$42, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Recipients" element
     */
    public boolean isSetRecipients()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RECIPIENTS$42) != 0;
        }
    }
    
    /**
     * Sets the "Recipients" element
     */
    public void setRecipients(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent recipients)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().find_element_user(RECIPIENTS$42, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().add_element_user(RECIPIENTS$42);
            }
            target.set(recipients);
        }
    }
    
    /**
     * Appends and returns a new empty "Recipients" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent addNewRecipients()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().add_element_user(RECIPIENTS$42);
            return target;
        }
    }
    
    /**
     * Nils the "Recipients" element
     */
    public void setNilRecipients()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().find_element_user(RECIPIENTS$42, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().add_element_user(RECIPIENTS$42);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Recipients" element
     */
    public void unsetRecipients()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RECIPIENTS$42, 0);
        }
    }
    
    /**
     * Gets the "RecipientsCC" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent getRecipientsCC()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().find_element_user(RECIPIENTSCC$44, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "RecipientsCC" element
     */
    public boolean isNilRecipientsCC()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().find_element_user(RECIPIENTSCC$44, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "RecipientsCC" element
     */
    public boolean isSetRecipientsCC()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RECIPIENTSCC$44) != 0;
        }
    }
    
    /**
     * Sets the "RecipientsCC" element
     */
    public void setRecipientsCC(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent recipientsCC)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().find_element_user(RECIPIENTSCC$44, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().add_element_user(RECIPIENTSCC$44);
            }
            target.set(recipientsCC);
        }
    }
    
    /**
     * Appends and returns a new empty "RecipientsCC" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent addNewRecipientsCC()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().add_element_user(RECIPIENTSCC$44);
            return target;
        }
    }
    
    /**
     * Nils the "RecipientsCC" element
     */
    public void setNilRecipientsCC()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().find_element_user(RECIPIENTSCC$44, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().add_element_user(RECIPIENTSCC$44);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "RecipientsCC" element
     */
    public void unsetRecipientsCC()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RECIPIENTSCC$44, 0);
        }
    }
    
    /**
     * Gets the "Register" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Register getRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Register target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().find_element_user(REGISTER$46, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Register" element
     */
    public boolean isNilRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Register target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().find_element_user(REGISTER$46, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Register" element
     */
    public boolean isSetRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(REGISTER$46) != 0;
        }
    }
    
    /**
     * Sets the "Register" element
     */
    public void setRegister(org.datacontract.schemas._2004._07.vtdocsws_domain.Register register)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Register target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().find_element_user(REGISTER$46, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().add_element_user(REGISTER$46);
            }
            target.set(register);
        }
    }
    
    /**
     * Appends and returns a new empty "Register" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Register addNewRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Register target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().add_element_user(REGISTER$46);
            return target;
        }
    }
    
    /**
     * Nils the "Register" element
     */
    public void setNilRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Register target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().find_element_user(REGISTER$46, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Register)get_store().add_element_user(REGISTER$46);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Register" element
     */
    public void unsetRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(REGISTER$46, 0);
        }
    }
    
    /**
     * Gets the "Sender" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent getSender()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent)get_store().find_element_user(SENDER$48, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Sender" element
     */
    public boolean isNilSender()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent)get_store().find_element_user(SENDER$48, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Sender" element
     */
    public boolean isSetSender()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SENDER$48) != 0;
        }
    }
    
    /**
     * Sets the "Sender" element
     */
    public void setSender(org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent sender)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent)get_store().find_element_user(SENDER$48, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent)get_store().add_element_user(SENDER$48);
            }
            target.set(sender);
        }
    }
    
    /**
     * Appends and returns a new empty "Sender" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent addNewSender()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent)get_store().add_element_user(SENDER$48);
            return target;
        }
    }
    
    /**
     * Nils the "Sender" element
     */
    public void setNilSender()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent)get_store().find_element_user(SENDER$48, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent)get_store().add_element_user(SENDER$48);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Sender" element
     */
    public void unsetSender()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SENDER$48, 0);
        }
    }
    
    /**
     * Gets the "Signature" element
     */
    public java.lang.String getSignature()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SIGNATURE$50, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Signature" element
     */
    public org.apache.xmlbeans.XmlString xgetSignature()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SIGNATURE$50, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Signature" element
     */
    public boolean isNilSignature()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SIGNATURE$50, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Signature" element
     */
    public boolean isSetSignature()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SIGNATURE$50) != 0;
        }
    }
    
    /**
     * Sets the "Signature" element
     */
    public void setSignature(java.lang.String signature)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SIGNATURE$50, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SIGNATURE$50);
            }
            target.setStringValue(signature);
        }
    }
    
    /**
     * Sets (as xml) the "Signature" element
     */
    public void xsetSignature(org.apache.xmlbeans.XmlString signature)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SIGNATURE$50, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SIGNATURE$50);
            }
            target.set(signature);
        }
    }
    
    /**
     * Nils the "Signature" element
     */
    public void setNilSignature()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SIGNATURE$50, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SIGNATURE$50);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Signature" element
     */
    public void unsetSignature()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SIGNATURE$50, 0);
        }
    }
    
    /**
     * Gets the "Template" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Template getTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Template target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().find_element_user(TEMPLATE$52, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Template" element
     */
    public boolean isNilTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Template target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().find_element_user(TEMPLATE$52, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Template" element
     */
    public boolean isSetTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TEMPLATE$52) != 0;
        }
    }
    
    /**
     * Sets the "Template" element
     */
    public void setTemplate(org.datacontract.schemas._2004._07.vtdocsws_domain.Template template)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Template target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().find_element_user(TEMPLATE$52, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().add_element_user(TEMPLATE$52);
            }
            target.set(template);
        }
    }
    
    /**
     * Appends and returns a new empty "Template" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Template addNewTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Template target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().add_element_user(TEMPLATE$52);
            return target;
        }
    }
    
    /**
     * Nils the "Template" element
     */
    public void setNilTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Template target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().find_element_user(TEMPLATE$52, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().add_element_user(TEMPLATE$52);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Template" element
     */
    public void unsetTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TEMPLATE$52, 0);
        }
    }
}
