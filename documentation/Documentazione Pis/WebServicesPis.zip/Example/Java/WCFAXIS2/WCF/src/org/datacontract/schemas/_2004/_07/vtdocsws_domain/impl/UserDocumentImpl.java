/*
 * An XML document type.
 * Localname: User
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.UserDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one User(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class UserDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.UserDocument
{
    
    public UserDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName USER$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "User");
    
    
    /**
     * Gets the "User" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.User getUser()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.User target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.User)get_store().find_element_user(USER$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "User" element
     */
    public boolean isNilUser()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.User target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.User)get_store().find_element_user(USER$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "User" element
     */
    public void setUser(org.datacontract.schemas._2004._07.vtdocsws_domain.User user)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.User target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.User)get_store().find_element_user(USER$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.User)get_store().add_element_user(USER$0);
            }
            target.set(user);
        }
    }
    
    /**
     * Appends and returns a new empty "User" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.User addNewUser()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.User target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.User)get_store().add_element_user(USER$0);
            return target;
        }
    }
    
    /**
     * Nils the "User" element
     */
    public void setNilUser()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.User target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.User)get_store().find_element_user(USER$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.User)get_store().add_element_user(USER$0);
            }
            target.setNil();
        }
    }
}
