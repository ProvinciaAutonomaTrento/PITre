/*
 * An XML document type.
 * Localname: EditProjectRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.EditProject
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.impl;
/**
 * A document containing one EditProjectRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.EditProject) element.
 *
 * This is a complex type.
 */
public class EditProjectRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectRequestDocument
{
    
    public EditProjectRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EDITPROJECTREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.EditProject", "EditProjectRequest");
    
    
    /**
     * Gets the "EditProjectRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectRequest getEditProjectRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectRequest)get_store().find_element_user(EDITPROJECTREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "EditProjectRequest" element
     */
    public boolean isNilEditProjectRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectRequest)get_store().find_element_user(EDITPROJECTREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "EditProjectRequest" element
     */
    public void setEditProjectRequest(org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectRequest editProjectRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectRequest)get_store().find_element_user(EDITPROJECTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectRequest)get_store().add_element_user(EDITPROJECTREQUEST$0);
            }
            target.set(editProjectRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "EditProjectRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectRequest addNewEditProjectRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectRequest)get_store().add_element_user(EDITPROJECTREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "EditProjectRequest" element
     */
    public void setNilEditProjectRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectRequest)get_store().find_element_user(EDITPROJECTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_editproject.EditProjectRequest)get_store().add_element_user(EDITPROJECTREQUEST$0);
            }
            target.setNil();
        }
    }
}
