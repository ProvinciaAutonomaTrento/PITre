/*
 * An XML document type.
 * Localname: Role
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.RoleDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one Role(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class RoleDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.RoleDocument
{
    
    public RoleDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ROLE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Role");
    
    
    /**
     * Gets the "Role" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Role getRole()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Role target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Role)get_store().find_element_user(ROLE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Role" element
     */
    public boolean isNilRole()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Role target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Role)get_store().find_element_user(ROLE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "Role" element
     */
    public void setRole(org.datacontract.schemas._2004._07.vtdocsws_domain.Role role)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Role target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Role)get_store().find_element_user(ROLE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Role)get_store().add_element_user(ROLE$0);
            }
            target.set(role);
        }
    }
    
    /**
     * Appends and returns a new empty "Role" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Role addNewRole()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Role target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Role)get_store().add_element_user(ROLE$0);
            return target;
        }
    }
    
    /**
     * Nils the "Role" element
     */
    public void setNilRole()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Role target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Role)get_store().find_element_user(ROLE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Role)get_store().add_element_user(ROLE$0);
            }
            target.setNil();
        }
    }
}
