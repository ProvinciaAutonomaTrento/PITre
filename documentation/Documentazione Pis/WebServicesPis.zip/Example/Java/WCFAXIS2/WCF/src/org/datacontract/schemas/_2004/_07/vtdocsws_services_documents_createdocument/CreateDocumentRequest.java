/*
 * XML Type:  CreateDocumentRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.CreateDocument
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument;


/**
 * An XML CreateDocumentRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.CreateDocument).
 *
 * This is a complex type.
 */
public interface CreateDocumentRequest extends org.datacontract.schemas._2004._07.vtdocsws_services.Request
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(CreateDocumentRequest.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s618A4BF965398050DC6199178E6A766E").resolveHandle("createdocumentrequestba1ftype");
    
    /**
     * Gets the "CodeRF" element
     */
    java.lang.String getCodeRF();
    
    /**
     * Gets (as xml) the "CodeRF" element
     */
    org.apache.xmlbeans.XmlString xgetCodeRF();
    
    /**
     * Tests for nil "CodeRF" element
     */
    boolean isNilCodeRF();
    
    /**
     * True if has "CodeRF" element
     */
    boolean isSetCodeRF();
    
    /**
     * Sets the "CodeRF" element
     */
    void setCodeRF(java.lang.String codeRF);
    
    /**
     * Sets (as xml) the "CodeRF" element
     */
    void xsetCodeRF(org.apache.xmlbeans.XmlString codeRF);
    
    /**
     * Nils the "CodeRF" element
     */
    void setNilCodeRF();
    
    /**
     * Unsets the "CodeRF" element
     */
    void unsetCodeRF();
    
    /**
     * Gets the "CodeRegister" element
     */
    java.lang.String getCodeRegister();
    
    /**
     * Gets (as xml) the "CodeRegister" element
     */
    org.apache.xmlbeans.XmlString xgetCodeRegister();
    
    /**
     * Tests for nil "CodeRegister" element
     */
    boolean isNilCodeRegister();
    
    /**
     * True if has "CodeRegister" element
     */
    boolean isSetCodeRegister();
    
    /**
     * Sets the "CodeRegister" element
     */
    void setCodeRegister(java.lang.String codeRegister);
    
    /**
     * Sets (as xml) the "CodeRegister" element
     */
    void xsetCodeRegister(org.apache.xmlbeans.XmlString codeRegister);
    
    /**
     * Nils the "CodeRegister" element
     */
    void setNilCodeRegister();
    
    /**
     * Unsets the "CodeRegister" element
     */
    void unsetCodeRegister();
    
    /**
     * Gets the "Document" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.Document getDocument();
    
    /**
     * Tests for nil "Document" element
     */
    boolean isNilDocument();
    
    /**
     * True if has "Document" element
     */
    boolean isSetDocument();
    
    /**
     * Sets the "Document" element
     */
    void setDocument(org.datacontract.schemas._2004._07.vtdocsws_domain.Document document);
    
    /**
     * Appends and returns a new empty "Document" element
     */
    org.datacontract.schemas._2004._07.vtdocsws_domain.Document addNewDocument();
    
    /**
     * Nils the "Document" element
     */
    void setNilDocument();
    
    /**
     * Unsets the "Document" element
     */
    void unsetDocument();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest newInstance() {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
