/*
 * An XML document type.
 * Localname: ArrayOfProject
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProjectDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one ArrayOfProject(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class ArrayOfProjectDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProjectDocument
{
    
    public ArrayOfProjectDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ARRAYOFPROJECT$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "ArrayOfProject");
    
    
    /**
     * Gets the "ArrayOfProject" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject getArrayOfProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject)get_store().find_element_user(ARRAYOFPROJECT$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ArrayOfProject" element
     */
    public boolean isNilArrayOfProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject)get_store().find_element_user(ARRAYOFPROJECT$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ArrayOfProject" element
     */
    public void setArrayOfProject(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject arrayOfProject)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject)get_store().find_element_user(ARRAYOFPROJECT$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject)get_store().add_element_user(ARRAYOFPROJECT$0);
            }
            target.set(arrayOfProject);
        }
    }
    
    /**
     * Appends and returns a new empty "ArrayOfProject" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject addNewArrayOfProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject)get_store().add_element_user(ARRAYOFPROJECT$0);
            return target;
        }
    }
    
    /**
     * Nils the "ArrayOfProject" element
     */
    public void setNilArrayOfProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject)get_store().find_element_user(ARRAYOFPROJECT$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject)get_store().add_element_user(ARRAYOFPROJECT$0);
            }
            target.setNil();
        }
    }
}
