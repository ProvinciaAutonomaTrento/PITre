/*
 * An XML document type.
 * Localname: ClassificationScheme
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationSchemeDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one ClassificationScheme(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class ClassificationSchemeDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationSchemeDocument
{
    
    public ClassificationSchemeDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CLASSIFICATIONSCHEME$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "ClassificationScheme");
    
    
    /**
     * Gets the "ClassificationScheme" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme getClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().find_element_user(CLASSIFICATIONSCHEME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ClassificationScheme" element
     */
    public boolean isNilClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().find_element_user(CLASSIFICATIONSCHEME$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ClassificationScheme" element
     */
    public void setClassificationScheme(org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme classificationScheme)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().find_element_user(CLASSIFICATIONSCHEME$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().add_element_user(CLASSIFICATIONSCHEME$0);
            }
            target.set(classificationScheme);
        }
    }
    
    /**
     * Appends and returns a new empty "ClassificationScheme" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme addNewClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().add_element_user(CLASSIFICATIONSCHEME$0);
            return target;
        }
    }
    
    /**
     * Nils the "ClassificationScheme" element
     */
    public void setNilClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().find_element_user(CLASSIFICATIONSCHEME$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ClassificationScheme)get_store().add_element_user(CLASSIFICATIONSCHEME$0);
            }
            target.setNil();
        }
    }
}
