/*
 * XML Type:  ArrayOfField
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfField
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * An XML ArrayOfField(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain).
 *
 * This is a complex type.
 */
public class ArrayOfFieldImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfField
{
    
    public ArrayOfFieldImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName FIELD$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Field");
    
    
    /**
     * Gets array of all "Field" elements
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Field[] getFieldArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(FIELD$0, targetList);
            org.datacontract.schemas._2004._07.vtdocsws_domain.Field[] result = new org.datacontract.schemas._2004._07.vtdocsws_domain.Field[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "Field" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Field getFieldArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Field target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Field)get_store().find_element_user(FIELD$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Tests for nil ith "Field" element
     */
    public boolean isNilFieldArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Field target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Field)get_store().find_element_user(FIELD$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "Field" element
     */
    public int sizeOfFieldArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FIELD$0);
        }
    }
    
    /**
     * Sets array of all "Field" element
     */
    public void setFieldArray(org.datacontract.schemas._2004._07.vtdocsws_domain.Field[] fieldArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(fieldArray, FIELD$0);
        }
    }
    
    /**
     * Sets ith "Field" element
     */
    public void setFieldArray(int i, org.datacontract.schemas._2004._07.vtdocsws_domain.Field field)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Field target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Field)get_store().find_element_user(FIELD$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(field);
        }
    }
    
    /**
     * Nils the ith "Field" element
     */
    public void setNilFieldArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Field target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Field)get_store().find_element_user(FIELD$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "Field" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Field insertNewField(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Field target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Field)get_store().insert_element_user(FIELD$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "Field" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Field addNewField()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Field target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Field)get_store().add_element_user(FIELD$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "Field" element
     */
    public void removeField(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FIELD$0, i);
        }
    }
}
