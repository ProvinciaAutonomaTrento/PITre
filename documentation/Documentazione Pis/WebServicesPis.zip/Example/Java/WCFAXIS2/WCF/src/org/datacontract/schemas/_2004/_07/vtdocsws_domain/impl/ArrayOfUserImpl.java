/*
 * XML Type:  ArrayOfUser
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * An XML ArrayOfUser(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain).
 *
 * This is a complex type.
 */
public class ArrayOfUserImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser
{
    
    public ArrayOfUserImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName USER$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "User");
    
    
    /**
     * Gets array of all "User" elements
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.User[] getUserArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(USER$0, targetList);
            org.datacontract.schemas._2004._07.vtdocsws_domain.User[] result = new org.datacontract.schemas._2004._07.vtdocsws_domain.User[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "User" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.User getUserArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.User target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.User)get_store().find_element_user(USER$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Tests for nil ith "User" element
     */
    public boolean isNilUserArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.User target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.User)get_store().find_element_user(USER$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "User" element
     */
    public int sizeOfUserArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(USER$0);
        }
    }
    
    /**
     * Sets array of all "User" element
     */
    public void setUserArray(org.datacontract.schemas._2004._07.vtdocsws_domain.User[] userArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(userArray, USER$0);
        }
    }
    
    /**
     * Sets ith "User" element
     */
    public void setUserArray(int i, org.datacontract.schemas._2004._07.vtdocsws_domain.User user)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.User target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.User)get_store().find_element_user(USER$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(user);
        }
    }
    
    /**
     * Nils the ith "User" element
     */
    public void setNilUserArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.User target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.User)get_store().find_element_user(USER$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "User" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.User insertNewUser(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.User target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.User)get_store().insert_element_user(USER$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "User" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.User addNewUser()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.User target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.User)get_store().add_element_user(USER$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "User" element
     */
    public void removeUser(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(USER$0, i);
        }
    }
}
