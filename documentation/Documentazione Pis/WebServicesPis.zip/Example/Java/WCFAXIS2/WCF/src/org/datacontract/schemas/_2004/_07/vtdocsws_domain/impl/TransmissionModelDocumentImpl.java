/*
 * An XML document type.
 * Localname: TransmissionModel
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModelDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one TransmissionModel(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class TransmissionModelDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModelDocument
{
    
    public TransmissionModelDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TRANSMISSIONMODEL$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "TransmissionModel");
    
    
    /**
     * Gets the "TransmissionModel" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel getTransmissionModel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel)get_store().find_element_user(TRANSMISSIONMODEL$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "TransmissionModel" element
     */
    public boolean isNilTransmissionModel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel)get_store().find_element_user(TRANSMISSIONMODEL$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "TransmissionModel" element
     */
    public void setTransmissionModel(org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel transmissionModel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel)get_store().find_element_user(TRANSMISSIONMODEL$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel)get_store().add_element_user(TRANSMISSIONMODEL$0);
            }
            target.set(transmissionModel);
        }
    }
    
    /**
     * Appends and returns a new empty "TransmissionModel" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel addNewTransmissionModel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel)get_store().add_element_user(TRANSMISSIONMODEL$0);
            return target;
        }
    }
    
    /**
     * Nils the "TransmissionModel" element
     */
    public void setNilTransmissionModel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel)get_store().find_element_user(TRANSMISSIONMODEL$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.TransmissionModel)get_store().add_element_user(TRANSMISSIONMODEL$0);
            }
            target.setNil();
        }
    }
}
