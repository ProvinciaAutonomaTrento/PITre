/*
 * An XML document type.
 * Localname: GetTemplatePrjResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetTemplatePrj
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_projects_gettemplateprj.GetTemplatePrjResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_projects_gettemplateprj.impl;
/**
 * A document containing one GetTemplatePrjResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetTemplatePrj) element.
 *
 * This is a complex type.
 */
public class GetTemplatePrjResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_projects_gettemplateprj.GetTemplatePrjResponseDocument
{
    
    public GetTemplatePrjResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETTEMPLATEPRJRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetTemplatePrj", "GetTemplatePrjResponse");
    
    
    /**
     * Gets the "GetTemplatePrjResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_gettemplateprj.GetTemplatePrjResponse getGetTemplatePrjResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_gettemplateprj.GetTemplatePrjResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_gettemplateprj.GetTemplatePrjResponse)get_store().find_element_user(GETTEMPLATEPRJRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetTemplatePrjResponse" element
     */
    public boolean isNilGetTemplatePrjResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_gettemplateprj.GetTemplatePrjResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_gettemplateprj.GetTemplatePrjResponse)get_store().find_element_user(GETTEMPLATEPRJRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetTemplatePrjResponse" element
     */
    public void setGetTemplatePrjResponse(org.datacontract.schemas._2004._07.vtdocsws_services_projects_gettemplateprj.GetTemplatePrjResponse getTemplatePrjResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_gettemplateprj.GetTemplatePrjResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_gettemplateprj.GetTemplatePrjResponse)get_store().find_element_user(GETTEMPLATEPRJRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_gettemplateprj.GetTemplatePrjResponse)get_store().add_element_user(GETTEMPLATEPRJRESPONSE$0);
            }
            target.set(getTemplatePrjResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "GetTemplatePrjResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_gettemplateprj.GetTemplatePrjResponse addNewGetTemplatePrjResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_gettemplateprj.GetTemplatePrjResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_gettemplateprj.GetTemplatePrjResponse)get_store().add_element_user(GETTEMPLATEPRJRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetTemplatePrjResponse" element
     */
    public void setNilGetTemplatePrjResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_gettemplateprj.GetTemplatePrjResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_gettemplateprj.GetTemplatePrjResponse)get_store().find_element_user(GETTEMPLATEPRJRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_gettemplateprj.GetTemplatePrjResponse)get_store().add_element_user(GETTEMPLATEPRJRESPONSE$0);
            }
            target.setNil();
        }
    }
}
