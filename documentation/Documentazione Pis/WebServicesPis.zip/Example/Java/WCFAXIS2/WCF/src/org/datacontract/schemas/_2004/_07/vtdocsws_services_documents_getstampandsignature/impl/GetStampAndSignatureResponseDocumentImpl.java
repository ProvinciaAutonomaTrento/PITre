/*
 * An XML document type.
 * Localname: GetStampAndSignatureResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetStampAndSignature
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.impl;
/**
 * A document containing one GetStampAndSignatureResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetStampAndSignature) element.
 *
 * This is a complex type.
 */
public class GetStampAndSignatureResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureResponseDocument
{
    
    public GetStampAndSignatureResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSTAMPANDSIGNATURERESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetStampAndSignature", "GetStampAndSignatureResponse");
    
    
    /**
     * Gets the "GetStampAndSignatureResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureResponse getGetStampAndSignatureResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureResponse)get_store().find_element_user(GETSTAMPANDSIGNATURERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetStampAndSignatureResponse" element
     */
    public boolean isNilGetStampAndSignatureResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureResponse)get_store().find_element_user(GETSTAMPANDSIGNATURERESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetStampAndSignatureResponse" element
     */
    public void setGetStampAndSignatureResponse(org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureResponse getStampAndSignatureResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureResponse)get_store().find_element_user(GETSTAMPANDSIGNATURERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureResponse)get_store().add_element_user(GETSTAMPANDSIGNATURERESPONSE$0);
            }
            target.set(getStampAndSignatureResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "GetStampAndSignatureResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureResponse addNewGetStampAndSignatureResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureResponse)get_store().add_element_user(GETSTAMPANDSIGNATURERESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetStampAndSignatureResponse" element
     */
    public void setNilGetStampAndSignatureResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureResponse)get_store().find_element_user(GETSTAMPANDSIGNATURERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureResponse)get_store().add_element_user(GETSTAMPANDSIGNATURERESPONSE$0);
            }
            target.setNil();
        }
    }
}
