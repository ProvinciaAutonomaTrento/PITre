/*
 * An XML document type.
 * Localname: GetTemplatesDocumentsRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetTemplatesDocuments
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.impl;
/**
 * A document containing one GetTemplatesDocumentsRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetTemplatesDocuments) element.
 *
 * This is a complex type.
 */
public class GetTemplatesDocumentsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsRequestDocument
{
    
    public GetTemplatesDocumentsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETTEMPLATESDOCUMENTSREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetTemplatesDocuments", "GetTemplatesDocumentsRequest");
    
    
    /**
     * Gets the "GetTemplatesDocumentsRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsRequest getGetTemplatesDocumentsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsRequest)get_store().find_element_user(GETTEMPLATESDOCUMENTSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetTemplatesDocumentsRequest" element
     */
    public boolean isNilGetTemplatesDocumentsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsRequest)get_store().find_element_user(GETTEMPLATESDOCUMENTSREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetTemplatesDocumentsRequest" element
     */
    public void setGetTemplatesDocumentsRequest(org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsRequest getTemplatesDocumentsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsRequest)get_store().find_element_user(GETTEMPLATESDOCUMENTSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsRequest)get_store().add_element_user(GETTEMPLATESDOCUMENTSREQUEST$0);
            }
            target.set(getTemplatesDocumentsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "GetTemplatesDocumentsRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsRequest addNewGetTemplatesDocumentsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsRequest)get_store().add_element_user(GETTEMPLATESDOCUMENTSREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetTemplatesDocumentsRequest" element
     */
    public void setNilGetTemplatesDocumentsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsRequest)get_store().find_element_user(GETTEMPLATESDOCUMENTSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsRequest)get_store().add_element_user(GETTEMPLATESDOCUMENTSREQUEST$0);
            }
            target.setNil();
        }
    }
}
