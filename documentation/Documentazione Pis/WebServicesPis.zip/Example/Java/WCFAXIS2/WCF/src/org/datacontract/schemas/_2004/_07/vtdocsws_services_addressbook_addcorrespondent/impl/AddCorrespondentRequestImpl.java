/*
 * XML Type:  AddCorrespondentRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.AddCorrespondent
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentRequest
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.impl;
/**
 * An XML AddCorrespondentRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.AddCorrespondent).
 *
 * This is a complex type.
 */
public class AddCorrespondentRequestImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.RequestImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentRequest
{
    
    public AddCorrespondentRequestImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CORRESPONDENT$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.AddCorrespondent", "Correspondent");
    
    
    /**
     * Gets the "Correspondent" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent getCorrespondent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent)get_store().find_element_user(CORRESPONDENT$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Correspondent" element
     */
    public boolean isNilCorrespondent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent)get_store().find_element_user(CORRESPONDENT$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Correspondent" element
     */
    public boolean isSetCorrespondent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CORRESPONDENT$0) != 0;
        }
    }
    
    /**
     * Sets the "Correspondent" element
     */
    public void setCorrespondent(org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent correspondent)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent)get_store().find_element_user(CORRESPONDENT$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent)get_store().add_element_user(CORRESPONDENT$0);
            }
            target.set(correspondent);
        }
    }
    
    /**
     * Appends and returns a new empty "Correspondent" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent addNewCorrespondent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent)get_store().add_element_user(CORRESPONDENT$0);
            return target;
        }
    }
    
    /**
     * Nils the "Correspondent" element
     */
    public void setNilCorrespondent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent)get_store().find_element_user(CORRESPONDENT$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent)get_store().add_element_user(CORRESPONDENT$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Correspondent" element
     */
    public void unsetCorrespondent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CORRESPONDENT$0, 0);
        }
    }
}
