/*
 * XML Type:  UploadFileToDocumentResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.UploadFileToDocument
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentResponse
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.impl;
/**
 * An XML UploadFileToDocumentResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.UploadFileToDocument).
 *
 * This is a complex type.
 */
public class UploadFileToDocumentResponseImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.ResponseImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_uploadfiletodocument.UploadFileToDocumentResponse
{
    
    public UploadFileToDocumentResponseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
