/*
 * An XML document type.
 * Localname: CreateProjectResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.CreateProject
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.impl;
/**
 * A document containing one CreateProjectResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.CreateProject) element.
 *
 * This is a complex type.
 */
public class CreateProjectResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectResponseDocument
{
    
    public CreateProjectResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CREATEPROJECTRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.CreateProject", "CreateProjectResponse");
    
    
    /**
     * Gets the "CreateProjectResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectResponse getCreateProjectResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectResponse)get_store().find_element_user(CREATEPROJECTRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "CreateProjectResponse" element
     */
    public boolean isNilCreateProjectResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectResponse)get_store().find_element_user(CREATEPROJECTRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "CreateProjectResponse" element
     */
    public void setCreateProjectResponse(org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectResponse createProjectResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectResponse)get_store().find_element_user(CREATEPROJECTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectResponse)get_store().add_element_user(CREATEPROJECTRESPONSE$0);
            }
            target.set(createProjectResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "CreateProjectResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectResponse addNewCreateProjectResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectResponse)get_store().add_element_user(CREATEPROJECTRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "CreateProjectResponse" element
     */
    public void setNilCreateProjectResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectResponse)get_store().find_element_user(CREATEPROJECTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_createproject.CreateProjectResponse)get_store().add_element_user(CREATEPROJECTRESPONSE$0);
            }
            target.setNil();
        }
    }
}
