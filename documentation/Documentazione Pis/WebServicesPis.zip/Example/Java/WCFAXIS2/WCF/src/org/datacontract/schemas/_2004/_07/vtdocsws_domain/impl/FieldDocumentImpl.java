/*
 * An XML document type.
 * Localname: Field
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.FieldDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one Field(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class FieldDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.FieldDocument
{
    
    public FieldDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName FIELD$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Field");
    
    
    /**
     * Gets the "Field" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Field getField()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Field target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Field)get_store().find_element_user(FIELD$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Field" element
     */
    public boolean isNilField()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Field target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Field)get_store().find_element_user(FIELD$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "Field" element
     */
    public void setField(org.datacontract.schemas._2004._07.vtdocsws_domain.Field field)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Field target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Field)get_store().find_element_user(FIELD$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Field)get_store().add_element_user(FIELD$0);
            }
            target.set(field);
        }
    }
    
    /**
     * Appends and returns a new empty "Field" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Field addNewField()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Field target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Field)get_store().add_element_user(FIELD$0);
            return target;
        }
    }
    
    /**
     * Nils the "Field" element
     */
    public void setNilField()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Field target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Field)get_store().find_element_user(FIELD$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Field)get_store().add_element_user(FIELD$0);
            }
            target.setNil();
        }
    }
}
