/*
 * XML Type:  Stamp
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain;


/**
 * An XML Stamp(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain).
 *
 * This is a complex type.
 */
public interface Stamp extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(Stamp.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s618A4BF965398050DC6199178E6A766E").resolveHandle("stampac4dtype");
    
    /**
     * Gets the "Classifications" element
     */
    java.lang.String getClassifications();
    
    /**
     * Gets (as xml) the "Classifications" element
     */
    org.apache.xmlbeans.XmlString xgetClassifications();
    
    /**
     * Tests for nil "Classifications" element
     */
    boolean isNilClassifications();
    
    /**
     * True if has "Classifications" element
     */
    boolean isSetClassifications();
    
    /**
     * Sets the "Classifications" element
     */
    void setClassifications(java.lang.String classifications);
    
    /**
     * Sets (as xml) the "Classifications" element
     */
    void xsetClassifications(org.apache.xmlbeans.XmlString classifications);
    
    /**
     * Nils the "Classifications" element
     */
    void setNilClassifications();
    
    /**
     * Unsets the "Classifications" element
     */
    void unsetClassifications();
    
    /**
     * Gets the "CodeAdministration" element
     */
    java.lang.String getCodeAdministration();
    
    /**
     * Gets (as xml) the "CodeAdministration" element
     */
    org.apache.xmlbeans.XmlString xgetCodeAdministration();
    
    /**
     * Tests for nil "CodeAdministration" element
     */
    boolean isNilCodeAdministration();
    
    /**
     * True if has "CodeAdministration" element
     */
    boolean isSetCodeAdministration();
    
    /**
     * Sets the "CodeAdministration" element
     */
    void setCodeAdministration(java.lang.String codeAdministration);
    
    /**
     * Sets (as xml) the "CodeAdministration" element
     */
    void xsetCodeAdministration(org.apache.xmlbeans.XmlString codeAdministration);
    
    /**
     * Nils the "CodeAdministration" element
     */
    void setNilCodeAdministration();
    
    /**
     * Unsets the "CodeAdministration" element
     */
    void unsetCodeAdministration();
    
    /**
     * Gets the "CodeRegister" element
     */
    java.lang.String getCodeRegister();
    
    /**
     * Gets (as xml) the "CodeRegister" element
     */
    org.apache.xmlbeans.XmlString xgetCodeRegister();
    
    /**
     * Tests for nil "CodeRegister" element
     */
    boolean isNilCodeRegister();
    
    /**
     * True if has "CodeRegister" element
     */
    boolean isSetCodeRegister();
    
    /**
     * Sets the "CodeRegister" element
     */
    void setCodeRegister(java.lang.String codeRegister);
    
    /**
     * Sets (as xml) the "CodeRegister" element
     */
    void xsetCodeRegister(org.apache.xmlbeans.XmlString codeRegister);
    
    /**
     * Nils the "CodeRegister" element
     */
    void setNilCodeRegister();
    
    /**
     * Unsets the "CodeRegister" element
     */
    void unsetCodeRegister();
    
    /**
     * Gets the "CodeRf" element
     */
    java.lang.String getCodeRf();
    
    /**
     * Gets (as xml) the "CodeRf" element
     */
    org.apache.xmlbeans.XmlString xgetCodeRf();
    
    /**
     * Tests for nil "CodeRf" element
     */
    boolean isNilCodeRf();
    
    /**
     * True if has "CodeRf" element
     */
    boolean isSetCodeRf();
    
    /**
     * Sets the "CodeRf" element
     */
    void setCodeRf(java.lang.String codeRf);
    
    /**
     * Sets (as xml) the "CodeRf" element
     */
    void xsetCodeRf(org.apache.xmlbeans.XmlString codeRf);
    
    /**
     * Nils the "CodeRf" element
     */
    void setNilCodeRf();
    
    /**
     * Unsets the "CodeRf" element
     */
    void unsetCodeRf();
    
    /**
     * Gets the "CodeUO" element
     */
    java.lang.String getCodeUO();
    
    /**
     * Gets (as xml) the "CodeUO" element
     */
    org.apache.xmlbeans.XmlString xgetCodeUO();
    
    /**
     * Tests for nil "CodeUO" element
     */
    boolean isNilCodeUO();
    
    /**
     * True if has "CodeUO" element
     */
    boolean isSetCodeUO();
    
    /**
     * Sets the "CodeUO" element
     */
    void setCodeUO(java.lang.String codeUO);
    
    /**
     * Sets (as xml) the "CodeUO" element
     */
    void xsetCodeUO(org.apache.xmlbeans.XmlString codeUO);
    
    /**
     * Nils the "CodeUO" element
     */
    void setNilCodeUO();
    
    /**
     * Unsets the "CodeUO" element
     */
    void unsetCodeUO();
    
    /**
     * Gets the "DataProtocol" element
     */
    java.lang.String getDataProtocol();
    
    /**
     * Gets (as xml) the "DataProtocol" element
     */
    org.apache.xmlbeans.XmlString xgetDataProtocol();
    
    /**
     * Tests for nil "DataProtocol" element
     */
    boolean isNilDataProtocol();
    
    /**
     * True if has "DataProtocol" element
     */
    boolean isSetDataProtocol();
    
    /**
     * Sets the "DataProtocol" element
     */
    void setDataProtocol(java.lang.String dataProtocol);
    
    /**
     * Sets (as xml) the "DataProtocol" element
     */
    void xsetDataProtocol(org.apache.xmlbeans.XmlString dataProtocol);
    
    /**
     * Nils the "DataProtocol" element
     */
    void setNilDataProtocol();
    
    /**
     * Unsets the "DataProtocol" element
     */
    void unsetDataProtocol();
    
    /**
     * Gets the "DocNumber" element
     */
    java.lang.String getDocNumber();
    
    /**
     * Gets (as xml) the "DocNumber" element
     */
    org.apache.xmlbeans.XmlString xgetDocNumber();
    
    /**
     * Tests for nil "DocNumber" element
     */
    boolean isNilDocNumber();
    
    /**
     * True if has "DocNumber" element
     */
    boolean isSetDocNumber();
    
    /**
     * Sets the "DocNumber" element
     */
    void setDocNumber(java.lang.String docNumber);
    
    /**
     * Sets (as xml) the "DocNumber" element
     */
    void xsetDocNumber(org.apache.xmlbeans.XmlString docNumber);
    
    /**
     * Nils the "DocNumber" element
     */
    void setNilDocNumber();
    
    /**
     * Unsets the "DocNumber" element
     */
    void unsetDocNumber();
    
    /**
     * Gets the "NumberAtthachements" element
     */
    java.lang.String getNumberAtthachements();
    
    /**
     * Gets (as xml) the "NumberAtthachements" element
     */
    org.apache.xmlbeans.XmlString xgetNumberAtthachements();
    
    /**
     * Tests for nil "NumberAtthachements" element
     */
    boolean isNilNumberAtthachements();
    
    /**
     * True if has "NumberAtthachements" element
     */
    boolean isSetNumberAtthachements();
    
    /**
     * Sets the "NumberAtthachements" element
     */
    void setNumberAtthachements(java.lang.String numberAtthachements);
    
    /**
     * Sets (as xml) the "NumberAtthachements" element
     */
    void xsetNumberAtthachements(org.apache.xmlbeans.XmlString numberAtthachements);
    
    /**
     * Nils the "NumberAtthachements" element
     */
    void setNilNumberAtthachements();
    
    /**
     * Unsets the "NumberAtthachements" element
     */
    void unsetNumberAtthachements();
    
    /**
     * Gets the "NumberProtocol" element
     */
    java.lang.String getNumberProtocol();
    
    /**
     * Gets (as xml) the "NumberProtocol" element
     */
    org.apache.xmlbeans.XmlString xgetNumberProtocol();
    
    /**
     * Tests for nil "NumberProtocol" element
     */
    boolean isNilNumberProtocol();
    
    /**
     * True if has "NumberProtocol" element
     */
    boolean isSetNumberProtocol();
    
    /**
     * Sets the "NumberProtocol" element
     */
    void setNumberProtocol(java.lang.String numberProtocol);
    
    /**
     * Sets (as xml) the "NumberProtocol" element
     */
    void xsetNumberProtocol(org.apache.xmlbeans.XmlString numberProtocol);
    
    /**
     * Nils the "NumberProtocol" element
     */
    void setNilNumberProtocol();
    
    /**
     * Unsets the "NumberProtocol" element
     */
    void unsetNumberProtocol();
    
    /**
     * Gets the "SignatureValue" element
     */
    java.lang.String getSignatureValue();
    
    /**
     * Gets (as xml) the "SignatureValue" element
     */
    org.apache.xmlbeans.XmlString xgetSignatureValue();
    
    /**
     * Tests for nil "SignatureValue" element
     */
    boolean isNilSignatureValue();
    
    /**
     * True if has "SignatureValue" element
     */
    boolean isSetSignatureValue();
    
    /**
     * Sets the "SignatureValue" element
     */
    void setSignatureValue(java.lang.String signatureValue);
    
    /**
     * Sets (as xml) the "SignatureValue" element
     */
    void xsetSignatureValue(org.apache.xmlbeans.XmlString signatureValue);
    
    /**
     * Nils the "SignatureValue" element
     */
    void setNilSignatureValue();
    
    /**
     * Unsets the "SignatureValue" element
     */
    void unsetSignatureValue();
    
    /**
     * Gets the "StampValue" element
     */
    java.lang.String getStampValue();
    
    /**
     * Gets (as xml) the "StampValue" element
     */
    org.apache.xmlbeans.XmlString xgetStampValue();
    
    /**
     * Tests for nil "StampValue" element
     */
    boolean isNilStampValue();
    
    /**
     * True if has "StampValue" element
     */
    boolean isSetStampValue();
    
    /**
     * Sets the "StampValue" element
     */
    void setStampValue(java.lang.String stampValue);
    
    /**
     * Sets (as xml) the "StampValue" element
     */
    void xsetStampValue(org.apache.xmlbeans.XmlString stampValue);
    
    /**
     * Nils the "StampValue" element
     */
    void setNilStampValue();
    
    /**
     * Unsets the "StampValue" element
     */
    void unsetStampValue();
    
    /**
     * Gets the "TimeProtocol" element
     */
    java.lang.String getTimeProtocol();
    
    /**
     * Gets (as xml) the "TimeProtocol" element
     */
    org.apache.xmlbeans.XmlString xgetTimeProtocol();
    
    /**
     * Tests for nil "TimeProtocol" element
     */
    boolean isNilTimeProtocol();
    
    /**
     * True if has "TimeProtocol" element
     */
    boolean isSetTimeProtocol();
    
    /**
     * Sets the "TimeProtocol" element
     */
    void setTimeProtocol(java.lang.String timeProtocol);
    
    /**
     * Sets (as xml) the "TimeProtocol" element
     */
    void xsetTimeProtocol(org.apache.xmlbeans.XmlString timeProtocol);
    
    /**
     * Nils the "TimeProtocol" element
     */
    void setNilTimeProtocol();
    
    /**
     * Unsets the "TimeProtocol" element
     */
    void unsetTimeProtocol();
    
    /**
     * Gets the "TypeProtocol" element
     */
    java.lang.String getTypeProtocol();
    
    /**
     * Gets (as xml) the "TypeProtocol" element
     */
    org.apache.xmlbeans.XmlString xgetTypeProtocol();
    
    /**
     * Tests for nil "TypeProtocol" element
     */
    boolean isNilTypeProtocol();
    
    /**
     * True if has "TypeProtocol" element
     */
    boolean isSetTypeProtocol();
    
    /**
     * Sets the "TypeProtocol" element
     */
    void setTypeProtocol(java.lang.String typeProtocol);
    
    /**
     * Sets (as xml) the "TypeProtocol" element
     */
    void xsetTypeProtocol(org.apache.xmlbeans.XmlString typeProtocol);
    
    /**
     * Nils the "TypeProtocol" element
     */
    void setNilTypeProtocol();
    
    /**
     * Unsets the "TypeProtocol" element
     */
    void unsetTypeProtocol();
    
    /**
     * Gets the "Year" element
     */
    java.lang.String getYear();
    
    /**
     * Gets (as xml) the "Year" element
     */
    org.apache.xmlbeans.XmlString xgetYear();
    
    /**
     * Tests for nil "Year" element
     */
    boolean isNilYear();
    
    /**
     * True if has "Year" element
     */
    boolean isSetYear();
    
    /**
     * Sets the "Year" element
     */
    void setYear(java.lang.String year);
    
    /**
     * Sets (as xml) the "Year" element
     */
    void xsetYear(org.apache.xmlbeans.XmlString year);
    
    /**
     * Nils the "Year" element
     */
    void setNilYear();
    
    /**
     * Unsets the "Year" element
     */
    void unsetYear();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp newInstance() {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
