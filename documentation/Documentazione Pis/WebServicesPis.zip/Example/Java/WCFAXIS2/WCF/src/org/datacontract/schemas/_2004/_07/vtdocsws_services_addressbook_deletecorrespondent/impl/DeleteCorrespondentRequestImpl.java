/*
 * XML Type:  DeleteCorrespondentRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.DeleteCorrespondent
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentRequest
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.impl;
/**
 * An XML DeleteCorrespondentRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.DeleteCorrespondent).
 *
 * This is a complex type.
 */
public class DeleteCorrespondentRequestImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.RequestImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentRequest
{
    
    public DeleteCorrespondentRequestImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CORRESPONDENTID$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.DeleteCorrespondent", "CorrespondentId");
    
    
    /**
     * Gets the "CorrespondentId" element
     */
    public java.lang.String getCorrespondentId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CORRESPONDENTID$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CorrespondentId" element
     */
    public org.apache.xmlbeans.XmlString xgetCorrespondentId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRESPONDENTID$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CorrespondentId" element
     */
    public boolean isNilCorrespondentId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRESPONDENTID$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CorrespondentId" element
     */
    public boolean isSetCorrespondentId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CORRESPONDENTID$0) != 0;
        }
    }
    
    /**
     * Sets the "CorrespondentId" element
     */
    public void setCorrespondentId(java.lang.String correspondentId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CORRESPONDENTID$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CORRESPONDENTID$0);
            }
            target.setStringValue(correspondentId);
        }
    }
    
    /**
     * Sets (as xml) the "CorrespondentId" element
     */
    public void xsetCorrespondentId(org.apache.xmlbeans.XmlString correspondentId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRESPONDENTID$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CORRESPONDENTID$0);
            }
            target.set(correspondentId);
        }
    }
    
    /**
     * Nils the "CorrespondentId" element
     */
    public void setNilCorrespondentId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRESPONDENTID$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CORRESPONDENTID$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CorrespondentId" element
     */
    public void unsetCorrespondentId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CORRESPONDENTID$0, 0);
        }
    }
}
