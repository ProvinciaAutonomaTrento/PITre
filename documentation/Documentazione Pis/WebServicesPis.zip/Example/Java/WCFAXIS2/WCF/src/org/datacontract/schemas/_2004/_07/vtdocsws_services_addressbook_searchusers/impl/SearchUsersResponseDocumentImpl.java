/*
 * An XML document type.
 * Localname: SearchUsersResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.SearchUsers
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.impl;
/**
 * A document containing one SearchUsersResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.SearchUsers) element.
 *
 * This is a complex type.
 */
public class SearchUsersResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersResponseDocument
{
    
    public SearchUsersResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SEARCHUSERSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.SearchUsers", "SearchUsersResponse");
    
    
    /**
     * Gets the "SearchUsersResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersResponse getSearchUsersResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersResponse)get_store().find_element_user(SEARCHUSERSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "SearchUsersResponse" element
     */
    public boolean isNilSearchUsersResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersResponse)get_store().find_element_user(SEARCHUSERSRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "SearchUsersResponse" element
     */
    public void setSearchUsersResponse(org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersResponse searchUsersResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersResponse)get_store().find_element_user(SEARCHUSERSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersResponse)get_store().add_element_user(SEARCHUSERSRESPONSE$0);
            }
            target.set(searchUsersResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "SearchUsersResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersResponse addNewSearchUsersResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersResponse)get_store().add_element_user(SEARCHUSERSRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "SearchUsersResponse" element
     */
    public void setNilSearchUsersResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersResponse)get_store().find_element_user(SEARCHUSERSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersResponse)get_store().add_element_user(SEARCHUSERSRESPONSE$0);
            }
            target.setNil();
        }
    }
}
