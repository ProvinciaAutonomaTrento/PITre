/*
 * An XML document type.
 * Localname: EditDocumentResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.EditDocument
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.impl;
/**
 * A document containing one EditDocumentResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.EditDocument) element.
 *
 * This is a complex type.
 */
public class EditDocumentResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentResponseDocument
{
    
    public EditDocumentResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EDITDOCUMENTRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.EditDocument", "EditDocumentResponse");
    
    
    /**
     * Gets the "EditDocumentResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentResponse getEditDocumentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentResponse)get_store().find_element_user(EDITDOCUMENTRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "EditDocumentResponse" element
     */
    public boolean isNilEditDocumentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentResponse)get_store().find_element_user(EDITDOCUMENTRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "EditDocumentResponse" element
     */
    public void setEditDocumentResponse(org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentResponse editDocumentResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentResponse)get_store().find_element_user(EDITDOCUMENTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentResponse)get_store().add_element_user(EDITDOCUMENTRESPONSE$0);
            }
            target.set(editDocumentResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "EditDocumentResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentResponse addNewEditDocumentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentResponse)get_store().add_element_user(EDITDOCUMENTRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "EditDocumentResponse" element
     */
    public void setNilEditDocumentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentResponse)get_store().find_element_user(EDITDOCUMENTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentResponse)get_store().add_element_user(EDITDOCUMENTRESPONSE$0);
            }
            target.setNil();
        }
    }
}
