/*
 * An XML document type.
 * Localname: SearchDocumentsResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.SearchDocuments
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.impl;
/**
 * A document containing one SearchDocumentsResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.SearchDocuments) element.
 *
 * This is a complex type.
 */
public class SearchDocumentsResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsResponseDocument
{
    
    public SearchDocumentsResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SEARCHDOCUMENTSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.SearchDocuments", "SearchDocumentsResponse");
    
    
    /**
     * Gets the "SearchDocumentsResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsResponse getSearchDocumentsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsResponse)get_store().find_element_user(SEARCHDOCUMENTSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "SearchDocumentsResponse" element
     */
    public boolean isNilSearchDocumentsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsResponse)get_store().find_element_user(SEARCHDOCUMENTSRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "SearchDocumentsResponse" element
     */
    public void setSearchDocumentsResponse(org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsResponse searchDocumentsResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsResponse)get_store().find_element_user(SEARCHDOCUMENTSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsResponse)get_store().add_element_user(SEARCHDOCUMENTSRESPONSE$0);
            }
            target.set(searchDocumentsResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "SearchDocumentsResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsResponse addNewSearchDocumentsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsResponse)get_store().add_element_user(SEARCHDOCUMENTSRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "SearchDocumentsResponse" element
     */
    public void setNilSearchDocumentsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsResponse)get_store().find_element_user(SEARCHDOCUMENTSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsResponse)get_store().add_element_user(SEARCHDOCUMENTSRESPONSE$0);
            }
            target.setNil();
        }
    }
}
