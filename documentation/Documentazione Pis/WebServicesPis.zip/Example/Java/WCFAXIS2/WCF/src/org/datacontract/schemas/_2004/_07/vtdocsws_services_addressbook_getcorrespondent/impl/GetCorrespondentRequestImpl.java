/*
 * XML Type:  GetCorrespondentRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.GetCorrespondent
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_getcorrespondent.GetCorrespondentRequest
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_getcorrespondent.impl;
/**
 * An XML GetCorrespondentRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.GetCorrespondent).
 *
 * This is a complex type.
 */
public class GetCorrespondentRequestImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.RequestImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_getcorrespondent.GetCorrespondentRequest
{
    
    public GetCorrespondentRequestImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName IDCORRESPONDENT$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.GetCorrespondent", "IdCorrespondent");
    
    
    /**
     * Gets the "IdCorrespondent" element
     */
    public java.lang.String getIdCorrespondent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDCORRESPONDENT$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "IdCorrespondent" element
     */
    public org.apache.xmlbeans.XmlString xgetIdCorrespondent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDCORRESPONDENT$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "IdCorrespondent" element
     */
    public boolean isNilIdCorrespondent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDCORRESPONDENT$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "IdCorrespondent" element
     */
    public boolean isSetIdCorrespondent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(IDCORRESPONDENT$0) != 0;
        }
    }
    
    /**
     * Sets the "IdCorrespondent" element
     */
    public void setIdCorrespondent(java.lang.String idCorrespondent)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDCORRESPONDENT$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(IDCORRESPONDENT$0);
            }
            target.setStringValue(idCorrespondent);
        }
    }
    
    /**
     * Sets (as xml) the "IdCorrespondent" element
     */
    public void xsetIdCorrespondent(org.apache.xmlbeans.XmlString idCorrespondent)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDCORRESPONDENT$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(IDCORRESPONDENT$0);
            }
            target.set(idCorrespondent);
        }
    }
    
    /**
     * Nils the "IdCorrespondent" element
     */
    public void setNilIdCorrespondent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDCORRESPONDENT$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(IDCORRESPONDENT$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "IdCorrespondent" element
     */
    public void unsetIdCorrespondent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(IDCORRESPONDENT$0, 0);
        }
    }
}
