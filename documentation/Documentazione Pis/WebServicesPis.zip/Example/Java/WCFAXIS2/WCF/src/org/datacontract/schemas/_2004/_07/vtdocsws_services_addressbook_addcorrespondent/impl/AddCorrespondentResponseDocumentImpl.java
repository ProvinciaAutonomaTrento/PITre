/*
 * An XML document type.
 * Localname: AddCorrespondentResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.AddCorrespondent
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.impl;
/**
 * A document containing one AddCorrespondentResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.AddCorrespondent) element.
 *
 * This is a complex type.
 */
public class AddCorrespondentResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentResponseDocument
{
    
    public AddCorrespondentResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ADDCORRESPONDENTRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.AddCorrespondent", "AddCorrespondentResponse");
    
    
    /**
     * Gets the "AddCorrespondentResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentResponse getAddCorrespondentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentResponse)get_store().find_element_user(ADDCORRESPONDENTRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "AddCorrespondentResponse" element
     */
    public boolean isNilAddCorrespondentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentResponse)get_store().find_element_user(ADDCORRESPONDENTRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "AddCorrespondentResponse" element
     */
    public void setAddCorrespondentResponse(org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentResponse addCorrespondentResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentResponse)get_store().find_element_user(ADDCORRESPONDENTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentResponse)get_store().add_element_user(ADDCORRESPONDENTRESPONSE$0);
            }
            target.set(addCorrespondentResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "AddCorrespondentResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentResponse addNewAddCorrespondentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentResponse)get_store().add_element_user(ADDCORRESPONDENTRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "AddCorrespondentResponse" element
     */
    public void setNilAddCorrespondentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentResponse)get_store().find_element_user(ADDCORRESPONDENTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentResponse)get_store().add_element_user(ADDCORRESPONDENTRESPONSE$0);
            }
            target.setNil();
        }
    }
}
