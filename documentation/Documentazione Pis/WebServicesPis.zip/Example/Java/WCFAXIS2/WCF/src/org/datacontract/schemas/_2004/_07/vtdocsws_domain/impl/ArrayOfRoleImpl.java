/*
 * XML Type:  ArrayOfRole
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRole
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * An XML ArrayOfRole(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain).
 *
 * This is a complex type.
 */
public class ArrayOfRoleImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRole
{
    
    public ArrayOfRoleImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ROLE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Role");
    
    
    /**
     * Gets array of all "Role" elements
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Role[] getRoleArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(ROLE$0, targetList);
            org.datacontract.schemas._2004._07.vtdocsws_domain.Role[] result = new org.datacontract.schemas._2004._07.vtdocsws_domain.Role[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "Role" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Role getRoleArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Role target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Role)get_store().find_element_user(ROLE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Tests for nil ith "Role" element
     */
    public boolean isNilRoleArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Role target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Role)get_store().find_element_user(ROLE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "Role" element
     */
    public int sizeOfRoleArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ROLE$0);
        }
    }
    
    /**
     * Sets array of all "Role" element
     */
    public void setRoleArray(org.datacontract.schemas._2004._07.vtdocsws_domain.Role[] roleArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(roleArray, ROLE$0);
        }
    }
    
    /**
     * Sets ith "Role" element
     */
    public void setRoleArray(int i, org.datacontract.schemas._2004._07.vtdocsws_domain.Role role)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Role target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Role)get_store().find_element_user(ROLE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(role);
        }
    }
    
    /**
     * Nils the ith "Role" element
     */
    public void setNilRoleArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Role target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Role)get_store().find_element_user(ROLE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "Role" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Role insertNewRole(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Role target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Role)get_store().insert_element_user(ROLE$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "Role" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Role addNewRole()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Role target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Role)get_store().add_element_user(ROLE$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "Role" element
     */
    public void removeRole(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ROLE$0, i);
        }
    }
}
