/*
 * An XML document type.
 * Localname: GetDocumentStateDiagramRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetDocumentStateDiagram
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.impl;
/**
 * A document containing one GetDocumentStateDiagramRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetDocumentStateDiagram) element.
 *
 * This is a complex type.
 */
public class GetDocumentStateDiagramRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramRequestDocument
{
    
    public GetDocumentStateDiagramRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETDOCUMENTSTATEDIAGRAMREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetDocumentStateDiagram", "GetDocumentStateDiagramRequest");
    
    
    /**
     * Gets the "GetDocumentStateDiagramRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramRequest getGetDocumentStateDiagramRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramRequest)get_store().find_element_user(GETDOCUMENTSTATEDIAGRAMREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetDocumentStateDiagramRequest" element
     */
    public boolean isNilGetDocumentStateDiagramRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramRequest)get_store().find_element_user(GETDOCUMENTSTATEDIAGRAMREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetDocumentStateDiagramRequest" element
     */
    public void setGetDocumentStateDiagramRequest(org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramRequest getDocumentStateDiagramRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramRequest)get_store().find_element_user(GETDOCUMENTSTATEDIAGRAMREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramRequest)get_store().add_element_user(GETDOCUMENTSTATEDIAGRAMREQUEST$0);
            }
            target.set(getDocumentStateDiagramRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "GetDocumentStateDiagramRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramRequest addNewGetDocumentStateDiagramRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramRequest)get_store().add_element_user(GETDOCUMENTSTATEDIAGRAMREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetDocumentStateDiagramRequest" element
     */
    public void setNilGetDocumentStateDiagramRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramRequest)get_store().find_element_user(GETDOCUMENTSTATEDIAGRAMREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentstatediagram.GetDocumentStateDiagramRequest)get_store().add_element_user(GETDOCUMENTSTATEDIAGRAMREQUEST$0);
            }
            target.setNil();
        }
    }
}
