/*
 * An XML document type.
 * Localname: GetDocumentsInProjectResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetDocumentsInProject
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentsinproject.GetDocumentsInProjectResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentsinproject.impl;
/**
 * A document containing one GetDocumentsInProjectResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetDocumentsInProject) element.
 *
 * This is a complex type.
 */
public class GetDocumentsInProjectResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentsinproject.GetDocumentsInProjectResponseDocument
{
    
    public GetDocumentsInProjectResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETDOCUMENTSINPROJECTRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetDocumentsInProject", "GetDocumentsInProjectResponse");
    
    
    /**
     * Gets the "GetDocumentsInProjectResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentsinproject.GetDocumentsInProjectResponse getGetDocumentsInProjectResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentsinproject.GetDocumentsInProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentsinproject.GetDocumentsInProjectResponse)get_store().find_element_user(GETDOCUMENTSINPROJECTRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetDocumentsInProjectResponse" element
     */
    public boolean isNilGetDocumentsInProjectResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentsinproject.GetDocumentsInProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentsinproject.GetDocumentsInProjectResponse)get_store().find_element_user(GETDOCUMENTSINPROJECTRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetDocumentsInProjectResponse" element
     */
    public void setGetDocumentsInProjectResponse(org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentsinproject.GetDocumentsInProjectResponse getDocumentsInProjectResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentsinproject.GetDocumentsInProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentsinproject.GetDocumentsInProjectResponse)get_store().find_element_user(GETDOCUMENTSINPROJECTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentsinproject.GetDocumentsInProjectResponse)get_store().add_element_user(GETDOCUMENTSINPROJECTRESPONSE$0);
            }
            target.set(getDocumentsInProjectResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "GetDocumentsInProjectResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentsinproject.GetDocumentsInProjectResponse addNewGetDocumentsInProjectResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentsinproject.GetDocumentsInProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentsinproject.GetDocumentsInProjectResponse)get_store().add_element_user(GETDOCUMENTSINPROJECTRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetDocumentsInProjectResponse" element
     */
    public void setNilGetDocumentsInProjectResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentsinproject.GetDocumentsInProjectResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentsinproject.GetDocumentsInProjectResponse)get_store().find_element_user(GETDOCUMENTSINPROJECTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocumentsinproject.GetDocumentsInProjectResponse)get_store().add_element_user(GETDOCUMENTSINPROJECTRESPONSE$0);
            }
            target.setNil();
        }
    }
}
