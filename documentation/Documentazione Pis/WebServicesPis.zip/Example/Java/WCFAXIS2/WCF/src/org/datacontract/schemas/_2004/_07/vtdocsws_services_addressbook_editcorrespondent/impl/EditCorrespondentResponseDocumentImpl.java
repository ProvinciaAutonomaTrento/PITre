/*
 * An XML document type.
 * Localname: EditCorrespondentResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.EditCorrespondent
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_editcorrespondent.EditCorrespondentResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_editcorrespondent.impl;
/**
 * A document containing one EditCorrespondentResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.EditCorrespondent) element.
 *
 * This is a complex type.
 */
public class EditCorrespondentResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_editcorrespondent.EditCorrespondentResponseDocument
{
    
    public EditCorrespondentResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EDITCORRESPONDENTRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.EditCorrespondent", "EditCorrespondentResponse");
    
    
    /**
     * Gets the "EditCorrespondentResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_editcorrespondent.EditCorrespondentResponse getEditCorrespondentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_editcorrespondent.EditCorrespondentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_editcorrespondent.EditCorrespondentResponse)get_store().find_element_user(EDITCORRESPONDENTRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "EditCorrespondentResponse" element
     */
    public boolean isNilEditCorrespondentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_editcorrespondent.EditCorrespondentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_editcorrespondent.EditCorrespondentResponse)get_store().find_element_user(EDITCORRESPONDENTRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "EditCorrespondentResponse" element
     */
    public void setEditCorrespondentResponse(org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_editcorrespondent.EditCorrespondentResponse editCorrespondentResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_editcorrespondent.EditCorrespondentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_editcorrespondent.EditCorrespondentResponse)get_store().find_element_user(EDITCORRESPONDENTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_editcorrespondent.EditCorrespondentResponse)get_store().add_element_user(EDITCORRESPONDENTRESPONSE$0);
            }
            target.set(editCorrespondentResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "EditCorrespondentResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_editcorrespondent.EditCorrespondentResponse addNewEditCorrespondentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_editcorrespondent.EditCorrespondentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_editcorrespondent.EditCorrespondentResponse)get_store().add_element_user(EDITCORRESPONDENTRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "EditCorrespondentResponse" element
     */
    public void setNilEditCorrespondentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_editcorrespondent.EditCorrespondentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_editcorrespondent.EditCorrespondentResponse)get_store().find_element_user(EDITCORRESPONDENTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_editcorrespondent.EditCorrespondentResponse)get_store().add_element_user(EDITCORRESPONDENTRESPONSE$0);
            }
            target.setNil();
        }
    }
}
