/*
 * XML Type:  CreateDocumentResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.CreateDocument
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentResponse
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.impl;
/**
 * An XML CreateDocumentResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.CreateDocument).
 *
 * This is a complex type.
 */
public class CreateDocumentResponseImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.ResponseImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentResponse
{
    
    public CreateDocumentResponseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DOCUMENT$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.CreateDocument", "Document");
    
    
    /**
     * Gets the "Document" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Document getDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Document target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Document)get_store().find_element_user(DOCUMENT$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Document" element
     */
    public boolean isNilDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Document target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Document)get_store().find_element_user(DOCUMENT$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Document" element
     */
    public boolean isSetDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DOCUMENT$0) != 0;
        }
    }
    
    /**
     * Sets the "Document" element
     */
    public void setDocument(org.datacontract.schemas._2004._07.vtdocsws_domain.Document document)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Document target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Document)get_store().find_element_user(DOCUMENT$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Document)get_store().add_element_user(DOCUMENT$0);
            }
            target.set(document);
        }
    }
    
    /**
     * Appends and returns a new empty "Document" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Document addNewDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Document target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Document)get_store().add_element_user(DOCUMENT$0);
            return target;
        }
    }
    
    /**
     * Nils the "Document" element
     */
    public void setNilDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Document target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Document)get_store().find_element_user(DOCUMENT$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Document)get_store().add_element_user(DOCUMENT$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Document" element
     */
    public void unsetDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DOCUMENT$0, 0);
        }
    }
}
