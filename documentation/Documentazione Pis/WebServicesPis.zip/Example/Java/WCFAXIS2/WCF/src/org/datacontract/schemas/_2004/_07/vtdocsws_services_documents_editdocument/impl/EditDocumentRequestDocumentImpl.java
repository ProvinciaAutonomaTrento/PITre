/*
 * An XML document type.
 * Localname: EditDocumentRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.EditDocument
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.impl;
/**
 * A document containing one EditDocumentRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.EditDocument) element.
 *
 * This is a complex type.
 */
public class EditDocumentRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentRequestDocument
{
    
    public EditDocumentRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EDITDOCUMENTREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.EditDocument", "EditDocumentRequest");
    
    
    /**
     * Gets the "EditDocumentRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentRequest getEditDocumentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentRequest)get_store().find_element_user(EDITDOCUMENTREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "EditDocumentRequest" element
     */
    public boolean isNilEditDocumentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentRequest)get_store().find_element_user(EDITDOCUMENTREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "EditDocumentRequest" element
     */
    public void setEditDocumentRequest(org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentRequest editDocumentRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentRequest)get_store().find_element_user(EDITDOCUMENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentRequest)get_store().add_element_user(EDITDOCUMENTREQUEST$0);
            }
            target.set(editDocumentRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "EditDocumentRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentRequest addNewEditDocumentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentRequest)get_store().add_element_user(EDITDOCUMENTREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "EditDocumentRequest" element
     */
    public void setNilEditDocumentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentRequest)get_store().find_element_user(EDITDOCUMENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocument.EditDocumentRequest)get_store().add_element_user(EDITDOCUMENTREQUEST$0);
            }
            target.setNil();
        }
    }
}
