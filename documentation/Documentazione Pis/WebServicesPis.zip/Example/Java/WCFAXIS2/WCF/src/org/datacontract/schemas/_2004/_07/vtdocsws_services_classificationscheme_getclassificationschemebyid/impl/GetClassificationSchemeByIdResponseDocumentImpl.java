/*
 * An XML document type.
 * Localname: GetClassificationSchemeByIdResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetClassificationSchemeById
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.impl;
/**
 * A document containing one GetClassificationSchemeByIdResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetClassificationSchemeById) element.
 *
 * This is a complex type.
 */
public class GetClassificationSchemeByIdResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdResponseDocument
{
    
    public GetClassificationSchemeByIdResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETCLASSIFICATIONSCHEMEBYIDRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetClassificationSchemeById", "GetClassificationSchemeByIdResponse");
    
    
    /**
     * Gets the "GetClassificationSchemeByIdResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdResponse getGetClassificationSchemeByIdResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdResponse)get_store().find_element_user(GETCLASSIFICATIONSCHEMEBYIDRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetClassificationSchemeByIdResponse" element
     */
    public boolean isNilGetClassificationSchemeByIdResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdResponse)get_store().find_element_user(GETCLASSIFICATIONSCHEMEBYIDRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetClassificationSchemeByIdResponse" element
     */
    public void setGetClassificationSchemeByIdResponse(org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdResponse getClassificationSchemeByIdResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdResponse)get_store().find_element_user(GETCLASSIFICATIONSCHEMEBYIDRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdResponse)get_store().add_element_user(GETCLASSIFICATIONSCHEMEBYIDRESPONSE$0);
            }
            target.set(getClassificationSchemeByIdResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "GetClassificationSchemeByIdResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdResponse addNewGetClassificationSchemeByIdResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdResponse)get_store().add_element_user(GETCLASSIFICATIONSCHEMEBYIDRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetClassificationSchemeByIdResponse" element
     */
    public void setNilGetClassificationSchemeByIdResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdResponse)get_store().find_element_user(GETCLASSIFICATIONSCHEMEBYIDRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdResponse)get_store().add_element_user(GETCLASSIFICATIONSCHEMEBYIDRESPONSE$0);
            }
            target.setNil();
        }
    }
}
