/*
 * An XML document type.
 * Localname: Note
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.NoteDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one Note(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class NoteDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.NoteDocument
{
    
    public NoteDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NOTE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Note");
    
    
    /**
     * Gets the "Note" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Note getNote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Note target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Note)get_store().find_element_user(NOTE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Note" element
     */
    public boolean isNilNote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Note target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Note)get_store().find_element_user(NOTE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "Note" element
     */
    public void setNote(org.datacontract.schemas._2004._07.vtdocsws_domain.Note note)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Note target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Note)get_store().find_element_user(NOTE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Note)get_store().add_element_user(NOTE$0);
            }
            target.set(note);
        }
    }
    
    /**
     * Appends and returns a new empty "Note" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Note addNewNote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Note target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Note)get_store().add_element_user(NOTE$0);
            return target;
        }
    }
    
    /**
     * Nils the "Note" element
     */
    public void setNilNote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Note target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Note)get_store().find_element_user(NOTE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Note)get_store().add_element_user(NOTE$0);
            }
            target.setNil();
        }
    }
}
