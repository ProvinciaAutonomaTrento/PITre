/*
 * An XML document type.
 * Localname: CreateDocumentResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.CreateDocument
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.impl;
/**
 * A document containing one CreateDocumentResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.CreateDocument) element.
 *
 * This is a complex type.
 */
public class CreateDocumentResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentResponseDocument
{
    
    public CreateDocumentResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CREATEDOCUMENTRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.CreateDocument", "CreateDocumentResponse");
    
    
    /**
     * Gets the "CreateDocumentResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentResponse getCreateDocumentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentResponse)get_store().find_element_user(CREATEDOCUMENTRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "CreateDocumentResponse" element
     */
    public boolean isNilCreateDocumentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentResponse)get_store().find_element_user(CREATEDOCUMENTRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "CreateDocumentResponse" element
     */
    public void setCreateDocumentResponse(org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentResponse createDocumentResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentResponse)get_store().find_element_user(CREATEDOCUMENTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentResponse)get_store().add_element_user(CREATEDOCUMENTRESPONSE$0);
            }
            target.set(createDocumentResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "CreateDocumentResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentResponse addNewCreateDocumentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentResponse)get_store().add_element_user(CREATEDOCUMENTRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "CreateDocumentResponse" element
     */
    public void setNilCreateDocumentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentResponse)get_store().find_element_user(CREATEDOCUMENTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_createdocument.CreateDocumentResponse)get_store().add_element_user(CREATEDOCUMENTRESPONSE$0);
            }
            target.setNil();
        }
    }
}
