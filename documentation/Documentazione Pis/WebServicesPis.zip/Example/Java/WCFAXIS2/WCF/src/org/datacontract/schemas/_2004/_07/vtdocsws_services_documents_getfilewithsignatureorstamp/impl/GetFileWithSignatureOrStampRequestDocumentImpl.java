/*
 * An XML document type.
 * Localname: GetFileWithSignatureOrStampRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetFileWithSignatureOrStamp
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.impl;
/**
 * A document containing one GetFileWithSignatureOrStampRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetFileWithSignatureOrStamp) element.
 *
 * This is a complex type.
 */
public class GetFileWithSignatureOrStampRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampRequestDocument
{
    
    public GetFileWithSignatureOrStampRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFILEWITHSIGNATUREORSTAMPREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetFileWithSignatureOrStamp", "GetFileWithSignatureOrStampRequest");
    
    
    /**
     * Gets the "GetFileWithSignatureOrStampRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampRequest getGetFileWithSignatureOrStampRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampRequest)get_store().find_element_user(GETFILEWITHSIGNATUREORSTAMPREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetFileWithSignatureOrStampRequest" element
     */
    public boolean isNilGetFileWithSignatureOrStampRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampRequest)get_store().find_element_user(GETFILEWITHSIGNATUREORSTAMPREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetFileWithSignatureOrStampRequest" element
     */
    public void setGetFileWithSignatureOrStampRequest(org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampRequest getFileWithSignatureOrStampRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampRequest)get_store().find_element_user(GETFILEWITHSIGNATUREORSTAMPREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampRequest)get_store().add_element_user(GETFILEWITHSIGNATUREORSTAMPREQUEST$0);
            }
            target.set(getFileWithSignatureOrStampRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "GetFileWithSignatureOrStampRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampRequest addNewGetFileWithSignatureOrStampRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampRequest)get_store().add_element_user(GETFILEWITHSIGNATUREORSTAMPREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetFileWithSignatureOrStampRequest" element
     */
    public void setNilGetFileWithSignatureOrStampRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampRequest)get_store().find_element_user(GETFILEWITHSIGNATUREORSTAMPREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampRequest)get_store().add_element_user(GETFILEWITHSIGNATUREORSTAMPREQUEST$0);
            }
            target.setNil();
        }
    }
}
