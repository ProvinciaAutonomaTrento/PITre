/*
 * XML Type:  GetClassificationSchemeByIdRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetClassificationSchemeById
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdRequest
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.impl;
/**
 * An XML GetClassificationSchemeByIdRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetClassificationSchemeById).
 *
 * This is a complex type.
 */
public class GetClassificationSchemeByIdRequestImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.RequestImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getclassificationschemebyid.GetClassificationSchemeByIdRequest
{
    
    public GetClassificationSchemeByIdRequestImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName IDCLASSIFICATIONSCHEME$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetClassificationSchemeById", "IdClassificationScheme");
    
    
    /**
     * Gets the "IdClassificationScheme" element
     */
    public java.lang.String getIdClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDCLASSIFICATIONSCHEME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "IdClassificationScheme" element
     */
    public org.apache.xmlbeans.XmlString xgetIdClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDCLASSIFICATIONSCHEME$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "IdClassificationScheme" element
     */
    public boolean isNilIdClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDCLASSIFICATIONSCHEME$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "IdClassificationScheme" element
     */
    public boolean isSetIdClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(IDCLASSIFICATIONSCHEME$0) != 0;
        }
    }
    
    /**
     * Sets the "IdClassificationScheme" element
     */
    public void setIdClassificationScheme(java.lang.String idClassificationScheme)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDCLASSIFICATIONSCHEME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(IDCLASSIFICATIONSCHEME$0);
            }
            target.setStringValue(idClassificationScheme);
        }
    }
    
    /**
     * Sets (as xml) the "IdClassificationScheme" element
     */
    public void xsetIdClassificationScheme(org.apache.xmlbeans.XmlString idClassificationScheme)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDCLASSIFICATIONSCHEME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(IDCLASSIFICATIONSCHEME$0);
            }
            target.set(idClassificationScheme);
        }
    }
    
    /**
     * Nils the "IdClassificationScheme" element
     */
    public void setNilIdClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDCLASSIFICATIONSCHEME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(IDCLASSIFICATIONSCHEME$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "IdClassificationScheme" element
     */
    public void unsetIdClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(IDCLASSIFICATIONSCHEME$0, 0);
        }
    }
}
