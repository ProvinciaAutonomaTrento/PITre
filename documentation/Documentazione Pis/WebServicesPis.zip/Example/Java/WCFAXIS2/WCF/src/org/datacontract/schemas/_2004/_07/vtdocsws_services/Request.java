/*
 * XML Type:  Request
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services.Request
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services;


/**
 * An XML Request(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services).
 *
 * This is a complex type.
 */
public interface Request extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(Request.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sE7973456B8A131A9340239C13C204768").resolveHandle("request47b3type");
    
    /**
     * Gets the "AuthenticationToken" element
     */
    java.lang.String getAuthenticationToken();
    
    /**
     * Gets (as xml) the "AuthenticationToken" element
     */
    org.apache.xmlbeans.XmlString xgetAuthenticationToken();
    
    /**
     * Tests for nil "AuthenticationToken" element
     */
    boolean isNilAuthenticationToken();
    
    /**
     * True if has "AuthenticationToken" element
     */
    boolean isSetAuthenticationToken();
    
    /**
     * Sets the "AuthenticationToken" element
     */
    void setAuthenticationToken(java.lang.String authenticationToken);
    
    /**
     * Sets (as xml) the "AuthenticationToken" element
     */
    void xsetAuthenticationToken(org.apache.xmlbeans.XmlString authenticationToken);
    
    /**
     * Nils the "AuthenticationToken" element
     */
    void setNilAuthenticationToken();
    
    /**
     * Unsets the "AuthenticationToken" element
     */
    void unsetAuthenticationToken();
    
    /**
     * Gets the "CodeAdm" element
     */
    java.lang.String getCodeAdm();
    
    /**
     * Gets (as xml) the "CodeAdm" element
     */
    org.apache.xmlbeans.XmlString xgetCodeAdm();
    
    /**
     * Tests for nil "CodeAdm" element
     */
    boolean isNilCodeAdm();
    
    /**
     * True if has "CodeAdm" element
     */
    boolean isSetCodeAdm();
    
    /**
     * Sets the "CodeAdm" element
     */
    void setCodeAdm(java.lang.String codeAdm);
    
    /**
     * Sets (as xml) the "CodeAdm" element
     */
    void xsetCodeAdm(org.apache.xmlbeans.XmlString codeAdm);
    
    /**
     * Nils the "CodeAdm" element
     */
    void setNilCodeAdm();
    
    /**
     * Unsets the "CodeAdm" element
     */
    void unsetCodeAdm();
    
    /**
     * Gets the "CodeApplication" element
     */
    java.lang.String getCodeApplication();
    
    /**
     * Gets (as xml) the "CodeApplication" element
     */
    org.apache.xmlbeans.XmlString xgetCodeApplication();
    
    /**
     * Tests for nil "CodeApplication" element
     */
    boolean isNilCodeApplication();
    
    /**
     * True if has "CodeApplication" element
     */
    boolean isSetCodeApplication();
    
    /**
     * Sets the "CodeApplication" element
     */
    void setCodeApplication(java.lang.String codeApplication);
    
    /**
     * Sets (as xml) the "CodeApplication" element
     */
    void xsetCodeApplication(org.apache.xmlbeans.XmlString codeApplication);
    
    /**
     * Nils the "CodeApplication" element
     */
    void setNilCodeApplication();
    
    /**
     * Unsets the "CodeApplication" element
     */
    void unsetCodeApplication();
    
    /**
     * Gets the "CodeRoleLogin" element
     */
    java.lang.String getCodeRoleLogin();
    
    /**
     * Gets (as xml) the "CodeRoleLogin" element
     */
    org.apache.xmlbeans.XmlString xgetCodeRoleLogin();
    
    /**
     * Tests for nil "CodeRoleLogin" element
     */
    boolean isNilCodeRoleLogin();
    
    /**
     * True if has "CodeRoleLogin" element
     */
    boolean isSetCodeRoleLogin();
    
    /**
     * Sets the "CodeRoleLogin" element
     */
    void setCodeRoleLogin(java.lang.String codeRoleLogin);
    
    /**
     * Sets (as xml) the "CodeRoleLogin" element
     */
    void xsetCodeRoleLogin(org.apache.xmlbeans.XmlString codeRoleLogin);
    
    /**
     * Nils the "CodeRoleLogin" element
     */
    void setNilCodeRoleLogin();
    
    /**
     * Unsets the "CodeRoleLogin" element
     */
    void unsetCodeRoleLogin();
    
    /**
     * Gets the "UserName" element
     */
    java.lang.String getUserName();
    
    /**
     * Gets (as xml) the "UserName" element
     */
    org.apache.xmlbeans.XmlString xgetUserName();
    
    /**
     * Tests for nil "UserName" element
     */
    boolean isNilUserName();
    
    /**
     * True if has "UserName" element
     */
    boolean isSetUserName();
    
    /**
     * Sets the "UserName" element
     */
    void setUserName(java.lang.String userName);
    
    /**
     * Sets (as xml) the "UserName" element
     */
    void xsetUserName(org.apache.xmlbeans.XmlString userName);
    
    /**
     * Nils the "UserName" element
     */
    void setNilUserName();
    
    /**
     * Unsets the "UserName" element
     */
    void unsetUserName();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.datacontract.schemas._2004._07.vtdocsws_services.Request newInstance() {
          return (org.datacontract.schemas._2004._07.vtdocsws_services.Request) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services.Request newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.datacontract.schemas._2004._07.vtdocsws_services.Request) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.datacontract.schemas._2004._07.vtdocsws_services.Request parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services.Request) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services.Request parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services.Request) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.datacontract.schemas._2004._07.vtdocsws_services.Request parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services.Request) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services.Request parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services.Request) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services.Request parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services.Request) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services.Request parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services.Request) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services.Request parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services.Request) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services.Request parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services.Request) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services.Request parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services.Request) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services.Request parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services.Request) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services.Request parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services.Request) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services.Request parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services.Request) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services.Request parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services.Request) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services.Request parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services.Request) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.vtdocsws_services.Request parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services.Request) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.vtdocsws_services.Request parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services.Request) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
