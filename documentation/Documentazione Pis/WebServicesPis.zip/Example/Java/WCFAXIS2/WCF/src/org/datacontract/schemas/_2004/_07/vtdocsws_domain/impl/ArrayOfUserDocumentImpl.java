/*
 * An XML document type.
 * Localname: ArrayOfUser
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUserDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one ArrayOfUser(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class ArrayOfUserDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUserDocument
{
    
    public ArrayOfUserDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ARRAYOFUSER$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "ArrayOfUser");
    
    
    /**
     * Gets the "ArrayOfUser" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser getArrayOfUser()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser)get_store().find_element_user(ARRAYOFUSER$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ArrayOfUser" element
     */
    public boolean isNilArrayOfUser()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser)get_store().find_element_user(ARRAYOFUSER$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ArrayOfUser" element
     */
    public void setArrayOfUser(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser arrayOfUser)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser)get_store().find_element_user(ARRAYOFUSER$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser)get_store().add_element_user(ARRAYOFUSER$0);
            }
            target.set(arrayOfUser);
        }
    }
    
    /**
     * Appends and returns a new empty "ArrayOfUser" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser addNewArrayOfUser()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser)get_store().add_element_user(ARRAYOFUSER$0);
            return target;
        }
    }
    
    /**
     * Nils the "ArrayOfUser" element
     */
    public void setNilArrayOfUser()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser)get_store().find_element_user(ARRAYOFUSER$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser)get_store().add_element_user(ARRAYOFUSER$0);
            }
            target.setNil();
        }
    }
}
