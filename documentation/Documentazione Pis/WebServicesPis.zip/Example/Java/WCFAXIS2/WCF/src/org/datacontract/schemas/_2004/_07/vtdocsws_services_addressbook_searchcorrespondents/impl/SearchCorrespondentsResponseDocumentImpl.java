/*
 * An XML document type.
 * Localname: SearchCorrespondentsResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.SearchCorrespondents
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.impl;
/**
 * A document containing one SearchCorrespondentsResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.SearchCorrespondents) element.
 *
 * This is a complex type.
 */
public class SearchCorrespondentsResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsResponseDocument
{
    
    public SearchCorrespondentsResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SEARCHCORRESPONDENTSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.SearchCorrespondents", "SearchCorrespondentsResponse");
    
    
    /**
     * Gets the "SearchCorrespondentsResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsResponse getSearchCorrespondentsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsResponse)get_store().find_element_user(SEARCHCORRESPONDENTSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "SearchCorrespondentsResponse" element
     */
    public boolean isNilSearchCorrespondentsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsResponse)get_store().find_element_user(SEARCHCORRESPONDENTSRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "SearchCorrespondentsResponse" element
     */
    public void setSearchCorrespondentsResponse(org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsResponse searchCorrespondentsResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsResponse)get_store().find_element_user(SEARCHCORRESPONDENTSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsResponse)get_store().add_element_user(SEARCHCORRESPONDENTSRESPONSE$0);
            }
            target.set(searchCorrespondentsResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "SearchCorrespondentsResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsResponse addNewSearchCorrespondentsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsResponse)get_store().add_element_user(SEARCHCORRESPONDENTSRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "SearchCorrespondentsResponse" element
     */
    public void setNilSearchCorrespondentsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsResponse)get_store().find_element_user(SEARCHCORRESPONDENTSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsResponse)get_store().add_element_user(SEARCHCORRESPONDENTSRESPONSE$0);
            }
            target.setNil();
        }
    }
}
