/*
 * An XML document type.
 * Localname: StateOfDiagram
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagramDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one StateOfDiagram(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class StateOfDiagramDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagramDocument
{
    
    public StateOfDiagramDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName STATEOFDIAGRAM$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "StateOfDiagram");
    
    
    /**
     * Gets the "StateOfDiagram" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram getStateOfDiagram()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram)get_store().find_element_user(STATEOFDIAGRAM$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "StateOfDiagram" element
     */
    public boolean isNilStateOfDiagram()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram)get_store().find_element_user(STATEOFDIAGRAM$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "StateOfDiagram" element
     */
    public void setStateOfDiagram(org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram stateOfDiagram)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram)get_store().find_element_user(STATEOFDIAGRAM$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram)get_store().add_element_user(STATEOFDIAGRAM$0);
            }
            target.set(stateOfDiagram);
        }
    }
    
    /**
     * Appends and returns a new empty "StateOfDiagram" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram addNewStateOfDiagram()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram)get_store().add_element_user(STATEOFDIAGRAM$0);
            return target;
        }
    }
    
    /**
     * Nils the "StateOfDiagram" element
     */
    public void setNilStateOfDiagram()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram)get_store().find_element_user(STATEOFDIAGRAM$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.StateOfDiagram)get_store().add_element_user(STATEOFDIAGRAM$0);
            }
            target.setNil();
        }
    }
}
