/*
 * An XML document type.
 * Localname: ArrayOfRegister
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRegisterDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one ArrayOfRegister(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class ArrayOfRegisterDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRegisterDocument
{
    
    public ArrayOfRegisterDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ARRAYOFREGISTER$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "ArrayOfRegister");
    
    
    /**
     * Gets the "ArrayOfRegister" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRegister getArrayOfRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRegister target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRegister)get_store().find_element_user(ARRAYOFREGISTER$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ArrayOfRegister" element
     */
    public boolean isNilArrayOfRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRegister target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRegister)get_store().find_element_user(ARRAYOFREGISTER$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ArrayOfRegister" element
     */
    public void setArrayOfRegister(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRegister arrayOfRegister)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRegister target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRegister)get_store().find_element_user(ARRAYOFREGISTER$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRegister)get_store().add_element_user(ARRAYOFREGISTER$0);
            }
            target.set(arrayOfRegister);
        }
    }
    
    /**
     * Appends and returns a new empty "ArrayOfRegister" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRegister addNewArrayOfRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRegister target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRegister)get_store().add_element_user(ARRAYOFREGISTER$0);
            return target;
        }
    }
    
    /**
     * Nils the "ArrayOfRegister" element
     */
    public void setNilArrayOfRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRegister target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRegister)get_store().find_element_user(ARRAYOFREGISTER$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRegister)get_store().add_element_user(ARRAYOFREGISTER$0);
            }
            target.setNil();
        }
    }
}
