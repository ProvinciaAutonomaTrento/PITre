/*
 * XML Type:  Stamp
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * An XML Stamp(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain).
 *
 * This is a complex type.
 */
public class StampImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp
{
    
    public StampImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CLASSIFICATIONS$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Classifications");
    private static final javax.xml.namespace.QName CODEADMINISTRATION$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "CodeAdministration");
    private static final javax.xml.namespace.QName CODEREGISTER$4 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "CodeRegister");
    private static final javax.xml.namespace.QName CODERF$6 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "CodeRf");
    private static final javax.xml.namespace.QName CODEUO$8 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "CodeUO");
    private static final javax.xml.namespace.QName DATAPROTOCOL$10 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "DataProtocol");
    private static final javax.xml.namespace.QName DOCNUMBER$12 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "DocNumber");
    private static final javax.xml.namespace.QName NUMBERATTHACHEMENTS$14 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "NumberAtthachements");
    private static final javax.xml.namespace.QName NUMBERPROTOCOL$16 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "NumberProtocol");
    private static final javax.xml.namespace.QName SIGNATUREVALUE$18 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "SignatureValue");
    private static final javax.xml.namespace.QName STAMPVALUE$20 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "StampValue");
    private static final javax.xml.namespace.QName TIMEPROTOCOL$22 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "TimeProtocol");
    private static final javax.xml.namespace.QName TYPEPROTOCOL$24 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "TypeProtocol");
    private static final javax.xml.namespace.QName YEAR$26 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Year");
    
    
    /**
     * Gets the "Classifications" element
     */
    public java.lang.String getClassifications()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CLASSIFICATIONS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Classifications" element
     */
    public org.apache.xmlbeans.XmlString xgetClassifications()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CLASSIFICATIONS$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Classifications" element
     */
    public boolean isNilClassifications()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CLASSIFICATIONS$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Classifications" element
     */
    public boolean isSetClassifications()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CLASSIFICATIONS$0) != 0;
        }
    }
    
    /**
     * Sets the "Classifications" element
     */
    public void setClassifications(java.lang.String classifications)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CLASSIFICATIONS$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CLASSIFICATIONS$0);
            }
            target.setStringValue(classifications);
        }
    }
    
    /**
     * Sets (as xml) the "Classifications" element
     */
    public void xsetClassifications(org.apache.xmlbeans.XmlString classifications)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CLASSIFICATIONS$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CLASSIFICATIONS$0);
            }
            target.set(classifications);
        }
    }
    
    /**
     * Nils the "Classifications" element
     */
    public void setNilClassifications()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CLASSIFICATIONS$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CLASSIFICATIONS$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Classifications" element
     */
    public void unsetClassifications()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CLASSIFICATIONS$0, 0);
        }
    }
    
    /**
     * Gets the "CodeAdministration" element
     */
    public java.lang.String getCodeAdministration()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODEADMINISTRATION$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodeAdministration" element
     */
    public org.apache.xmlbeans.XmlString xgetCodeAdministration()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEADMINISTRATION$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CodeAdministration" element
     */
    public boolean isNilCodeAdministration()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEADMINISTRATION$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CodeAdministration" element
     */
    public boolean isSetCodeAdministration()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODEADMINISTRATION$2) != 0;
        }
    }
    
    /**
     * Sets the "CodeAdministration" element
     */
    public void setCodeAdministration(java.lang.String codeAdministration)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODEADMINISTRATION$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODEADMINISTRATION$2);
            }
            target.setStringValue(codeAdministration);
        }
    }
    
    /**
     * Sets (as xml) the "CodeAdministration" element
     */
    public void xsetCodeAdministration(org.apache.xmlbeans.XmlString codeAdministration)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEADMINISTRATION$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODEADMINISTRATION$2);
            }
            target.set(codeAdministration);
        }
    }
    
    /**
     * Nils the "CodeAdministration" element
     */
    public void setNilCodeAdministration()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEADMINISTRATION$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODEADMINISTRATION$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CodeAdministration" element
     */
    public void unsetCodeAdministration()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODEADMINISTRATION$2, 0);
        }
    }
    
    /**
     * Gets the "CodeRegister" element
     */
    public java.lang.String getCodeRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODEREGISTER$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodeRegister" element
     */
    public org.apache.xmlbeans.XmlString xgetCodeRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEREGISTER$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CodeRegister" element
     */
    public boolean isNilCodeRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEREGISTER$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CodeRegister" element
     */
    public boolean isSetCodeRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODEREGISTER$4) != 0;
        }
    }
    
    /**
     * Sets the "CodeRegister" element
     */
    public void setCodeRegister(java.lang.String codeRegister)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODEREGISTER$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODEREGISTER$4);
            }
            target.setStringValue(codeRegister);
        }
    }
    
    /**
     * Sets (as xml) the "CodeRegister" element
     */
    public void xsetCodeRegister(org.apache.xmlbeans.XmlString codeRegister)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEREGISTER$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODEREGISTER$4);
            }
            target.set(codeRegister);
        }
    }
    
    /**
     * Nils the "CodeRegister" element
     */
    public void setNilCodeRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEREGISTER$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODEREGISTER$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CodeRegister" element
     */
    public void unsetCodeRegister()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODEREGISTER$4, 0);
        }
    }
    
    /**
     * Gets the "CodeRf" element
     */
    public java.lang.String getCodeRf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODERF$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodeRf" element
     */
    public org.apache.xmlbeans.XmlString xgetCodeRf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODERF$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CodeRf" element
     */
    public boolean isNilCodeRf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODERF$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CodeRf" element
     */
    public boolean isSetCodeRf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODERF$6) != 0;
        }
    }
    
    /**
     * Sets the "CodeRf" element
     */
    public void setCodeRf(java.lang.String codeRf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODERF$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODERF$6);
            }
            target.setStringValue(codeRf);
        }
    }
    
    /**
     * Sets (as xml) the "CodeRf" element
     */
    public void xsetCodeRf(org.apache.xmlbeans.XmlString codeRf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODERF$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODERF$6);
            }
            target.set(codeRf);
        }
    }
    
    /**
     * Nils the "CodeRf" element
     */
    public void setNilCodeRf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODERF$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODERF$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CodeRf" element
     */
    public void unsetCodeRf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODERF$6, 0);
        }
    }
    
    /**
     * Gets the "CodeUO" element
     */
    public java.lang.String getCodeUO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODEUO$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodeUO" element
     */
    public org.apache.xmlbeans.XmlString xgetCodeUO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEUO$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CodeUO" element
     */
    public boolean isNilCodeUO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEUO$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CodeUO" element
     */
    public boolean isSetCodeUO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODEUO$8) != 0;
        }
    }
    
    /**
     * Sets the "CodeUO" element
     */
    public void setCodeUO(java.lang.String codeUO)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODEUO$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODEUO$8);
            }
            target.setStringValue(codeUO);
        }
    }
    
    /**
     * Sets (as xml) the "CodeUO" element
     */
    public void xsetCodeUO(org.apache.xmlbeans.XmlString codeUO)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEUO$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODEUO$8);
            }
            target.set(codeUO);
        }
    }
    
    /**
     * Nils the "CodeUO" element
     */
    public void setNilCodeUO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEUO$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODEUO$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CodeUO" element
     */
    public void unsetCodeUO()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODEUO$8, 0);
        }
    }
    
    /**
     * Gets the "DataProtocol" element
     */
    public java.lang.String getDataProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAPROTOCOL$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataProtocol" element
     */
    public org.apache.xmlbeans.XmlString xgetDataProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATAPROTOCOL$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DataProtocol" element
     */
    public boolean isNilDataProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATAPROTOCOL$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DataProtocol" element
     */
    public boolean isSetDataProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DATAPROTOCOL$10) != 0;
        }
    }
    
    /**
     * Sets the "DataProtocol" element
     */
    public void setDataProtocol(java.lang.String dataProtocol)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAPROTOCOL$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATAPROTOCOL$10);
            }
            target.setStringValue(dataProtocol);
        }
    }
    
    /**
     * Sets (as xml) the "DataProtocol" element
     */
    public void xsetDataProtocol(org.apache.xmlbeans.XmlString dataProtocol)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATAPROTOCOL$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DATAPROTOCOL$10);
            }
            target.set(dataProtocol);
        }
    }
    
    /**
     * Nils the "DataProtocol" element
     */
    public void setNilDataProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DATAPROTOCOL$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DATAPROTOCOL$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DataProtocol" element
     */
    public void unsetDataProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DATAPROTOCOL$10, 0);
        }
    }
    
    /**
     * Gets the "DocNumber" element
     */
    public java.lang.String getDocNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DOCNUMBER$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "DocNumber" element
     */
    public org.apache.xmlbeans.XmlString xgetDocNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DOCNUMBER$12, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "DocNumber" element
     */
    public boolean isNilDocNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DOCNUMBER$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "DocNumber" element
     */
    public boolean isSetDocNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DOCNUMBER$12) != 0;
        }
    }
    
    /**
     * Sets the "DocNumber" element
     */
    public void setDocNumber(java.lang.String docNumber)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DOCNUMBER$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DOCNUMBER$12);
            }
            target.setStringValue(docNumber);
        }
    }
    
    /**
     * Sets (as xml) the "DocNumber" element
     */
    public void xsetDocNumber(org.apache.xmlbeans.XmlString docNumber)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DOCNUMBER$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DOCNUMBER$12);
            }
            target.set(docNumber);
        }
    }
    
    /**
     * Nils the "DocNumber" element
     */
    public void setNilDocNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DOCNUMBER$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DOCNUMBER$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "DocNumber" element
     */
    public void unsetDocNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DOCNUMBER$12, 0);
        }
    }
    
    /**
     * Gets the "NumberAtthachements" element
     */
    public java.lang.String getNumberAtthachements()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMBERATTHACHEMENTS$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "NumberAtthachements" element
     */
    public org.apache.xmlbeans.XmlString xgetNumberAtthachements()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMBERATTHACHEMENTS$14, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "NumberAtthachements" element
     */
    public boolean isNilNumberAtthachements()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMBERATTHACHEMENTS$14, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "NumberAtthachements" element
     */
    public boolean isSetNumberAtthachements()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NUMBERATTHACHEMENTS$14) != 0;
        }
    }
    
    /**
     * Sets the "NumberAtthachements" element
     */
    public void setNumberAtthachements(java.lang.String numberAtthachements)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMBERATTHACHEMENTS$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMBERATTHACHEMENTS$14);
            }
            target.setStringValue(numberAtthachements);
        }
    }
    
    /**
     * Sets (as xml) the "NumberAtthachements" element
     */
    public void xsetNumberAtthachements(org.apache.xmlbeans.XmlString numberAtthachements)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMBERATTHACHEMENTS$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NUMBERATTHACHEMENTS$14);
            }
            target.set(numberAtthachements);
        }
    }
    
    /**
     * Nils the "NumberAtthachements" element
     */
    public void setNilNumberAtthachements()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMBERATTHACHEMENTS$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NUMBERATTHACHEMENTS$14);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "NumberAtthachements" element
     */
    public void unsetNumberAtthachements()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NUMBERATTHACHEMENTS$14, 0);
        }
    }
    
    /**
     * Gets the "NumberProtocol" element
     */
    public java.lang.String getNumberProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMBERPROTOCOL$16, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "NumberProtocol" element
     */
    public org.apache.xmlbeans.XmlString xgetNumberProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMBERPROTOCOL$16, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "NumberProtocol" element
     */
    public boolean isNilNumberProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMBERPROTOCOL$16, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "NumberProtocol" element
     */
    public boolean isSetNumberProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NUMBERPROTOCOL$16) != 0;
        }
    }
    
    /**
     * Sets the "NumberProtocol" element
     */
    public void setNumberProtocol(java.lang.String numberProtocol)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMBERPROTOCOL$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMBERPROTOCOL$16);
            }
            target.setStringValue(numberProtocol);
        }
    }
    
    /**
     * Sets (as xml) the "NumberProtocol" element
     */
    public void xsetNumberProtocol(org.apache.xmlbeans.XmlString numberProtocol)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMBERPROTOCOL$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NUMBERPROTOCOL$16);
            }
            target.set(numberProtocol);
        }
    }
    
    /**
     * Nils the "NumberProtocol" element
     */
    public void setNilNumberProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NUMBERPROTOCOL$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NUMBERPROTOCOL$16);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "NumberProtocol" element
     */
    public void unsetNumberProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NUMBERPROTOCOL$16, 0);
        }
    }
    
    /**
     * Gets the "SignatureValue" element
     */
    public java.lang.String getSignatureValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SIGNATUREVALUE$18, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "SignatureValue" element
     */
    public org.apache.xmlbeans.XmlString xgetSignatureValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SIGNATUREVALUE$18, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "SignatureValue" element
     */
    public boolean isNilSignatureValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SIGNATUREVALUE$18, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "SignatureValue" element
     */
    public boolean isSetSignatureValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SIGNATUREVALUE$18) != 0;
        }
    }
    
    /**
     * Sets the "SignatureValue" element
     */
    public void setSignatureValue(java.lang.String signatureValue)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SIGNATUREVALUE$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SIGNATUREVALUE$18);
            }
            target.setStringValue(signatureValue);
        }
    }
    
    /**
     * Sets (as xml) the "SignatureValue" element
     */
    public void xsetSignatureValue(org.apache.xmlbeans.XmlString signatureValue)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SIGNATUREVALUE$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SIGNATUREVALUE$18);
            }
            target.set(signatureValue);
        }
    }
    
    /**
     * Nils the "SignatureValue" element
     */
    public void setNilSignatureValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SIGNATUREVALUE$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SIGNATUREVALUE$18);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "SignatureValue" element
     */
    public void unsetSignatureValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SIGNATUREVALUE$18, 0);
        }
    }
    
    /**
     * Gets the "StampValue" element
     */
    public java.lang.String getStampValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(STAMPVALUE$20, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "StampValue" element
     */
    public org.apache.xmlbeans.XmlString xgetStampValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(STAMPVALUE$20, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "StampValue" element
     */
    public boolean isNilStampValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(STAMPVALUE$20, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "StampValue" element
     */
    public boolean isSetStampValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(STAMPVALUE$20) != 0;
        }
    }
    
    /**
     * Sets the "StampValue" element
     */
    public void setStampValue(java.lang.String stampValue)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(STAMPVALUE$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(STAMPVALUE$20);
            }
            target.setStringValue(stampValue);
        }
    }
    
    /**
     * Sets (as xml) the "StampValue" element
     */
    public void xsetStampValue(org.apache.xmlbeans.XmlString stampValue)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(STAMPVALUE$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(STAMPVALUE$20);
            }
            target.set(stampValue);
        }
    }
    
    /**
     * Nils the "StampValue" element
     */
    public void setNilStampValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(STAMPVALUE$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(STAMPVALUE$20);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "StampValue" element
     */
    public void unsetStampValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(STAMPVALUE$20, 0);
        }
    }
    
    /**
     * Gets the "TimeProtocol" element
     */
    public java.lang.String getTimeProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TIMEPROTOCOL$22, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "TimeProtocol" element
     */
    public org.apache.xmlbeans.XmlString xgetTimeProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TIMEPROTOCOL$22, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "TimeProtocol" element
     */
    public boolean isNilTimeProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TIMEPROTOCOL$22, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "TimeProtocol" element
     */
    public boolean isSetTimeProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TIMEPROTOCOL$22) != 0;
        }
    }
    
    /**
     * Sets the "TimeProtocol" element
     */
    public void setTimeProtocol(java.lang.String timeProtocol)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TIMEPROTOCOL$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TIMEPROTOCOL$22);
            }
            target.setStringValue(timeProtocol);
        }
    }
    
    /**
     * Sets (as xml) the "TimeProtocol" element
     */
    public void xsetTimeProtocol(org.apache.xmlbeans.XmlString timeProtocol)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TIMEPROTOCOL$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TIMEPROTOCOL$22);
            }
            target.set(timeProtocol);
        }
    }
    
    /**
     * Nils the "TimeProtocol" element
     */
    public void setNilTimeProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TIMEPROTOCOL$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TIMEPROTOCOL$22);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "TimeProtocol" element
     */
    public void unsetTimeProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TIMEPROTOCOL$22, 0);
        }
    }
    
    /**
     * Gets the "TypeProtocol" element
     */
    public java.lang.String getTypeProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TYPEPROTOCOL$24, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "TypeProtocol" element
     */
    public org.apache.xmlbeans.XmlString xgetTypeProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TYPEPROTOCOL$24, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "TypeProtocol" element
     */
    public boolean isNilTypeProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TYPEPROTOCOL$24, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "TypeProtocol" element
     */
    public boolean isSetTypeProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TYPEPROTOCOL$24) != 0;
        }
    }
    
    /**
     * Sets the "TypeProtocol" element
     */
    public void setTypeProtocol(java.lang.String typeProtocol)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TYPEPROTOCOL$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TYPEPROTOCOL$24);
            }
            target.setStringValue(typeProtocol);
        }
    }
    
    /**
     * Sets (as xml) the "TypeProtocol" element
     */
    public void xsetTypeProtocol(org.apache.xmlbeans.XmlString typeProtocol)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TYPEPROTOCOL$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TYPEPROTOCOL$24);
            }
            target.set(typeProtocol);
        }
    }
    
    /**
     * Nils the "TypeProtocol" element
     */
    public void setNilTypeProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TYPEPROTOCOL$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TYPEPROTOCOL$24);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "TypeProtocol" element
     */
    public void unsetTypeProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TYPEPROTOCOL$24, 0);
        }
    }
    
    /**
     * Gets the "Year" element
     */
    public java.lang.String getYear()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(YEAR$26, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Year" element
     */
    public org.apache.xmlbeans.XmlString xgetYear()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(YEAR$26, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Year" element
     */
    public boolean isNilYear()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(YEAR$26, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Year" element
     */
    public boolean isSetYear()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(YEAR$26) != 0;
        }
    }
    
    /**
     * Sets the "Year" element
     */
    public void setYear(java.lang.String year)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(YEAR$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(YEAR$26);
            }
            target.setStringValue(year);
        }
    }
    
    /**
     * Sets (as xml) the "Year" element
     */
    public void xsetYear(org.apache.xmlbeans.XmlString year)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(YEAR$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(YEAR$26);
            }
            target.set(year);
        }
    }
    
    /**
     * Nils the "Year" element
     */
    public void setNilYear()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(YEAR$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(YEAR$26);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Year" element
     */
    public void unsetYear()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(YEAR$26, 0);
        }
    }
}
