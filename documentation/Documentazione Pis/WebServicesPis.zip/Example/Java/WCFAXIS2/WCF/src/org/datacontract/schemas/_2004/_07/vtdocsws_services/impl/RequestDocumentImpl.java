/*
 * An XML document type.
 * Localname: Request
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services.RequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services.impl;
/**
 * A document containing one Request(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services) element.
 *
 * This is a complex type.
 */
public class RequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services.RequestDocument
{
    
    public RequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName REQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services", "Request");
    
    
    /**
     * Gets the "Request" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services.Request getRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services.Request target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services.Request)get_store().find_element_user(REQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Request" element
     */
    public boolean isNilRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services.Request target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services.Request)get_store().find_element_user(REQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "Request" element
     */
    public void setRequest(org.datacontract.schemas._2004._07.vtdocsws_services.Request request)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services.Request target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services.Request)get_store().find_element_user(REQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services.Request)get_store().add_element_user(REQUEST$0);
            }
            target.set(request);
        }
    }
    
    /**
     * Appends and returns a new empty "Request" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services.Request addNewRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services.Request target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services.Request)get_store().add_element_user(REQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "Request" element
     */
    public void setNilRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services.Request target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services.Request)get_store().find_element_user(REQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services.Request)get_store().add_element_user(REQUEST$0);
            }
            target.setNil();
        }
    }
}
