/*
 * An XML document type.
 * Localname: GetTemplatesDocumentsResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetTemplatesDocuments
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.impl;
/**
 * A document containing one GetTemplatesDocumentsResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetTemplatesDocuments) element.
 *
 * This is a complex type.
 */
public class GetTemplatesDocumentsResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsResponseDocument
{
    
    public GetTemplatesDocumentsResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETTEMPLATESDOCUMENTSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetTemplatesDocuments", "GetTemplatesDocumentsResponse");
    
    
    /**
     * Gets the "GetTemplatesDocumentsResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsResponse getGetTemplatesDocumentsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsResponse)get_store().find_element_user(GETTEMPLATESDOCUMENTSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetTemplatesDocumentsResponse" element
     */
    public boolean isNilGetTemplatesDocumentsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsResponse)get_store().find_element_user(GETTEMPLATESDOCUMENTSRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetTemplatesDocumentsResponse" element
     */
    public void setGetTemplatesDocumentsResponse(org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsResponse getTemplatesDocumentsResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsResponse)get_store().find_element_user(GETTEMPLATESDOCUMENTSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsResponse)get_store().add_element_user(GETTEMPLATESDOCUMENTSRESPONSE$0);
            }
            target.set(getTemplatesDocumentsResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "GetTemplatesDocumentsResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsResponse addNewGetTemplatesDocumentsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsResponse)get_store().add_element_user(GETTEMPLATESDOCUMENTSRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetTemplatesDocumentsResponse" element
     */
    public void setNilGetTemplatesDocumentsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsResponse)get_store().find_element_user(GETTEMPLATESDOCUMENTSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_gettemplatesdocuments.GetTemplatesDocumentsResponse)get_store().add_element_user(GETTEMPLATESDOCUMENTSRESPONSE$0);
            }
            target.setNil();
        }
    }
}
