/*
 * XML Type:  GetActiveClassificationSchemeRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetActiveClassificationScheme
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeRequest
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.impl;
/**
 * An XML GetActiveClassificationSchemeRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetActiveClassificationScheme).
 *
 * This is a complex type.
 */
public class GetActiveClassificationSchemeRequestImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.RequestImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeRequest
{
    
    public GetActiveClassificationSchemeRequestImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
