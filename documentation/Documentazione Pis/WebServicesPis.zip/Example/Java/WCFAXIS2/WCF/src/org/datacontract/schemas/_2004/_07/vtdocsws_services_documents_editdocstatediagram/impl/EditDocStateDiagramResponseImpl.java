/*
 * XML Type:  EditDocStateDiagramResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.EditDocStateDiagram
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramResponse
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.impl;
/**
 * An XML EditDocStateDiagramResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.EditDocStateDiagram).
 *
 * This is a complex type.
 */
public class EditDocStateDiagramResponseImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.ResponseImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramResponse
{
    
    public EditDocStateDiagramResponseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
