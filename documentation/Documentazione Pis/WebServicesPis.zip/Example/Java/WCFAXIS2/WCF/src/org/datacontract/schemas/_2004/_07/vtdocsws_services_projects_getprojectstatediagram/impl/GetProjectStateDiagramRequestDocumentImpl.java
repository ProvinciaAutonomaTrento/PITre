/*
 * An XML document type.
 * Localname: GetProjectStateDiagramRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProjectStateDiagram
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.impl;
/**
 * A document containing one GetProjectStateDiagramRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProjectStateDiagram) element.
 *
 * This is a complex type.
 */
public class GetProjectStateDiagramRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramRequestDocument
{
    
    public GetProjectStateDiagramRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETPROJECTSTATEDIAGRAMREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProjectStateDiagram", "GetProjectStateDiagramRequest");
    
    
    /**
     * Gets the "GetProjectStateDiagramRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramRequest getGetProjectStateDiagramRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramRequest)get_store().find_element_user(GETPROJECTSTATEDIAGRAMREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetProjectStateDiagramRequest" element
     */
    public boolean isNilGetProjectStateDiagramRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramRequest)get_store().find_element_user(GETPROJECTSTATEDIAGRAMREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetProjectStateDiagramRequest" element
     */
    public void setGetProjectStateDiagramRequest(org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramRequest getProjectStateDiagramRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramRequest)get_store().find_element_user(GETPROJECTSTATEDIAGRAMREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramRequest)get_store().add_element_user(GETPROJECTSTATEDIAGRAMREQUEST$0);
            }
            target.set(getProjectStateDiagramRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "GetProjectStateDiagramRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramRequest addNewGetProjectStateDiagramRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramRequest)get_store().add_element_user(GETPROJECTSTATEDIAGRAMREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetProjectStateDiagramRequest" element
     */
    public void setNilGetProjectStateDiagramRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramRequest)get_store().find_element_user(GETPROJECTSTATEDIAGRAMREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramRequest)get_store().add_element_user(GETPROJECTSTATEDIAGRAMREQUEST$0);
            }
            target.setNil();
        }
    }
}
