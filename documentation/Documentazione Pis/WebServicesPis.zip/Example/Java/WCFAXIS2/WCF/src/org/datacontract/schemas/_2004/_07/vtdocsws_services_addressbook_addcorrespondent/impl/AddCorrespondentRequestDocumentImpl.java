/*
 * An XML document type.
 * Localname: AddCorrespondentRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.AddCorrespondent
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.impl;
/**
 * A document containing one AddCorrespondentRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.AddCorrespondent) element.
 *
 * This is a complex type.
 */
public class AddCorrespondentRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentRequestDocument
{
    
    public AddCorrespondentRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ADDCORRESPONDENTREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.AddCorrespondent", "AddCorrespondentRequest");
    
    
    /**
     * Gets the "AddCorrespondentRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentRequest getAddCorrespondentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentRequest)get_store().find_element_user(ADDCORRESPONDENTREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "AddCorrespondentRequest" element
     */
    public boolean isNilAddCorrespondentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentRequest)get_store().find_element_user(ADDCORRESPONDENTREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "AddCorrespondentRequest" element
     */
    public void setAddCorrespondentRequest(org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentRequest addCorrespondentRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentRequest)get_store().find_element_user(ADDCORRESPONDENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentRequest)get_store().add_element_user(ADDCORRESPONDENTREQUEST$0);
            }
            target.set(addCorrespondentRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "AddCorrespondentRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentRequest addNewAddCorrespondentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentRequest)get_store().add_element_user(ADDCORRESPONDENTREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "AddCorrespondentRequest" element
     */
    public void setNilAddCorrespondentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentRequest)get_store().find_element_user(ADDCORRESPONDENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_addcorrespondent.AddCorrespondentRequest)get_store().add_element_user(ADDCORRESPONDENTREQUEST$0);
            }
            target.setNil();
        }
    }
}
