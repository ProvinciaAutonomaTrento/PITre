/*
 * An XML document type.
 * Localname: Stamp
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.StampDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one Stamp(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class StampDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.StampDocument
{
    
    public StampDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName STAMP$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Stamp");
    
    
    /**
     * Gets the "Stamp" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp getStamp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp)get_store().find_element_user(STAMP$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Stamp" element
     */
    public boolean isNilStamp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp)get_store().find_element_user(STAMP$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "Stamp" element
     */
    public void setStamp(org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp stamp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp)get_store().find_element_user(STAMP$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp)get_store().add_element_user(STAMP$0);
            }
            target.set(stamp);
        }
    }
    
    /**
     * Appends and returns a new empty "Stamp" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp addNewStamp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp)get_store().add_element_user(STAMP$0);
            return target;
        }
    }
    
    /**
     * Nils the "Stamp" element
     */
    public void setNilStamp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp)get_store().find_element_user(STAMP$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Stamp)get_store().add_element_user(STAMP$0);
            }
            target.setNil();
        }
    }
}
