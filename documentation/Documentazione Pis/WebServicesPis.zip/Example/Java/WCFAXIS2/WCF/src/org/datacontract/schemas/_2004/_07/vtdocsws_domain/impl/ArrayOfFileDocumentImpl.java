/*
 * An XML document type.
 * Localname: ArrayOfFile
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFileDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one ArrayOfFile(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class ArrayOfFileDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFileDocument
{
    
    public ArrayOfFileDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ARRAYOFFILE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "ArrayOfFile");
    
    
    /**
     * Gets the "ArrayOfFile" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile getArrayOfFile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile)get_store().find_element_user(ARRAYOFFILE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ArrayOfFile" element
     */
    public boolean isNilArrayOfFile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile)get_store().find_element_user(ARRAYOFFILE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ArrayOfFile" element
     */
    public void setArrayOfFile(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile arrayOfFile)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile)get_store().find_element_user(ARRAYOFFILE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile)get_store().add_element_user(ARRAYOFFILE$0);
            }
            target.set(arrayOfFile);
        }
    }
    
    /**
     * Appends and returns a new empty "ArrayOfFile" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile addNewArrayOfFile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile)get_store().add_element_user(ARRAYOFFILE$0);
            return target;
        }
    }
    
    /**
     * Nils the "ArrayOfFile" element
     */
    public void setNilArrayOfFile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile)get_store().find_element_user(ARRAYOFFILE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile)get_store().add_element_user(ARRAYOFFILE$0);
            }
            target.setNil();
        }
    }
}
