/*
 * An XML document type.
 * Localname: ArrayOfCorrespondent
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondentDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one ArrayOfCorrespondent(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class ArrayOfCorrespondentDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondentDocument
{
    
    public ArrayOfCorrespondentDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ARRAYOFCORRESPONDENT$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "ArrayOfCorrespondent");
    
    
    /**
     * Gets the "ArrayOfCorrespondent" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent getArrayOfCorrespondent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().find_element_user(ARRAYOFCORRESPONDENT$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ArrayOfCorrespondent" element
     */
    public boolean isNilArrayOfCorrespondent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().find_element_user(ARRAYOFCORRESPONDENT$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ArrayOfCorrespondent" element
     */
    public void setArrayOfCorrespondent(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent arrayOfCorrespondent)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().find_element_user(ARRAYOFCORRESPONDENT$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().add_element_user(ARRAYOFCORRESPONDENT$0);
            }
            target.set(arrayOfCorrespondent);
        }
    }
    
    /**
     * Appends and returns a new empty "ArrayOfCorrespondent" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent addNewArrayOfCorrespondent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().add_element_user(ARRAYOFCORRESPONDENT$0);
            return target;
        }
    }
    
    /**
     * Nils the "ArrayOfCorrespondent" element
     */
    public void setNilArrayOfCorrespondent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().find_element_user(ARRAYOFCORRESPONDENT$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent)get_store().add_element_user(ARRAYOFCORRESPONDENT$0);
            }
            target.setNil();
        }
    }
}
