/*
 * An XML document type.
 * Localname: ArrayOfClassificationScheme
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationSchemeDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one ArrayOfClassificationScheme(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class ArrayOfClassificationSchemeDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationSchemeDocument
{
    
    public ArrayOfClassificationSchemeDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ARRAYOFCLASSIFICATIONSCHEME$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "ArrayOfClassificationScheme");
    
    
    /**
     * Gets the "ArrayOfClassificationScheme" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme getArrayOfClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme)get_store().find_element_user(ARRAYOFCLASSIFICATIONSCHEME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ArrayOfClassificationScheme" element
     */
    public boolean isNilArrayOfClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme)get_store().find_element_user(ARRAYOFCLASSIFICATIONSCHEME$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ArrayOfClassificationScheme" element
     */
    public void setArrayOfClassificationScheme(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme arrayOfClassificationScheme)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme)get_store().find_element_user(ARRAYOFCLASSIFICATIONSCHEME$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme)get_store().add_element_user(ARRAYOFCLASSIFICATIONSCHEME$0);
            }
            target.set(arrayOfClassificationScheme);
        }
    }
    
    /**
     * Appends and returns a new empty "ArrayOfClassificationScheme" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme addNewArrayOfClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme)get_store().add_element_user(ARRAYOFCLASSIFICATIONSCHEME$0);
            return target;
        }
    }
    
    /**
     * Nils the "ArrayOfClassificationScheme" element
     */
    public void setNilArrayOfClassificationScheme()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme)get_store().find_element_user(ARRAYOFCLASSIFICATIONSCHEME$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfClassificationScheme)get_store().add_element_user(ARRAYOFCLASSIFICATIONSCHEME$0);
            }
            target.setNil();
        }
    }
}
