/*
 * XML Type:  AddDocInProjectRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.AddDocInProject
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectRequest
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.impl;
/**
 * An XML AddDocInProjectRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.AddDocInProject).
 *
 * This is a complex type.
 */
public class AddDocInProjectRequestImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.RequestImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectRequest
{
    
    public AddDocInProjectRequestImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CODEPROJECT$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.AddDocInProject", "CodeProject");
    private static final javax.xml.namespace.QName IDDOCUMENT$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.AddDocInProject", "IdDocument");
    private static final javax.xml.namespace.QName IDPROJECT$4 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.AddDocInProject", "IdProject");
    
    
    /**
     * Gets the "CodeProject" element
     */
    public java.lang.String getCodeProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODEPROJECT$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodeProject" element
     */
    public org.apache.xmlbeans.XmlString xgetCodeProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEPROJECT$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "CodeProject" element
     */
    public boolean isNilCodeProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEPROJECT$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "CodeProject" element
     */
    public boolean isSetCodeProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODEPROJECT$0) != 0;
        }
    }
    
    /**
     * Sets the "CodeProject" element
     */
    public void setCodeProject(java.lang.String codeProject)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODEPROJECT$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODEPROJECT$0);
            }
            target.setStringValue(codeProject);
        }
    }
    
    /**
     * Sets (as xml) the "CodeProject" element
     */
    public void xsetCodeProject(org.apache.xmlbeans.XmlString codeProject)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEPROJECT$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODEPROJECT$0);
            }
            target.set(codeProject);
        }
    }
    
    /**
     * Nils the "CodeProject" element
     */
    public void setNilCodeProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODEPROJECT$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODEPROJECT$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "CodeProject" element
     */
    public void unsetCodeProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODEPROJECT$0, 0);
        }
    }
    
    /**
     * Gets the "IdDocument" element
     */
    public java.lang.String getIdDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDDOCUMENT$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "IdDocument" element
     */
    public org.apache.xmlbeans.XmlString xgetIdDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDDOCUMENT$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "IdDocument" element
     */
    public boolean isNilIdDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDDOCUMENT$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "IdDocument" element
     */
    public boolean isSetIdDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(IDDOCUMENT$2) != 0;
        }
    }
    
    /**
     * Sets the "IdDocument" element
     */
    public void setIdDocument(java.lang.String idDocument)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDDOCUMENT$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(IDDOCUMENT$2);
            }
            target.setStringValue(idDocument);
        }
    }
    
    /**
     * Sets (as xml) the "IdDocument" element
     */
    public void xsetIdDocument(org.apache.xmlbeans.XmlString idDocument)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDDOCUMENT$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(IDDOCUMENT$2);
            }
            target.set(idDocument);
        }
    }
    
    /**
     * Nils the "IdDocument" element
     */
    public void setNilIdDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDDOCUMENT$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(IDDOCUMENT$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "IdDocument" element
     */
    public void unsetIdDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(IDDOCUMENT$2, 0);
        }
    }
    
    /**
     * Gets the "IdProject" element
     */
    public java.lang.String getIdProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDPROJECT$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "IdProject" element
     */
    public org.apache.xmlbeans.XmlString xgetIdProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDPROJECT$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "IdProject" element
     */
    public boolean isNilIdProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDPROJECT$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "IdProject" element
     */
    public boolean isSetIdProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(IDPROJECT$4) != 0;
        }
    }
    
    /**
     * Sets the "IdProject" element
     */
    public void setIdProject(java.lang.String idProject)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDPROJECT$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(IDPROJECT$4);
            }
            target.setStringValue(idProject);
        }
    }
    
    /**
     * Sets (as xml) the "IdProject" element
     */
    public void xsetIdProject(org.apache.xmlbeans.XmlString idProject)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDPROJECT$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(IDPROJECT$4);
            }
            target.set(idProject);
        }
    }
    
    /**
     * Nils the "IdProject" element
     */
    public void setNilIdProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDPROJECT$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(IDPROJECT$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "IdProject" element
     */
    public void unsetIdProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(IDPROJECT$4, 0);
        }
    }
}
