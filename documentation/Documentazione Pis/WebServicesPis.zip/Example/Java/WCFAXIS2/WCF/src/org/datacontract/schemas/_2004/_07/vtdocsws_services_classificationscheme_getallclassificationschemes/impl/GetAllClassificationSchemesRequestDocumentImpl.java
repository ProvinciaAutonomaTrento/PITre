/*
 * An XML document type.
 * Localname: GetAllClassificationSchemesRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetAllClassificationSchemes
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.impl;
/**
 * A document containing one GetAllClassificationSchemesRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetAllClassificationSchemes) element.
 *
 * This is a complex type.
 */
public class GetAllClassificationSchemesRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesRequestDocument
{
    
    public GetAllClassificationSchemesRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLCLASSIFICATIONSCHEMESREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetAllClassificationSchemes", "GetAllClassificationSchemesRequest");
    
    
    /**
     * Gets the "GetAllClassificationSchemesRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesRequest getGetAllClassificationSchemesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesRequest)get_store().find_element_user(GETALLCLASSIFICATIONSCHEMESREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetAllClassificationSchemesRequest" element
     */
    public boolean isNilGetAllClassificationSchemesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesRequest)get_store().find_element_user(GETALLCLASSIFICATIONSCHEMESREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetAllClassificationSchemesRequest" element
     */
    public void setGetAllClassificationSchemesRequest(org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesRequest getAllClassificationSchemesRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesRequest)get_store().find_element_user(GETALLCLASSIFICATIONSCHEMESREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesRequest)get_store().add_element_user(GETALLCLASSIFICATIONSCHEMESREQUEST$0);
            }
            target.set(getAllClassificationSchemesRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "GetAllClassificationSchemesRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesRequest addNewGetAllClassificationSchemesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesRequest)get_store().add_element_user(GETALLCLASSIFICATIONSCHEMESREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetAllClassificationSchemesRequest" element
     */
    public void setNilGetAllClassificationSchemesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesRequest)get_store().find_element_user(GETALLCLASSIFICATIONSCHEMESREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesRequest)get_store().add_element_user(GETALLCLASSIFICATIONSCHEMESREQUEST$0);
            }
            target.setNil();
        }
    }
}
