/*
 * An XML document type.
 * Localname: SendDocumentResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.SendDocument
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.impl;
/**
 * A document containing one SendDocumentResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.SendDocument) element.
 *
 * This is a complex type.
 */
public class SendDocumentResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentResponseDocument
{
    
    public SendDocumentResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SENDDOCUMENTRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.SendDocument", "SendDocumentResponse");
    
    
    /**
     * Gets the "SendDocumentResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentResponse getSendDocumentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentResponse)get_store().find_element_user(SENDDOCUMENTRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "SendDocumentResponse" element
     */
    public boolean isNilSendDocumentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentResponse)get_store().find_element_user(SENDDOCUMENTRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "SendDocumentResponse" element
     */
    public void setSendDocumentResponse(org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentResponse sendDocumentResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentResponse)get_store().find_element_user(SENDDOCUMENTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentResponse)get_store().add_element_user(SENDDOCUMENTRESPONSE$0);
            }
            target.set(sendDocumentResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "SendDocumentResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentResponse addNewSendDocumentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentResponse)get_store().add_element_user(SENDDOCUMENTRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "SendDocumentResponse" element
     */
    public void setNilSendDocumentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentResponse)get_store().find_element_user(SENDDOCUMENTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentResponse)get_store().add_element_user(SENDDOCUMENTRESPONSE$0);
            }
            target.setNil();
        }
    }
}
