/*
 * XML Type:  GetProjectsByDocumentRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProjectsByDocument
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentRequest
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.impl;
/**
 * An XML GetProjectsByDocumentRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProjectsByDocument).
 *
 * This is a complex type.
 */
public class GetProjectsByDocumentRequestImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.RequestImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectsbydocument.GetProjectsByDocumentRequest
{
    
    public GetProjectsByDocumentRequestImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName IDDOCUMENT$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProjectsByDocument", "IdDocument");
    private static final javax.xml.namespace.QName SIGNATURE$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProjectsByDocument", "Signature");
    
    
    /**
     * Gets the "IdDocument" element
     */
    public java.lang.String getIdDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDDOCUMENT$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "IdDocument" element
     */
    public org.apache.xmlbeans.XmlString xgetIdDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDDOCUMENT$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "IdDocument" element
     */
    public boolean isNilIdDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDDOCUMENT$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "IdDocument" element
     */
    public boolean isSetIdDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(IDDOCUMENT$0) != 0;
        }
    }
    
    /**
     * Sets the "IdDocument" element
     */
    public void setIdDocument(java.lang.String idDocument)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDDOCUMENT$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(IDDOCUMENT$0);
            }
            target.setStringValue(idDocument);
        }
    }
    
    /**
     * Sets (as xml) the "IdDocument" element
     */
    public void xsetIdDocument(org.apache.xmlbeans.XmlString idDocument)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDDOCUMENT$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(IDDOCUMENT$0);
            }
            target.set(idDocument);
        }
    }
    
    /**
     * Nils the "IdDocument" element
     */
    public void setNilIdDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(IDDOCUMENT$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(IDDOCUMENT$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "IdDocument" element
     */
    public void unsetIdDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(IDDOCUMENT$0, 0);
        }
    }
    
    /**
     * Gets the "Signature" element
     */
    public java.lang.String getSignature()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SIGNATURE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Signature" element
     */
    public org.apache.xmlbeans.XmlString xgetSignature()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SIGNATURE$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "Signature" element
     */
    public boolean isNilSignature()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SIGNATURE$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Signature" element
     */
    public boolean isSetSignature()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SIGNATURE$2) != 0;
        }
    }
    
    /**
     * Sets the "Signature" element
     */
    public void setSignature(java.lang.String signature)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SIGNATURE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SIGNATURE$2);
            }
            target.setStringValue(signature);
        }
    }
    
    /**
     * Sets (as xml) the "Signature" element
     */
    public void xsetSignature(org.apache.xmlbeans.XmlString signature)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SIGNATURE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SIGNATURE$2);
            }
            target.set(signature);
        }
    }
    
    /**
     * Nils the "Signature" element
     */
    public void setNilSignature()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SIGNATURE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SIGNATURE$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Signature" element
     */
    public void unsetSignature()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SIGNATURE$2, 0);
        }
    }
}
