/*
 * An XML document type.
 * Localname: GetActiveClassificationSchemeRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetActiveClassificationScheme
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.impl;
/**
 * A document containing one GetActiveClassificationSchemeRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetActiveClassificationScheme) element.
 *
 * This is a complex type.
 */
public class GetActiveClassificationSchemeRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeRequestDocument
{
    
    public GetActiveClassificationSchemeRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETACTIVECLASSIFICATIONSCHEMEREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetActiveClassificationScheme", "GetActiveClassificationSchemeRequest");
    
    
    /**
     * Gets the "GetActiveClassificationSchemeRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeRequest getGetActiveClassificationSchemeRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeRequest)get_store().find_element_user(GETACTIVECLASSIFICATIONSCHEMEREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetActiveClassificationSchemeRequest" element
     */
    public boolean isNilGetActiveClassificationSchemeRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeRequest)get_store().find_element_user(GETACTIVECLASSIFICATIONSCHEMEREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetActiveClassificationSchemeRequest" element
     */
    public void setGetActiveClassificationSchemeRequest(org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeRequest getActiveClassificationSchemeRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeRequest)get_store().find_element_user(GETACTIVECLASSIFICATIONSCHEMEREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeRequest)get_store().add_element_user(GETACTIVECLASSIFICATIONSCHEMEREQUEST$0);
            }
            target.set(getActiveClassificationSchemeRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "GetActiveClassificationSchemeRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeRequest addNewGetActiveClassificationSchemeRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeRequest)get_store().add_element_user(GETACTIVECLASSIFICATIONSCHEMEREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetActiveClassificationSchemeRequest" element
     */
    public void setNilGetActiveClassificationSchemeRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeRequest)get_store().find_element_user(GETACTIVECLASSIFICATIONSCHEMEREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeRequest)get_store().add_element_user(GETACTIVECLASSIFICATIONSCHEMEREQUEST$0);
            }
            target.setNil();
        }
    }
}
