/*
 * XML Type:  Response
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services.Response
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services.impl;
/**
 * An XML Response(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services).
 *
 * This is a complex type.
 */
public class ResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services.Response
{
    
    public ResponseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ERROR$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services", "Error");
    private static final javax.xml.namespace.QName SUCCESS$2 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services", "Success");
    
    
    /**
     * Gets the "Error" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError getError()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError)get_store().find_element_user(ERROR$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Error" element
     */
    public boolean isNilError()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError)get_store().find_element_user(ERROR$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Error" element
     */
    public boolean isSetError()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ERROR$0) != 0;
        }
    }
    
    /**
     * Sets the "Error" element
     */
    public void setError(org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError error)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError)get_store().find_element_user(ERROR$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError)get_store().add_element_user(ERROR$0);
            }
            target.set(error);
        }
    }
    
    /**
     * Appends and returns a new empty "Error" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError addNewError()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError)get_store().add_element_user(ERROR$0);
            return target;
        }
    }
    
    /**
     * Nils the "Error" element
     */
    public void setNilError()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError)get_store().find_element_user(ERROR$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError)get_store().add_element_user(ERROR$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Error" element
     */
    public void unsetError()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ERROR$0, 0);
        }
    }
    
    /**
     * Gets the "Success" element
     */
    public boolean getSuccess()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUCCESS$2, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "Success" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetSuccess()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(SUCCESS$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "Success" element
     */
    public boolean isSetSuccess()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SUCCESS$2) != 0;
        }
    }
    
    /**
     * Sets the "Success" element
     */
    public void setSuccess(boolean success)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUCCESS$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SUCCESS$2);
            }
            target.setBooleanValue(success);
        }
    }
    
    /**
     * Sets (as xml) the "Success" element
     */
    public void xsetSuccess(org.apache.xmlbeans.XmlBoolean success)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(SUCCESS$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(SUCCESS$2);
            }
            target.set(success);
        }
    }
    
    /**
     * Unsets the "Success" element
     */
    public void unsetSuccess()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SUCCESS$2, 0);
        }
    }
}
