/*
 * XML Type:  GetProjectRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProject
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject;


/**
 * An XML GetProjectRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProject).
 *
 * This is a complex type.
 */
public interface GetProjectRequest extends org.datacontract.schemas._2004._07.vtdocsws_services.Request
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(GetProjectRequest.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s4E8A12153D12D8BC5B823C971B9DCCB1").resolveHandle("getprojectrequest6239type");
    
    /**
     * Gets the "ClassificationSchemeId" element
     */
    java.lang.String getClassificationSchemeId();
    
    /**
     * Gets (as xml) the "ClassificationSchemeId" element
     */
    org.apache.xmlbeans.XmlString xgetClassificationSchemeId();
    
    /**
     * Tests for nil "ClassificationSchemeId" element
     */
    boolean isNilClassificationSchemeId();
    
    /**
     * True if has "ClassificationSchemeId" element
     */
    boolean isSetClassificationSchemeId();
    
    /**
     * Sets the "ClassificationSchemeId" element
     */
    void setClassificationSchemeId(java.lang.String classificationSchemeId);
    
    /**
     * Sets (as xml) the "ClassificationSchemeId" element
     */
    void xsetClassificationSchemeId(org.apache.xmlbeans.XmlString classificationSchemeId);
    
    /**
     * Nils the "ClassificationSchemeId" element
     */
    void setNilClassificationSchemeId();
    
    /**
     * Unsets the "ClassificationSchemeId" element
     */
    void unsetClassificationSchemeId();
    
    /**
     * Gets the "CodeProject" element
     */
    java.lang.String getCodeProject();
    
    /**
     * Gets (as xml) the "CodeProject" element
     */
    org.apache.xmlbeans.XmlString xgetCodeProject();
    
    /**
     * Tests for nil "CodeProject" element
     */
    boolean isNilCodeProject();
    
    /**
     * True if has "CodeProject" element
     */
    boolean isSetCodeProject();
    
    /**
     * Sets the "CodeProject" element
     */
    void setCodeProject(java.lang.String codeProject);
    
    /**
     * Sets (as xml) the "CodeProject" element
     */
    void xsetCodeProject(org.apache.xmlbeans.XmlString codeProject);
    
    /**
     * Nils the "CodeProject" element
     */
    void setNilCodeProject();
    
    /**
     * Unsets the "CodeProject" element
     */
    void unsetCodeProject();
    
    /**
     * Gets the "IdProject" element
     */
    java.lang.String getIdProject();
    
    /**
     * Gets (as xml) the "IdProject" element
     */
    org.apache.xmlbeans.XmlString xgetIdProject();
    
    /**
     * Tests for nil "IdProject" element
     */
    boolean isNilIdProject();
    
    /**
     * True if has "IdProject" element
     */
    boolean isSetIdProject();
    
    /**
     * Sets the "IdProject" element
     */
    void setIdProject(java.lang.String idProject);
    
    /**
     * Sets (as xml) the "IdProject" element
     */
    void xsetIdProject(org.apache.xmlbeans.XmlString idProject);
    
    /**
     * Nils the "IdProject" element
     */
    void setNilIdProject();
    
    /**
     * Unsets the "IdProject" element
     */
    void unsetIdProject();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest newInstance() {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getproject.GetProjectRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
