/*
 * An XML document type.
 * Localname: GetDocumentResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetDocument
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.impl;
/**
 * A document containing one GetDocumentResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetDocument) element.
 *
 * This is a complex type.
 */
public class GetDocumentResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentResponseDocument
{
    
    public GetDocumentResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETDOCUMENTRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetDocument", "GetDocumentResponse");
    
    
    /**
     * Gets the "GetDocumentResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentResponse getGetDocumentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentResponse)get_store().find_element_user(GETDOCUMENTRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetDocumentResponse" element
     */
    public boolean isNilGetDocumentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentResponse)get_store().find_element_user(GETDOCUMENTRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetDocumentResponse" element
     */
    public void setGetDocumentResponse(org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentResponse getDocumentResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentResponse)get_store().find_element_user(GETDOCUMENTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentResponse)get_store().add_element_user(GETDOCUMENTRESPONSE$0);
            }
            target.set(getDocumentResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "GetDocumentResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentResponse addNewGetDocumentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentResponse)get_store().add_element_user(GETDOCUMENTRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetDocumentResponse" element
     */
    public void setNilGetDocumentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentResponse)get_store().find_element_user(GETDOCUMENTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentResponse)get_store().add_element_user(GETDOCUMENTRESPONSE$0);
            }
            target.setNil();
        }
    }
}
