/*
 * An XML document type.
 * Localname: GetActiveClassificationSchemeResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetActiveClassificationScheme
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.impl;
/**
 * A document containing one GetActiveClassificationSchemeResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetActiveClassificationScheme) element.
 *
 * This is a complex type.
 */
public class GetActiveClassificationSchemeResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeResponseDocument
{
    
    public GetActiveClassificationSchemeResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETACTIVECLASSIFICATIONSCHEMERESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetActiveClassificationScheme", "GetActiveClassificationSchemeResponse");
    
    
    /**
     * Gets the "GetActiveClassificationSchemeResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeResponse getGetActiveClassificationSchemeResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeResponse)get_store().find_element_user(GETACTIVECLASSIFICATIONSCHEMERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetActiveClassificationSchemeResponse" element
     */
    public boolean isNilGetActiveClassificationSchemeResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeResponse)get_store().find_element_user(GETACTIVECLASSIFICATIONSCHEMERESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetActiveClassificationSchemeResponse" element
     */
    public void setGetActiveClassificationSchemeResponse(org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeResponse getActiveClassificationSchemeResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeResponse)get_store().find_element_user(GETACTIVECLASSIFICATIONSCHEMERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeResponse)get_store().add_element_user(GETACTIVECLASSIFICATIONSCHEMERESPONSE$0);
            }
            target.set(getActiveClassificationSchemeResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "GetActiveClassificationSchemeResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeResponse addNewGetActiveClassificationSchemeResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeResponse)get_store().add_element_user(GETACTIVECLASSIFICATIONSCHEMERESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetActiveClassificationSchemeResponse" element
     */
    public void setNilGetActiveClassificationSchemeResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeResponse)get_store().find_element_user(GETACTIVECLASSIFICATIONSCHEMERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getactiveclassificationscheme.GetActiveClassificationSchemeResponse)get_store().add_element_user(GETACTIVECLASSIFICATIONSCHEMERESPONSE$0);
            }
            target.setNil();
        }
    }
}
