/*
 * XML Type:  ArrayOfProject
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * An XML ArrayOfProject(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain).
 *
 * This is a complex type.
 */
public class ArrayOfProjectImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfProject
{
    
    public ArrayOfProjectImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PROJECT$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Project");
    
    
    /**
     * Gets array of all "Project" elements
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Project[] getProjectArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PROJECT$0, targetList);
            org.datacontract.schemas._2004._07.vtdocsws_domain.Project[] result = new org.datacontract.schemas._2004._07.vtdocsws_domain.Project[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "Project" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Project getProjectArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Project target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Project)get_store().find_element_user(PROJECT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Tests for nil ith "Project" element
     */
    public boolean isNilProjectArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Project target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Project)get_store().find_element_user(PROJECT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "Project" element
     */
    public int sizeOfProjectArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROJECT$0);
        }
    }
    
    /**
     * Sets array of all "Project" element
     */
    public void setProjectArray(org.datacontract.schemas._2004._07.vtdocsws_domain.Project[] projectArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(projectArray, PROJECT$0);
        }
    }
    
    /**
     * Sets ith "Project" element
     */
    public void setProjectArray(int i, org.datacontract.schemas._2004._07.vtdocsws_domain.Project project)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Project target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Project)get_store().find_element_user(PROJECT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(project);
        }
    }
    
    /**
     * Nils the ith "Project" element
     */
    public void setNilProjectArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Project target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Project)get_store().find_element_user(PROJECT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "Project" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Project insertNewProject(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Project target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Project)get_store().insert_element_user(PROJECT$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "Project" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Project addNewProject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Project target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Project)get_store().add_element_user(PROJECT$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "Project" element
     */
    public void removeProject(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROJECT$0, i);
        }
    }
}
