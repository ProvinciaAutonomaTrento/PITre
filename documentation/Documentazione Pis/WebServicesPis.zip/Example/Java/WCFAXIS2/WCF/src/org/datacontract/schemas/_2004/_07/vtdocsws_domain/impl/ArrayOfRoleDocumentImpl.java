/*
 * An XML document type.
 * Localname: ArrayOfRole
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRoleDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one ArrayOfRole(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class ArrayOfRoleDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRoleDocument
{
    
    public ArrayOfRoleDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ARRAYOFROLE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "ArrayOfRole");
    
    
    /**
     * Gets the "ArrayOfRole" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRole getArrayOfRole()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRole target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRole)get_store().find_element_user(ARRAYOFROLE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ArrayOfRole" element
     */
    public boolean isNilArrayOfRole()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRole target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRole)get_store().find_element_user(ARRAYOFROLE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ArrayOfRole" element
     */
    public void setArrayOfRole(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRole arrayOfRole)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRole target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRole)get_store().find_element_user(ARRAYOFROLE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRole)get_store().add_element_user(ARRAYOFROLE$0);
            }
            target.set(arrayOfRole);
        }
    }
    
    /**
     * Appends and returns a new empty "ArrayOfRole" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRole addNewArrayOfRole()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRole target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRole)get_store().add_element_user(ARRAYOFROLE$0);
            return target;
        }
    }
    
    /**
     * Nils the "ArrayOfRole" element
     */
    public void setNilArrayOfRole()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRole target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRole)get_store().find_element_user(ARRAYOFROLE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfRole)get_store().add_element_user(ARRAYOFROLE$0);
            }
            target.setNil();
        }
    }
}
