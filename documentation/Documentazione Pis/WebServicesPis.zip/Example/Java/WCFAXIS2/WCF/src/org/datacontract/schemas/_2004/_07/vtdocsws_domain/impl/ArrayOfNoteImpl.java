/*
 * XML Type:  ArrayOfNote
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * An XML ArrayOfNote(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain).
 *
 * This is a complex type.
 */
public class ArrayOfNoteImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfNote
{
    
    public ArrayOfNoteImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NOTE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Note");
    
    
    /**
     * Gets array of all "Note" elements
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Note[] getNoteArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(NOTE$0, targetList);
            org.datacontract.schemas._2004._07.vtdocsws_domain.Note[] result = new org.datacontract.schemas._2004._07.vtdocsws_domain.Note[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "Note" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Note getNoteArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Note target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Note)get_store().find_element_user(NOTE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Tests for nil ith "Note" element
     */
    public boolean isNilNoteArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Note target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Note)get_store().find_element_user(NOTE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "Note" element
     */
    public int sizeOfNoteArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NOTE$0);
        }
    }
    
    /**
     * Sets array of all "Note" element
     */
    public void setNoteArray(org.datacontract.schemas._2004._07.vtdocsws_domain.Note[] noteArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(noteArray, NOTE$0);
        }
    }
    
    /**
     * Sets ith "Note" element
     */
    public void setNoteArray(int i, org.datacontract.schemas._2004._07.vtdocsws_domain.Note note)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Note target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Note)get_store().find_element_user(NOTE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(note);
        }
    }
    
    /**
     * Nils the ith "Note" element
     */
    public void setNilNoteArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Note target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Note)get_store().find_element_user(NOTE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "Note" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Note insertNewNote(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Note target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Note)get_store().insert_element_user(NOTE$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "Note" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Note addNewNote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Note target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Note)get_store().add_element_user(NOTE$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "Note" element
     */
    public void removeNote(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NOTE$0, i);
        }
    }
}
