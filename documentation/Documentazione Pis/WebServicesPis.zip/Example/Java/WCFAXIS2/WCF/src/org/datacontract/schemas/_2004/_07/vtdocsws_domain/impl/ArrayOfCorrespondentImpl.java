/*
 * XML Type:  ArrayOfCorrespondent
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * An XML ArrayOfCorrespondent(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain).
 *
 * This is a complex type.
 */
public class ArrayOfCorrespondentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfCorrespondent
{
    
    public ArrayOfCorrespondentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CORRESPONDENT$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "Correspondent");
    
    
    /**
     * Gets array of all "Correspondent" elements
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent[] getCorrespondentArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(CORRESPONDENT$0, targetList);
            org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent[] result = new org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "Correspondent" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent getCorrespondentArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent)get_store().find_element_user(CORRESPONDENT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Tests for nil ith "Correspondent" element
     */
    public boolean isNilCorrespondentArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent)get_store().find_element_user(CORRESPONDENT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "Correspondent" element
     */
    public int sizeOfCorrespondentArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CORRESPONDENT$0);
        }
    }
    
    /**
     * Sets array of all "Correspondent" element
     */
    public void setCorrespondentArray(org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent[] correspondentArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(correspondentArray, CORRESPONDENT$0);
        }
    }
    
    /**
     * Sets ith "Correspondent" element
     */
    public void setCorrespondentArray(int i, org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent correspondent)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent)get_store().find_element_user(CORRESPONDENT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(correspondent);
        }
    }
    
    /**
     * Nils the ith "Correspondent" element
     */
    public void setNilCorrespondentArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent)get_store().find_element_user(CORRESPONDENT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "Correspondent" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent insertNewCorrespondent(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent)get_store().insert_element_user(CORRESPONDENT$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "Correspondent" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent addNewCorrespondent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Correspondent)get_store().add_element_user(CORRESPONDENT$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "Correspondent" element
     */
    public void removeCorrespondent(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CORRESPONDENT$0, i);
        }
    }
}
