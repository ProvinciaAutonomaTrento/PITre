/*
 * XML Type:  GetAllClassificationSchemesRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetAllClassificationSchemes
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesRequest
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.impl;
/**
 * An XML GetAllClassificationSchemesRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.ClassificationScheme.GetAllClassificationSchemes).
 *
 * This is a complex type.
 */
public class GetAllClassificationSchemesRequestImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.RequestImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_classificationscheme_getallclassificationschemes.GetAllClassificationSchemesRequest
{
    
    public GetAllClassificationSchemesRequestImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
