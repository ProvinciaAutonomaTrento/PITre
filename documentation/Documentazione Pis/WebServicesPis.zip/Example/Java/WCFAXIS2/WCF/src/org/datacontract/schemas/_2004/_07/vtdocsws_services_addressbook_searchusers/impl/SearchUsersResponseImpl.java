/*
 * XML Type:  SearchUsersResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.SearchUsers
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersResponse
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.impl;
/**
 * An XML SearchUsersResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.SearchUsers).
 *
 * This is a complex type.
 */
public class SearchUsersResponseImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.ResponseImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersResponse
{
    
    public SearchUsersResponseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName USERS$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.SearchUsers", "Users");
    
    
    /**
     * Gets the "Users" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser getUsers()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser)get_store().find_element_user(USERS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Users" element
     */
    public boolean isNilUsers()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser)get_store().find_element_user(USERS$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Users" element
     */
    public boolean isSetUsers()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(USERS$0) != 0;
        }
    }
    
    /**
     * Sets the "Users" element
     */
    public void setUsers(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser users)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser)get_store().find_element_user(USERS$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser)get_store().add_element_user(USERS$0);
            }
            target.set(users);
        }
    }
    
    /**
     * Appends and returns a new empty "Users" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser addNewUsers()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser)get_store().add_element_user(USERS$0);
            return target;
        }
    }
    
    /**
     * Nils the "Users" element
     */
    public void setNilUsers()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser)get_store().find_element_user(USERS$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfUser)get_store().add_element_user(USERS$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Users" element
     */
    public void unsetUsers()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(USERS$0, 0);
        }
    }
}
