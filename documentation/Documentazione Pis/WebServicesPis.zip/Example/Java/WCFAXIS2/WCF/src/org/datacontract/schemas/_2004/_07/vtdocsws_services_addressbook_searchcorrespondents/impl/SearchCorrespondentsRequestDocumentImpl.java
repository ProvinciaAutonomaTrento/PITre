/*
 * An XML document type.
 * Localname: SearchCorrespondentsRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.SearchCorrespondents
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.impl;
/**
 * A document containing one SearchCorrespondentsRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.SearchCorrespondents) element.
 *
 * This is a complex type.
 */
public class SearchCorrespondentsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsRequestDocument
{
    
    public SearchCorrespondentsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SEARCHCORRESPONDENTSREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.SearchCorrespondents", "SearchCorrespondentsRequest");
    
    
    /**
     * Gets the "SearchCorrespondentsRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsRequest getSearchCorrespondentsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsRequest)get_store().find_element_user(SEARCHCORRESPONDENTSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "SearchCorrespondentsRequest" element
     */
    public boolean isNilSearchCorrespondentsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsRequest)get_store().find_element_user(SEARCHCORRESPONDENTSREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "SearchCorrespondentsRequest" element
     */
    public void setSearchCorrespondentsRequest(org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsRequest searchCorrespondentsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsRequest)get_store().find_element_user(SEARCHCORRESPONDENTSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsRequest)get_store().add_element_user(SEARCHCORRESPONDENTSREQUEST$0);
            }
            target.set(searchCorrespondentsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "SearchCorrespondentsRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsRequest addNewSearchCorrespondentsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsRequest)get_store().add_element_user(SEARCHCORRESPONDENTSREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "SearchCorrespondentsRequest" element
     */
    public void setNilSearchCorrespondentsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsRequest)get_store().find_element_user(SEARCHCORRESPONDENTSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchcorrespondents.SearchCorrespondentsRequest)get_store().add_element_user(SEARCHCORRESPONDENTSREQUEST$0);
            }
            target.setNil();
        }
    }
}
