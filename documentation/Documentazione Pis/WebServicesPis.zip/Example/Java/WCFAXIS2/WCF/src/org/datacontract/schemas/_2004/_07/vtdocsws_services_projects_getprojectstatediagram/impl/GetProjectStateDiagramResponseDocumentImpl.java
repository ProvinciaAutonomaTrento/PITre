/*
 * An XML document type.
 * Localname: GetProjectStateDiagramResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProjectStateDiagram
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.impl;
/**
 * A document containing one GetProjectStateDiagramResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProjectStateDiagram) element.
 *
 * This is a complex type.
 */
public class GetProjectStateDiagramResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramResponseDocument
{
    
    public GetProjectStateDiagramResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETPROJECTSTATEDIAGRAMRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetProjectStateDiagram", "GetProjectStateDiagramResponse");
    
    
    /**
     * Gets the "GetProjectStateDiagramResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramResponse getGetProjectStateDiagramResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramResponse)get_store().find_element_user(GETPROJECTSTATEDIAGRAMRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetProjectStateDiagramResponse" element
     */
    public boolean isNilGetProjectStateDiagramResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramResponse)get_store().find_element_user(GETPROJECTSTATEDIAGRAMRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetProjectStateDiagramResponse" element
     */
    public void setGetProjectStateDiagramResponse(org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramResponse getProjectStateDiagramResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramResponse)get_store().find_element_user(GETPROJECTSTATEDIAGRAMRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramResponse)get_store().add_element_user(GETPROJECTSTATEDIAGRAMRESPONSE$0);
            }
            target.set(getProjectStateDiagramResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "GetProjectStateDiagramResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramResponse addNewGetProjectStateDiagramResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramResponse)get_store().add_element_user(GETPROJECTSTATEDIAGRAMRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetProjectStateDiagramResponse" element
     */
    public void setNilGetProjectStateDiagramResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramResponse)get_store().find_element_user(GETPROJECTSTATEDIAGRAMRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_projects_getprojectstatediagram.GetProjectStateDiagramResponse)get_store().add_element_user(GETPROJECTSTATEDIAGRAMRESPONSE$0);
            }
            target.setNil();
        }
    }
}
