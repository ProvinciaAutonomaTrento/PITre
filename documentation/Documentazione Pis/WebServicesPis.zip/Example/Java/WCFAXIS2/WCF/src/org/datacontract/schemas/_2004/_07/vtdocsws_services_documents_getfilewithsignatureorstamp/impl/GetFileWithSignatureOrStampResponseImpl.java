/*
 * XML Type:  GetFileWithSignatureOrStampResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetFileWithSignatureOrStamp
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampResponse
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.impl;
/**
 * An XML GetFileWithSignatureOrStampResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetFileWithSignatureOrStamp).
 *
 * This is a complex type.
 */
public class GetFileWithSignatureOrStampResponseImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.ResponseImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_getfilewithsignatureorstamp.GetFileWithSignatureOrStampResponse
{
    
    public GetFileWithSignatureOrStampResponseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName FILE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetFileWithSignatureOrStamp", "File");
    
    
    /**
     * Gets the "File" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.File getFile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().find_element_user(FILE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "File" element
     */
    public boolean isNilFile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().find_element_user(FILE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "File" element
     */
    public boolean isSetFile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FILE$0) != 0;
        }
    }
    
    /**
     * Sets the "File" element
     */
    public void setFile(org.datacontract.schemas._2004._07.vtdocsws_domain.File file)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().find_element_user(FILE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().add_element_user(FILE$0);
            }
            target.set(file);
        }
    }
    
    /**
     * Appends and returns a new empty "File" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.File addNewFile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().add_element_user(FILE$0);
            return target;
        }
    }
    
    /**
     * Nils the "File" element
     */
    public void setNilFile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().find_element_user(FILE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().add_element_user(FILE$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "File" element
     */
    public void unsetFile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FILE$0, 0);
        }
    }
}
