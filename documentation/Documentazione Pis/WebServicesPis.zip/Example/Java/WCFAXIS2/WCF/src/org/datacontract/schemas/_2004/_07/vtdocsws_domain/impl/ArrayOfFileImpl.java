/*
 * XML Type:  ArrayOfFile
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * An XML ArrayOfFile(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain).
 *
 * This is a complex type.
 */
public class ArrayOfFileImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFile
{
    
    public ArrayOfFileImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName FILE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "File");
    
    
    /**
     * Gets array of all "File" elements
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.File[] getFileArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(FILE$0, targetList);
            org.datacontract.schemas._2004._07.vtdocsws_domain.File[] result = new org.datacontract.schemas._2004._07.vtdocsws_domain.File[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "File" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.File getFileArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().find_element_user(FILE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Tests for nil ith "File" element
     */
    public boolean isNilFileArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().find_element_user(FILE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "File" element
     */
    public int sizeOfFileArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FILE$0);
        }
    }
    
    /**
     * Sets array of all "File" element
     */
    public void setFileArray(org.datacontract.schemas._2004._07.vtdocsws_domain.File[] fileArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(fileArray, FILE$0);
        }
    }
    
    /**
     * Sets ith "File" element
     */
    public void setFileArray(int i, org.datacontract.schemas._2004._07.vtdocsws_domain.File file)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().find_element_user(FILE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(file);
        }
    }
    
    /**
     * Nils the ith "File" element
     */
    public void setNilFileArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().find_element_user(FILE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "File" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.File insertNewFile(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().insert_element_user(FILE$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "File" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.File addNewFile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.File target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.File)get_store().add_element_user(FILE$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "File" element
     */
    public void removeFile(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FILE$0, i);
        }
    }
}
