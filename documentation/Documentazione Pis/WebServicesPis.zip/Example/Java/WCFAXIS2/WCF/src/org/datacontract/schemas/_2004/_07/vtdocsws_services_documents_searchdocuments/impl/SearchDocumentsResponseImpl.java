/*
 * XML Type:  SearchDocumentsResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.SearchDocuments
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsResponse
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.impl;
/**
 * An XML SearchDocumentsResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.SearchDocuments).
 *
 * This is a complex type.
 */
public class SearchDocumentsResponseImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.ResponseImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_searchdocuments.SearchDocumentsResponse
{
    
    public SearchDocumentsResponseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DOCUMENTS$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.SearchDocuments", "Documents");
    
    
    /**
     * Gets the "Documents" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1 getDocuments()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1 target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1)get_store().find_element_user(DOCUMENTS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Documents" element
     */
    public boolean isNilDocuments()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1 target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1)get_store().find_element_user(DOCUMENTS$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Documents" element
     */
    public boolean isSetDocuments()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DOCUMENTS$0) != 0;
        }
    }
    
    /**
     * Sets the "Documents" element
     */
    public void setDocuments(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1 documents)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1 target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1)get_store().find_element_user(DOCUMENTS$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1)get_store().add_element_user(DOCUMENTS$0);
            }
            target.set(documents);
        }
    }
    
    /**
     * Appends and returns a new empty "Documents" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1 addNewDocuments()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1 target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1)get_store().add_element_user(DOCUMENTS$0);
            return target;
        }
    }
    
    /**
     * Nils the "Documents" element
     */
    public void setNilDocuments()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1 target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1)get_store().find_element_user(DOCUMENTS$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1)get_store().add_element_user(DOCUMENTS$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Documents" element
     */
    public void unsetDocuments()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DOCUMENTS$0, 0);
        }
    }
}
