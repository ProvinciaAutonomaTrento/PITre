/*
 * An XML document type.
 * Localname: ArrayOfTemplate
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfTemplateDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one ArrayOfTemplate(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class ArrayOfTemplateDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfTemplateDocument
{
    
    public ArrayOfTemplateDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ARRAYOFTEMPLATE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "ArrayOfTemplate");
    
    
    /**
     * Gets the "ArrayOfTemplate" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfTemplate getArrayOfTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfTemplate target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfTemplate)get_store().find_element_user(ARRAYOFTEMPLATE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ArrayOfTemplate" element
     */
    public boolean isNilArrayOfTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfTemplate target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfTemplate)get_store().find_element_user(ARRAYOFTEMPLATE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ArrayOfTemplate" element
     */
    public void setArrayOfTemplate(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfTemplate arrayOfTemplate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfTemplate target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfTemplate)get_store().find_element_user(ARRAYOFTEMPLATE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfTemplate)get_store().add_element_user(ARRAYOFTEMPLATE$0);
            }
            target.set(arrayOfTemplate);
        }
    }
    
    /**
     * Appends and returns a new empty "ArrayOfTemplate" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfTemplate addNewArrayOfTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfTemplate target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfTemplate)get_store().add_element_user(ARRAYOFTEMPLATE$0);
            return target;
        }
    }
    
    /**
     * Nils the "ArrayOfTemplate" element
     */
    public void setNilArrayOfTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfTemplate target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfTemplate)get_store().find_element_user(ARRAYOFTEMPLATE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfTemplate)get_store().add_element_user(ARRAYOFTEMPLATE$0);
            }
            target.setNil();
        }
    }
}
