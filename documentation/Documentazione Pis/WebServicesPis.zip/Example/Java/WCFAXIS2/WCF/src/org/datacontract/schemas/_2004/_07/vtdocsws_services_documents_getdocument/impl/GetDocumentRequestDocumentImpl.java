/*
 * An XML document type.
 * Localname: GetDocumentRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetDocument
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.impl;
/**
 * A document containing one GetDocumentRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetDocument) element.
 *
 * This is a complex type.
 */
public class GetDocumentRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentRequestDocument
{
    
    public GetDocumentRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETDOCUMENTREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetDocument", "GetDocumentRequest");
    
    
    /**
     * Gets the "GetDocumentRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentRequest getGetDocumentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentRequest)get_store().find_element_user(GETDOCUMENTREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetDocumentRequest" element
     */
    public boolean isNilGetDocumentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentRequest)get_store().find_element_user(GETDOCUMENTREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetDocumentRequest" element
     */
    public void setGetDocumentRequest(org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentRequest getDocumentRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentRequest)get_store().find_element_user(GETDOCUMENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentRequest)get_store().add_element_user(GETDOCUMENTREQUEST$0);
            }
            target.set(getDocumentRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "GetDocumentRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentRequest addNewGetDocumentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentRequest)get_store().add_element_user(GETDOCUMENTREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetDocumentRequest" element
     */
    public void setNilGetDocumentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentRequest)get_store().find_element_user(GETDOCUMENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getdocument.GetDocumentRequest)get_store().add_element_user(GETDOCUMENTREQUEST$0);
            }
            target.setNil();
        }
    }
}
