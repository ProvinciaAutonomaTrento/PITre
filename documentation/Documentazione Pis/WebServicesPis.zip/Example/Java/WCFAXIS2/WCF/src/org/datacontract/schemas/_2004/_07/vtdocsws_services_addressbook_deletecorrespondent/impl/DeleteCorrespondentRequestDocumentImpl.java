/*
 * An XML document type.
 * Localname: DeleteCorrespondentRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.DeleteCorrespondent
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.impl;
/**
 * A document containing one DeleteCorrespondentRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.DeleteCorrespondent) element.
 *
 * This is a complex type.
 */
public class DeleteCorrespondentRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentRequestDocument
{
    
    public DeleteCorrespondentRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DELETECORRESPONDENTREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.DeleteCorrespondent", "DeleteCorrespondentRequest");
    
    
    /**
     * Gets the "DeleteCorrespondentRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentRequest getDeleteCorrespondentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentRequest)get_store().find_element_user(DELETECORRESPONDENTREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "DeleteCorrespondentRequest" element
     */
    public boolean isNilDeleteCorrespondentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentRequest)get_store().find_element_user(DELETECORRESPONDENTREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "DeleteCorrespondentRequest" element
     */
    public void setDeleteCorrespondentRequest(org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentRequest deleteCorrespondentRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentRequest)get_store().find_element_user(DELETECORRESPONDENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentRequest)get_store().add_element_user(DELETECORRESPONDENTREQUEST$0);
            }
            target.set(deleteCorrespondentRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "DeleteCorrespondentRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentRequest addNewDeleteCorrespondentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentRequest)get_store().add_element_user(DELETECORRESPONDENTREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "DeleteCorrespondentRequest" element
     */
    public void setNilDeleteCorrespondentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentRequest)get_store().find_element_user(DELETECORRESPONDENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentRequest)get_store().add_element_user(DELETECORRESPONDENTREQUEST$0);
            }
            target.setNil();
        }
    }
}
