/*
 * An XML document type.
 * Localname: GetStampAndSignatureRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetStampAndSignature
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.impl;
/**
 * A document containing one GetStampAndSignatureRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetStampAndSignature) element.
 *
 * This is a complex type.
 */
public class GetStampAndSignatureRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureRequestDocument
{
    
    public GetStampAndSignatureRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSTAMPANDSIGNATUREREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.GetStampAndSignature", "GetStampAndSignatureRequest");
    
    
    /**
     * Gets the "GetStampAndSignatureRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureRequest getGetStampAndSignatureRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureRequest)get_store().find_element_user(GETSTAMPANDSIGNATUREREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "GetStampAndSignatureRequest" element
     */
    public boolean isNilGetStampAndSignatureRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureRequest)get_store().find_element_user(GETSTAMPANDSIGNATUREREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "GetStampAndSignatureRequest" element
     */
    public void setGetStampAndSignatureRequest(org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureRequest getStampAndSignatureRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureRequest)get_store().find_element_user(GETSTAMPANDSIGNATUREREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureRequest)get_store().add_element_user(GETSTAMPANDSIGNATUREREQUEST$0);
            }
            target.set(getStampAndSignatureRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "GetStampAndSignatureRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureRequest addNewGetStampAndSignatureRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureRequest)get_store().add_element_user(GETSTAMPANDSIGNATUREREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "GetStampAndSignatureRequest" element
     */
    public void setNilGetStampAndSignatureRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureRequest)get_store().find_element_user(GETSTAMPANDSIGNATUREREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_getstampandsignature.GetStampAndSignatureRequest)get_store().add_element_user(GETSTAMPANDSIGNATUREREQUEST$0);
            }
            target.setNil();
        }
    }
}
