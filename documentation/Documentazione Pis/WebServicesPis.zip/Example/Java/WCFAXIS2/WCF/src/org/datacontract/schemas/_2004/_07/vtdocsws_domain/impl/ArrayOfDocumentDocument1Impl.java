/*
 * An XML document type.
 * Localname: ArrayOfDocument
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocumentDocument1
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one ArrayOfDocument(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class ArrayOfDocumentDocument1Impl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocumentDocument1
{
    
    public ArrayOfDocumentDocument1Impl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ARRAYOFDOCUMENT$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "ArrayOfDocument");
    
    
    /**
     * Gets the "ArrayOfDocument" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1 getArrayOfDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1 target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1)get_store().find_element_user(ARRAYOFDOCUMENT$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ArrayOfDocument" element
     */
    public boolean isNilArrayOfDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1 target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1)get_store().find_element_user(ARRAYOFDOCUMENT$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ArrayOfDocument" element
     */
    public void setArrayOfDocument(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1 arrayOfDocument)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1 target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1)get_store().find_element_user(ARRAYOFDOCUMENT$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1)get_store().add_element_user(ARRAYOFDOCUMENT$0);
            }
            target.set(arrayOfDocument);
        }
    }
    
    /**
     * Appends and returns a new empty "ArrayOfDocument" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1 addNewArrayOfDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1 target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1)get_store().add_element_user(ARRAYOFDOCUMENT$0);
            return target;
        }
    }
    
    /**
     * Nils the "ArrayOfDocument" element
     */
    public void setNilArrayOfDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1 target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1)get_store().find_element_user(ARRAYOFDOCUMENT$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfDocument1)get_store().add_element_user(ARRAYOFDOCUMENT$0);
            }
            target.setNil();
        }
    }
}
