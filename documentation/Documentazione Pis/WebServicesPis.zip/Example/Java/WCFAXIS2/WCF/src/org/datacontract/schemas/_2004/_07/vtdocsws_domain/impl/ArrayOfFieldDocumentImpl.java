/*
 * An XML document type.
 * Localname: ArrayOfField
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFieldDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one ArrayOfField(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class ArrayOfFieldDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfFieldDocument
{
    
    public ArrayOfFieldDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ARRAYOFFIELD$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "ArrayOfField");
    
    
    /**
     * Gets the "ArrayOfField" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfField getArrayOfField()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfField target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfField)get_store().find_element_user(ARRAYOFFIELD$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ArrayOfField" element
     */
    public boolean isNilArrayOfField()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfField target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfField)get_store().find_element_user(ARRAYOFFIELD$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ArrayOfField" element
     */
    public void setArrayOfField(org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfField arrayOfField)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfField target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfField)get_store().find_element_user(ARRAYOFFIELD$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfField)get_store().add_element_user(ARRAYOFFIELD$0);
            }
            target.set(arrayOfField);
        }
    }
    
    /**
     * Appends and returns a new empty "ArrayOfField" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfField addNewArrayOfField()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfField target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfField)get_store().add_element_user(ARRAYOFFIELD$0);
            return target;
        }
    }
    
    /**
     * Nils the "ArrayOfField" element
     */
    public void setNilArrayOfField()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfField target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfField)get_store().find_element_user(ARRAYOFFIELD$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.ArrayOfField)get_store().add_element_user(ARRAYOFFIELD$0);
            }
            target.setNil();
        }
    }
}
