/*
 * XML Type:  SendDocumentResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.SendDocument
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentResponse
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.impl;
/**
 * An XML SendDocumentResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.SendDocument).
 *
 * This is a complex type.
 */
public class SendDocumentResponseImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.ResponseImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_senddocument.SendDocumentResponse
{
    
    public SendDocumentResponseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
