/*
 * XML Type:  GetTemplatePrjResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetTemplatePrj
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_projects_gettemplateprj.GetTemplatePrjResponse
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_projects_gettemplateprj.impl;
/**
 * An XML GetTemplatePrjResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetTemplatePrj).
 *
 * This is a complex type.
 */
public class GetTemplatePrjResponseImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.ResponseImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_projects_gettemplateprj.GetTemplatePrjResponse
{
    
    public GetTemplatePrjResponseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TEMPLATE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Projects.GetTemplatePrj", "Template");
    
    
    /**
     * Gets the "Template" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Template getTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Template target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().find_element_user(TEMPLATE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "Template" element
     */
    public boolean isNilTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Template target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().find_element_user(TEMPLATE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "Template" element
     */
    public boolean isSetTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TEMPLATE$0) != 0;
        }
    }
    
    /**
     * Sets the "Template" element
     */
    public void setTemplate(org.datacontract.schemas._2004._07.vtdocsws_domain.Template template)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Template target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().find_element_user(TEMPLATE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().add_element_user(TEMPLATE$0);
            }
            target.set(template);
        }
    }
    
    /**
     * Appends and returns a new empty "Template" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.Template addNewTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Template target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().add_element_user(TEMPLATE$0);
            return target;
        }
    }
    
    /**
     * Nils the "Template" element
     */
    public void setNilTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.Template target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().find_element_user(TEMPLATE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.Template)get_store().add_element_user(TEMPLATE$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "Template" element
     */
    public void unsetTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TEMPLATE$0, 0);
        }
    }
}
