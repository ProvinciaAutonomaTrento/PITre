/*
 * An XML document type.
 * Localname: SearchUsersRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.SearchUsers
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.impl;
/**
 * A document containing one SearchUsersRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.SearchUsers) element.
 *
 * This is a complex type.
 */
public class SearchUsersRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersRequestDocument
{
    
    public SearchUsersRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SEARCHUSERSREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.SearchUsers", "SearchUsersRequest");
    
    
    /**
     * Gets the "SearchUsersRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersRequest getSearchUsersRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersRequest)get_store().find_element_user(SEARCHUSERSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "SearchUsersRequest" element
     */
    public boolean isNilSearchUsersRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersRequest)get_store().find_element_user(SEARCHUSERSREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "SearchUsersRequest" element
     */
    public void setSearchUsersRequest(org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersRequest searchUsersRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersRequest)get_store().find_element_user(SEARCHUSERSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersRequest)get_store().add_element_user(SEARCHUSERSREQUEST$0);
            }
            target.set(searchUsersRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "SearchUsersRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersRequest addNewSearchUsersRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersRequest)get_store().add_element_user(SEARCHUSERSREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "SearchUsersRequest" element
     */
    public void setNilSearchUsersRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersRequest)get_store().find_element_user(SEARCHUSERSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_searchusers.SearchUsersRequest)get_store().add_element_user(SEARCHUSERSREQUEST$0);
            }
            target.setNil();
        }
    }
}
