/*
 * An XML document type.
 * Localname: StateDiagram
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Domain
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_domain.StateDiagramDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_domain.impl;
/**
 * A document containing one StateDiagram(@http://schemas.datacontract.org/2004/07/VtDocsWS.Domain) element.
 *
 * This is a complex type.
 */
public class StateDiagramDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_domain.StateDiagramDocument
{
    
    public StateDiagramDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName STATEDIAGRAM$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Domain", "StateDiagram");
    
    
    /**
     * Gets the "StateDiagram" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.StateDiagram getStateDiagram()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.StateDiagram target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.StateDiagram)get_store().find_element_user(STATEDIAGRAM$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "StateDiagram" element
     */
    public boolean isNilStateDiagram()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.StateDiagram target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.StateDiagram)get_store().find_element_user(STATEDIAGRAM$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "StateDiagram" element
     */
    public void setStateDiagram(org.datacontract.schemas._2004._07.vtdocsws_domain.StateDiagram stateDiagram)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.StateDiagram target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.StateDiagram)get_store().find_element_user(STATEDIAGRAM$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.StateDiagram)get_store().add_element_user(STATEDIAGRAM$0);
            }
            target.set(stateDiagram);
        }
    }
    
    /**
     * Appends and returns a new empty "StateDiagram" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_domain.StateDiagram addNewStateDiagram()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.StateDiagram target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.StateDiagram)get_store().add_element_user(STATEDIAGRAM$0);
            return target;
        }
    }
    
    /**
     * Nils the "StateDiagram" element
     */
    public void setNilStateDiagram()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_domain.StateDiagram target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_domain.StateDiagram)get_store().find_element_user(STATEDIAGRAM$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_domain.StateDiagram)get_store().add_element_user(STATEDIAGRAM$0);
            }
            target.setNil();
        }
    }
}
