/*
 * An XML document type.
 * Localname: ResponseError
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services.ResponseErrorDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services.impl;
/**
 * A document containing one ResponseError(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services) element.
 *
 * This is a complex type.
 */
public class ResponseErrorDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services.ResponseErrorDocument
{
    
    public ResponseErrorDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName RESPONSEERROR$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services", "ResponseError");
    
    
    /**
     * Gets the "ResponseError" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError getResponseError()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError)get_store().find_element_user(RESPONSEERROR$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ResponseError" element
     */
    public boolean isNilResponseError()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError)get_store().find_element_user(RESPONSEERROR$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "ResponseError" element
     */
    public void setResponseError(org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError responseError)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError)get_store().find_element_user(RESPONSEERROR$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError)get_store().add_element_user(RESPONSEERROR$0);
            }
            target.set(responseError);
        }
    }
    
    /**
     * Appends and returns a new empty "ResponseError" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError addNewResponseError()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError)get_store().add_element_user(RESPONSEERROR$0);
            return target;
        }
    }
    
    /**
     * Nils the "ResponseError" element
     */
    public void setNilResponseError()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError)get_store().find_element_user(RESPONSEERROR$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services.ResponseError)get_store().add_element_user(RESPONSEERROR$0);
            }
            target.setNil();
        }
    }
}
