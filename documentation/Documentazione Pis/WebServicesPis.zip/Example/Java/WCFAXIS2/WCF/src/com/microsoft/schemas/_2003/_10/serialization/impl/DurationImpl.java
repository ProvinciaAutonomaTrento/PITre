/*
 * XML Type:  duration
 * Namespace: http://schemas.microsoft.com/2003/10/Serialization/
 * Java type: com.microsoft.schemas._2003._10.serialization.Duration
 *
 * Automatically generated - do not modify.
 */
package com.microsoft.schemas._2003._10.serialization.impl;
/**
 * An XML duration(@http://schemas.microsoft.com/2003/10/Serialization/).
 *
 * This is an atomic type that is a restriction of com.microsoft.schemas._2003._10.serialization.Duration.
 */
public class DurationImpl extends org.apache.xmlbeans.impl.values.JavaGDurationHolderEx implements com.microsoft.schemas._2003._10.serialization.Duration
{
    
    public DurationImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected DurationImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
