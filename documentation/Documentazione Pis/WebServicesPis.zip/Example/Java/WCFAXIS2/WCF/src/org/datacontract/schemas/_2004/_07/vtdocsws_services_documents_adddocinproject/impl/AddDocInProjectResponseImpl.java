/*
 * XML Type:  AddDocInProjectResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.AddDocInProject
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectResponse
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.impl;
/**
 * An XML AddDocInProjectResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.AddDocInProject).
 *
 * This is a complex type.
 */
public class AddDocInProjectResponseImpl extends org.datacontract.schemas._2004._07.vtdocsws_services.impl.ResponseImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_adddocinproject.AddDocInProjectResponse
{
    
    public AddDocInProjectResponseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
