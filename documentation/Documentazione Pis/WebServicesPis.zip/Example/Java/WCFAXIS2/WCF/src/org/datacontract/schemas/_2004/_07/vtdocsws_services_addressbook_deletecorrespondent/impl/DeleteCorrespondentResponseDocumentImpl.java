/*
 * An XML document type.
 * Localname: DeleteCorrespondentResponse
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.DeleteCorrespondent
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.impl;
/**
 * A document containing one DeleteCorrespondentResponse(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.DeleteCorrespondent) element.
 *
 * This is a complex type.
 */
public class DeleteCorrespondentResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentResponseDocument
{
    
    public DeleteCorrespondentResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DELETECORRESPONDENTRESPONSE$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.AddressBook.DeleteCorrespondent", "DeleteCorrespondentResponse");
    
    
    /**
     * Gets the "DeleteCorrespondentResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentResponse getDeleteCorrespondentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentResponse)get_store().find_element_user(DELETECORRESPONDENTRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "DeleteCorrespondentResponse" element
     */
    public boolean isNilDeleteCorrespondentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentResponse)get_store().find_element_user(DELETECORRESPONDENTRESPONSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "DeleteCorrespondentResponse" element
     */
    public void setDeleteCorrespondentResponse(org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentResponse deleteCorrespondentResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentResponse)get_store().find_element_user(DELETECORRESPONDENTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentResponse)get_store().add_element_user(DELETECORRESPONDENTRESPONSE$0);
            }
            target.set(deleteCorrespondentResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "DeleteCorrespondentResponse" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentResponse addNewDeleteCorrespondentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentResponse)get_store().add_element_user(DELETECORRESPONDENTRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "DeleteCorrespondentResponse" element
     */
    public void setNilDeleteCorrespondentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentResponse target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentResponse)get_store().find_element_user(DELETECORRESPONDENTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_addressbook_deletecorrespondent.DeleteCorrespondentResponse)get_store().add_element_user(DELETECORRESPONDENTRESPONSE$0);
            }
            target.setNil();
        }
    }
}
