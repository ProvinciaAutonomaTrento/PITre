/*
 * An XML document type.
 * Localname: EditDocStateDiagramRequest
 * Namespace: http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.EditDocStateDiagram
 * Java type: org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.impl;
/**
 * A document containing one EditDocStateDiagramRequest(@http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.EditDocStateDiagram) element.
 *
 * This is a complex type.
 */
public class EditDocStateDiagramRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramRequestDocument
{
    
    public EditDocStateDiagramRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EDITDOCSTATEDIAGRAMREQUEST$0 = 
        new javax.xml.namespace.QName("http://schemas.datacontract.org/2004/07/VtDocsWS.Services.Documents.EditDocStateDiagram", "EditDocStateDiagramRequest");
    
    
    /**
     * Gets the "EditDocStateDiagramRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramRequest getEditDocStateDiagramRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramRequest)get_store().find_element_user(EDITDOCSTATEDIAGRAMREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "EditDocStateDiagramRequest" element
     */
    public boolean isNilEditDocStateDiagramRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramRequest)get_store().find_element_user(EDITDOCSTATEDIAGRAMREQUEST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "EditDocStateDiagramRequest" element
     */
    public void setEditDocStateDiagramRequest(org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramRequest editDocStateDiagramRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramRequest)get_store().find_element_user(EDITDOCSTATEDIAGRAMREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramRequest)get_store().add_element_user(EDITDOCSTATEDIAGRAMREQUEST$0);
            }
            target.set(editDocStateDiagramRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "EditDocStateDiagramRequest" element
     */
    public org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramRequest addNewEditDocStateDiagramRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramRequest)get_store().add_element_user(EDITDOCSTATEDIAGRAMREQUEST$0);
            return target;
        }
    }
    
    /**
     * Nils the "EditDocStateDiagramRequest" element
     */
    public void setNilEditDocStateDiagramRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramRequest target = null;
            target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramRequest)get_store().find_element_user(EDITDOCSTATEDIAGRAMREQUEST$0, 0);
            if (target == null)
            {
                target = (org.datacontract.schemas._2004._07.vtdocsws_services_documents_editdocstatediagram.EditDocStateDiagramRequest)get_store().add_element_user(EDITDOCSTATEDIAGRAMREQUEST$0);
            }
            target.setNil();
        }
    }
}
