﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class EditCorrespondent : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }

    protected void btnEditDocument_Click(object sender, EventArgs e)
    {

        AddressBook.AddressBookClient services = new AddressBook.AddressBookClient();
        AddressBook.EditCorrespondentRequest request = new AddressBook.EditCorrespondentRequest();

        //if (this.Session["UserName"] != null && this.Session["AuthenticationToken"] != null)
        //{
        //    request.UserName = this.Session["UserName"].ToString();
        //    request.AuthenticationToken = this.Session["AuthenticationToken"].ToString();
        //}
        request.UserName = this.txt_username.Text;
        request.CodeAdm = this.txt_codAmm.Text;
        request.CodeRoleLogin = this.txt_codice_ruolo.Text;

        AddressBook.Correspondent docRequest = new AddressBook.Correspondent();

        docRequest.Id = this.txtDoc.Text;
        docRequest.Code=this.txt_codice.Text;
        docRequest.AdmCode=this.text_cod_amm.Text;
        docRequest.AOOCode=this.text_cod_aoo.Text;
        docRequest.Email=this.txt_mail.Text;
        docRequest.Description=this.txt_descrizione.Text;
        docRequest.Address=this.txt_indirizzo.Text ;
        docRequest.Cap= this.txt_cap.Text;
        docRequest.City= this.txt_citta.Text;
        docRequest.Province=this.txt_provincia.Text;
        docRequest.Location=this.txt_localita.Text;
        docRequest.Nation= this.txt_nazione.Text ;
        docRequest.PhoneNumber=this.txt_telefono.Text;
        docRequest.Fax= this.txt_fax.Text ;
        docRequest.NationalIdentificationNumber=this.text_codice_fiscale.Text;
        docRequest.Note = this.txt_note.Text;

        request.Correspondent = docRequest;

        this.txtRequest.Text = this.SerializeAsXml(request);

        AddressBook.EditCorrespondentResponse response = services.EditCorrespondent(request);

        this.txtResponse.Text = this.SerializeAsXml(response);

        if (response.Success)
        {
            this.txtCodiceErrore.Text = string.Empty;
            this.txtDescrizioneErrore.Text = string.Empty;
        }
        else
        {
            this.txtCodiceErrore.Text = response.Error.Code;
            this.txtDescrizioneErrore.Text = response.Error.Description;
        }
    }


    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
    private string SerializeAsXml(object data)
    {
        System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(data.GetType());

        using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
        {
            serializer.Serialize(ms, data);
            ms.Position = 0;

            byte[] buffer = new byte[ms.Length];
            ms.Read(buffer, 0, buffer.Length);

            return System.Text.UnicodeEncoding.Default.GetString(buffer);
        }

    }

    protected void btnGetDocument_Click(object sender, EventArgs e)
    {

        AddressBook.AddressBookClient services = new AddressBook.AddressBookClient();
        AddressBook.GetCorrespondentRequest request = new AddressBook.GetCorrespondentRequest();

        //if (this.Session["UserName"] != null && this.Session["AuthenticationToken"] != null)
        //{
        //    request.UserName = this.Session["UserName"].ToString();
        //    request.AuthenticationToken = this.Session["AuthenticationToken"].ToString();
        //}

        request.UserName = this.txt_username.Text;
        request.CodeAdm = this.txt_codAmm.Text;
        request.CodeRoleLogin = this.txt_codice_ruolo.Text;

        request.IdCorrespondent = txtIdDocument.Text;

        this.txtRequest.Text = this.SerializeAsXml(request);

        using (AddressBook.AddressBookClient client = new AddressBook.AddressBookClient())
        {
            client.AddCorrespondent(new AddressBook.AddCorrespondentRequest() { Correspondent = null });
        }

        AddressBook.GetCorrespondentResponse response = services.GetCorrespondent(request);

        this.txtResponse.Text = this.SerializeAsXml(response);

        if (response.Success)
        {
            AddressBook.Correspondent result = response.Correspondent;
            this.txtCodiceErrore.Text = string.Empty;
            this.txtDescrizioneErrore.Text = string.Empty;
            this.pnl_getDocument.Visible = false;
            this.pnl_dettaglio.Visible = true;
         
            this.txtDoc.Text = result.Id;
            this.txt_codice.Text = result.Code;
            this.text_cod_amm.Text = result.AdmCode;
            this.text_cod_aoo.Text = result.AOOCode;
            this.txt_mail.Text = result.Email;
            this.txt_descrizione.Text = result.Description;
            this.txt_indirizzo.Text = result.Address;
            this.txt_cap.Text = result.Cap;
            this.txt_citta.Text = result.City;
            this.txt_provincia.Text = result.Province;
            this.txt_localita.Text = result.Location;
            this.txt_nazione.Text = result.Nation;
            this.txt_telefono.Text = result.PhoneNumber;
            this.txt_fax.Text = result.Fax;
            this.text_codice_fiscale.Text = result.NationalIdentificationNumber;
            this.txt_note.Text = result.Note;

        }
        else
        {
            this.txtCodiceErrore.Text = response.Error.Code;
            this.txtDescrizioneErrore.Text = response.Error.Description;
        }
    }
}