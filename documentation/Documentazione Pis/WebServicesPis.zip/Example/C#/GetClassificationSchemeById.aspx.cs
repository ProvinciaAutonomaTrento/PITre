﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class GetClassificationSchemeById : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }

    protected void btnGetClassificationSchemeById_Click(object sender, EventArgs e)
    {

        ClassificationSchemes.ClassificationSchemesClient services = new ClassificationSchemes.ClassificationSchemesClient();
        ClassificationSchemes.GetClassificationSchemeByIdRequest request = new ClassificationSchemes.GetClassificationSchemeByIdRequest();

        //if (this.Session["UserName"] != null && this.Session["AuthenticationToken"] != null)
        //{
        //    request.UserName = this.Session["UserName"].ToString();
        //    request.AuthenticationToken = this.Session["AuthenticationToken"].ToString();
        //}

        request.UserName = this.txt_username.Text;
        request.CodeAdm = this.txt_codAmm.Text;
        request.CodeRoleLogin = this.txt_codice_ruolo.Text;

        request.IdClassificationScheme = this.txtIdClassification.Text;


        this.txtRequest.Text = this.SerializeAsXml(request);
        ClassificationSchemes.GetClassificationSchemeByIdResponse response = services.GetClassificationSchemeById(request);

        this.txtResponse.Text = this.SerializeAsXml(response);

        if (response.Success)
        {
            ClassificationSchemes.ClassificationScheme result = response.ClassificationScheme;
            this.txtCodiceErrore.Text = string.Empty;
            this.txtDescrizioneErrore.Text = string.Empty;
        }
        else
        {
            this.txtCodiceErrore.Text = response.Error.Code;
            this.txtDescrizioneErrore.Text = response.Error.Description;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
    private string SerializeAsXml(object data)
    {
        System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(data.GetType());

        using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
        {
            serializer.Serialize(ms, data);
            ms.Position = 0;

            byte[] buffer = new byte[ms.Length];
            ms.Read(buffer, 0, buffer.Length);

            return System.Text.UnicodeEncoding.Default.GetString(buffer);
        }

    }
}