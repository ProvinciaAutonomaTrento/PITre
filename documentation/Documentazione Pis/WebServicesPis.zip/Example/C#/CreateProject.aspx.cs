﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;

public partial class CreateProject : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            Projects.ProjectsClient services = new Projects.ProjectsClient();
            Projects.GetTemplatesProjectsRequest request = new Projects.GetTemplatesProjectsRequest();

            //if (this.Session["UserName"] != null && this.Session["AuthenticationToken"] != null)
            //{
            //    request.UserName = this.Session["UserName"].ToString();
            //    request.AuthenticationToken = this.Session["AuthenticationToken"].ToString();
            //}

            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["username"]) && !string.IsNullOrEmpty(ConfigurationManager.AppSettings["amministrazione"]))
            {
                request.UserName = ConfigurationManager.AppSettings["username"].ToString();
                request.CodeAdm = ConfigurationManager.AppSettings["amministrazione"].ToString();
            }

            Projects.GetTemplatesProjectsResponse response = services.GetTemplatesProjects(request);

            if (response.Success)
            {
                this.cboProfili.DataSource = response.Templates;
                this.cboProfili.DataBind();
                this.cboProfili.Items.Insert(0, "");
            }
        }

    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }

    protected void btnCreateDocument_Click(object sender, EventArgs e)
    {
        Projects.ProjectsClient services = new Projects.ProjectsClient();
        Projects.CreateProjectRequest request = new Projects.CreateProjectRequest();

        //if (this.Session["UserName"] != null && this.Session["AuthenticationToken"] != null)
        //{
        //    request.UserName = this.Session["UserName"].ToString();
        //    request.AuthenticationToken = this.Session["AuthenticationToken"].ToString();
        //}

        request.UserName = this.txt_username.Text;
        request.CodeAdm = this.txt_codAmm.Text;
        request.CodeRoleLogin = this.txt_codice_ruolo.Text;

        Projects.Project fascRequest = new Projects.Project();

        //Creazione fascicolo

        fascRequest.ClassificationScheme = new Projects.ClassificationScheme();
        fascRequest.ClassificationScheme.Id = this.txt_titolario.Text;
        fascRequest.Description = this.txt_descrizione.Text;
        if (!string.IsNullOrEmpty(this.txt_nota.Text))
        {
            fascRequest.Note = new Projects.Note[1];
            fascRequest.Note[0] = new Projects.Note();
            fascRequest.Note[0].Description = this.txt_nota.Text;
        }
        fascRequest.Paper = this.chkCartaceo.Checked;
        fascRequest.Private = this.chkPrivato.Checked;
        fascRequest.CodeNodeClassification = this.txt_codice_nodo.Text;


        request.Project = fascRequest;



        if (!string.IsNullOrEmpty(cboProfili.SelectedValue))
        {
            Projects.Template template = new Projects.Template();
            template.Id = cboProfili.SelectedValue;
            template.Name = cboProfili.SelectedItem.Text;

            List<Projects.Field> campiProfilo = new List<Projects.Field>();

            foreach (DataGridItem itm in this.grdDatiProfilati.Items)
            {
                if (itm.ItemType != ListItemType.Header)
                {
                    campiProfilo.Add(new Projects.Field
                    {
                        Name = ((Label)itm.FindControl("lblNomeCampo")).Text,
                        Required = ((CheckBox)itm.FindControl("chkObbligatorio")).Checked,
                        Value = ((TextBox)itm.FindControl("txtValoreCampo")).Text,
                        CodeRegisterOrRF = ((TextBox)itm.FindControl("txtValoreCampo")).Text
                    });
                }
            }
            request.Project.Template = template;
            request.Project.Template.Fields = campiProfilo.ToArray();
        }

        this.txtRequest.Text = this.SerializeAsXml(request);

        Projects.CreateProjectResponse response = services.CreateProject(request);

        this.txtResponse.Text = this.SerializeAsXml(response);

        if (response.Success)
        {
            Projects.Project result = response.Project;
            this.txtCodiceErrore.Text = string.Empty;
            this.txtDescrizioneErrore.Text = string.Empty;
        }
        else
        {
            this.txtCodiceErrore.Text = response.Error.Code;
            this.txtDescrizioneErrore.Text = response.Error.Description;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void cboProfili_OnSelectedIndexChanged(object sender, EventArgs e)
    {
        Projects.ProjectsClient services = new Projects.ProjectsClient();
        Projects.GetTemplatePrjRequest request = new Projects.GetTemplatePrjRequest();

        //if (this.Session["UserName"] != null && this.Session["AuthenticationToken"] != null)
        //{
        //    request.UserName = this.Session["UserName"].ToString();
        //    request.AuthenticationToken = this.Session["AuthenticationToken"].ToString();
        //}

        if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["username"]) && !string.IsNullOrEmpty(ConfigurationManager.AppSettings["amministrazione"]))
        {
            request.UserName = ConfigurationManager.AppSettings["username"].ToString();
            request.CodeAdm = ConfigurationManager.AppSettings["amministrazione"].ToString();
        }

        request.IdTemplate = this.cboProfili.SelectedValue;
        Projects.Project docRequest = new Projects.Project();

        Projects.GetTemplatePrjResponse response = services.GetTemplatePrj(request);

        if (response.Success)
        {
            this.grdDatiProfilati.DataSource = response.Template.Fields;
            this.grdDatiProfilati.DataBind();
        }

    }

  

    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
    private string SerializeAsXml(object data)
    {
        System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(data.GetType());

        using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
        {
            serializer.Serialize(ms, data);
            ms.Position = 0;

            byte[] buffer = new byte[ms.Length];
            ms.Read(buffer, 0, buffer.Length);

            return System.Text.UnicodeEncoding.Default.GetString(buffer);
        }

    }
}