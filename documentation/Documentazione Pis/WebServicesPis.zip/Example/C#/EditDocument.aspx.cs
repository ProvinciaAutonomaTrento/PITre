﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class EditDocument : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }

    protected void btnEditDocument_Click(object sender, EventArgs e)
    {
        Documents.DocumentsClient services = new Documents.DocumentsClient();
        Documents.EditDocumentRequest request = new Documents.EditDocumentRequest();

        //if (this.Session["UserName"] != null && this.Session["AuthenticationToken"] != null)
        //{
        //    request.UserName = this.Session["UserName"].ToString();
        //    request.AuthenticationToken = this.Session["AuthenticationToken"].ToString();
        //}
        request.UserName = this.txt_username.Text;
        request.CodeAdm = this.txt_codAmm.Text;
        request.CodeRoleLogin = this.txt_codice_ruolo.Text;

        Documents.Document docRequest = new Documents.Document();
        docRequest.Id = this.txtDoc.Text;
        docRequest.Object = txtOggetto.Text;
        docRequest.PrivateDocument = chkPrivato.Checked;
        if (!string.IsNullOrEmpty(txtNota.Text))
        {
            docRequest.Note = new Documents.Note[1];
            docRequest.Note[0] = new Documents.Note();
            docRequest.Note[0].Description = this.txtNota.Text;
        }
        docRequest.DocumentType = rbl_radio.SelectedItem.Value;

        if (this.rbl_radio.SelectedValue.Equals("G"))
        {

        }
        else
        {
            if (!string.IsNullOrEmpty(this.txtDescrizioneMitt.Text))
            {
                docRequest.Predisposed = chkPre.Checked;
                docRequest.Sender = new Documents.Correspondent();
                docRequest.Sender.Description = this.txtDescrizioneMitt.Text;
                docRequest.Sender.CorrespondentType = "O";

                if (this.rbl_radio.SelectedValue.Equals("A"))
                {
                    if (!string.IsNullOrEmpty(this.txtDescrizioneMittMultiplo.Text))
                    {
                        docRequest.MultipleSenders = new Documents.Correspondent[1];
                        docRequest.MultipleSenders[0] = new Documents.Correspondent();
                        docRequest.MultipleSenders[0].Description = this.txtDescrizioneMittMultiplo.Text;
                        docRequest.MultipleSenders[0].CorrespondentType = "O";
                    }

                    if (!string.IsNullOrEmpty(this.txt_mezzo.Text))
                    {
                        docRequest.MeansOfSending = this.txt_mezzo.Text;
                    }

                    if (!string.IsNullOrEmpty(this.txtProtocolloMittente.Text))
                    {
                        docRequest.ProtocolSender = this.txtProtocolloMittente.Text;
                    }

                    if (!string.IsNullOrEmpty(this.txtDataProtMittente.Text))
                    {
                        docRequest.DataProtocolSender = this.txtDataProtMittente.Text;
                    }
                }
                if (this.rbl_radio.SelectedValue.Equals("P") || this.rbl_radio.SelectedValue.Equals("I"))
                {
                    if (!string.IsNullOrEmpty(this.txt_dest.Text))
                    {
                        docRequest.Recipients = new Documents.Correspondent[1];
                        docRequest.Recipients[0] = new Documents.Correspondent();
                        docRequest.Recipients[0].Description = this.txt_dest.Text;
                        docRequest.Recipients[0].Id = this.txt_dest.Text;
                    }

                    if (!string.IsNullOrEmpty(this.txt_dest_cc.Text))
                    {
                        docRequest.RecipientsCC = new Documents.Correspondent[1];
                        docRequest.RecipientsCC[0] = new Documents.Correspondent();
                        docRequest.RecipientsCC[0].Description = this.txt_dest_cc.Text;
                        docRequest.RecipientsCC[0].Id = this.txt_dest_cc.Text;
                    }
                }
            }
        }

        request.Document = docRequest;

        this.txtRequest.Text = this.SerializeAsXml(request);

        Documents.EditDocumentResponse response = services.EditDocument(request);

        this.txtResponse.Text = this.SerializeAsXml(response);

        if (response.Success)
        {
            Documents.Document result = response.Document;
            this.txtCodiceErrore.Text = string.Empty;
            this.txtDescrizioneErrore.Text = string.Empty;
        }
        else
        {
            this.txtCodiceErrore.Text = response.Error.Code;
            this.txtDescrizioneErrore.Text = response.Error.Description;
        }
    }


    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
    private string SerializeAsXml(object data)
    {
        System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(data.GetType());

        using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
        {
            serializer.Serialize(ms, data);
            ms.Position = 0;

            byte[] buffer = new byte[ms.Length];
            ms.Read(buffer, 0, buffer.Length);

            return System.Text.UnicodeEncoding.Default.GetString(buffer);
        }

    }

    protected void btnGetDocument_Click(object sender, EventArgs e)
    {
        Documents.DocumentsClient services = new Documents.DocumentsClient();
        Documents.GetDocumentRequest request = new Documents.GetDocumentRequest();

        //if (this.Session["UserName"] != null && this.Session["AuthenticationToken"] != null)
        //{
        //    request.UserName = this.Session["UserName"].ToString();
        //    request.AuthenticationToken = this.Session["AuthenticationToken"].ToString();
        //}

        request.UserName = this.txt_username.Text;
        request.CodeAdm = this.txt_codAmm.Text;

        request.IdDocument = txtIdDocument.Text;
        request.Signature = txtSignature.Text;

        this.txtRequest.Text = this.SerializeAsXml(request);

        Documents.GetDocumentResponse response = services.GetDocument(request);

        this.txtResponse.Text = this.SerializeAsXml(response);

        if (response.Success)
        {
            Documents.Document result = response.Document;
            this.txtCodiceErrore.Text = string.Empty;
            this.txtDescrizioneErrore.Text = string.Empty;
            this.pnl_getDocument.Visible = false;
            this.pnl_dettaglio.Visible = true;
            this.rbl_radio.SelectedValue = result.DocumentType;
            if (!this.rbl_radio.SelectedValue.Equals("G"))
            {
                this.pnl_predisposto.Visible = true;
                this.pnl_mittente.Visible = true;
                if (result.Predisposed)
                {
                    this.chkPre.Checked = true;
                }
                if (result.Sender != null)
                {
                    this.txtDescrizioneMitt.Text = result.Sender.Description;
                }
            }
            else
            {
                this.pnl_predisposto.Visible = false;
                this.pnl_mittente.Visible = false;              
            }
            if (this.rbl_radio.SelectedValue.Equals("A"))
            {
                this.pnl_multipli.Visible = true;
                this.pnl_protMitt.Visible = true;
                this.pnl_data_prot.Visible = true;
                if (result.MultipleSenders != null && result.MultipleSenders.Length > 0)
                {
                    this.txtDescrizioneMittMultiplo.Text = result.MultipleSenders[0].Description;
                }
                if (!string.IsNullOrEmpty(result.ProtocolSender))
                {
                    this.txtProtocolloMittente.Text = result.ProtocolSender;
                }
                if (!string.IsNullOrEmpty(result.DataProtocolSender))
                {
                    this.txtDataProtMittente.Text = result.DataProtocolSender;
                }
            }
            else
            {
                this.pnl_multipli.Visible = false;
                this.pnl_protMitt.Visible = false;
                this.pnl_data_prot.Visible = false;
            }
            this.txtOggetto.Text = result.Object;

            if (result.Note != null && result.Note.Length > 0)
            {
                this.txtNota.Text = result.Note[0].Description;
            }

            if (this.rbl_radio.SelectedValue.Equals("P") || this.rbl_radio.SelectedValue.Equals("I"))
            {
                this.pnl_destinatari.Visible = true;
                this.pnl_destinatari_cc.Visible = true;
                if (result.Recipients != null && result.Recipients.Length > 0)
                {
                    txt_dest.Text = result.Recipients[0].Description;
                }
                if (result.RecipientsCC != null && result.RecipientsCC.Length > 0)
                {
                    txt_dest_cc.Text = result.RecipientsCC[0].Description;
                }
            }
            else
            {
                this.pnl_destinatari.Visible = false;
                this.pnl_destinatari_cc.Visible = false;
            }

            if (result.PrivateDocument)
            {
                this.chkPrivato.Checked = true;
            }

            this.txtDoc.Text = result.Id;

           
        }
        else
        {
            this.txtCodiceErrore.Text = response.Error.Code;
            this.txtDescrizioneErrore.Text = response.Error.Description;
        }
    }
}