﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class EditProject : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }

    protected void btnEditDocument_Click(object sender, EventArgs e)
    {
        Projects.ProjectsClient services = new Projects.ProjectsClient();
        Projects.EditProjectRequest request = new Projects.EditProjectRequest();

        //if (this.Session["UserName"] != null && this.Session["AuthenticationToken"] != null)
        //{
        //    request.UserName = this.Session["UserName"].ToString();
        //    request.AuthenticationToken = this.Session["AuthenticationToken"].ToString();
        //}

        request.UserName = this.txt_username.Text;
        request.CodeAdm = this.txt_codAmm.Text;
        request.CodeRoleLogin = this.txt_codice_ruolo.Text;

        Projects.Project fascRequest = new Projects.Project();
     
        fascRequest.Description = this.txt_descrizione.Text;
        
        fascRequest.Paper = this.chkCartaceo.Checked;
        fascRequest.Private = this.chkPrivato.Checked;
        fascRequest.Id = this.txtFasc.Text;

        request.Project = fascRequest;

        this.txtRequest.Text = this.SerializeAsXml(request);

        Projects.EditProjectResponse response = services.EditProject(request);

        this.txtResponse.Text = this.SerializeAsXml(response);

        if (response.Success)
        {
            Projects.Project result = response.Project;
            this.txtCodiceErrore.Text = string.Empty;
            this.txtDescrizioneErrore.Text = string.Empty;
        }
        else
        {
            this.txtCodiceErrore.Text = response.Error.Code;
            this.txtDescrizioneErrore.Text = response.Error.Description;
        }
    }


    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
    private string SerializeAsXml(object data)
    {
        System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(data.GetType());

        using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
        {
            serializer.Serialize(ms, data);
            ms.Position = 0;

            byte[] buffer = new byte[ms.Length];
            ms.Read(buffer, 0, buffer.Length);

            return System.Text.UnicodeEncoding.Default.GetString(buffer);
        }

    }

    protected void btnGetDocument_Click(object sender, EventArgs e)
    {
        Projects.ProjectsClient services = new Projects.ProjectsClient();
        Projects.GetProjectRequest request = new Projects.GetProjectRequest();

        //if (this.Session["UserName"] != null && this.Session["AuthenticationToken"] != null)
        //{
        //    request.UserName = this.Session["UserName"].ToString();
        //    request.AuthenticationToken = this.Session["AuthenticationToken"].ToString();
        //}

        request.UserName = this.txt_username.Text;
        request.CodeAdm = this.txt_codAmm.Text;
        request.CodeRoleLogin = this.txt_codice_ruolo.Text;

        request.ClassificationSchemeId = txtIdTitolario.Text;
        request.CodeProject = txtCode.Text;
        request.IdProject = txtIdProject.Text;

        this.txtRequest.Text = this.SerializeAsXml(request);

        Projects.GetProjectResponse response = services.GetProject(request);

        this.txtResponse.Text = this.SerializeAsXml(response);

        if (response.Success)
        {
            Projects.Project result = response.Project;
            this.txtCodiceErrore.Text = string.Empty;
            this.txtDescrizioneErrore.Text = string.Empty;
            this.pnl_getDocument.Visible = false;
            this.pnl_dettaglio.Visible = true;
            this.txt_descrizione.Text = response.Project.Description;
            this.chkCartaceo.Checked = response.Project.Paper;
            this.chkPrivato.Checked = response.Project.Private;
            this.txtFasc.Text = response.Project.Id;
        }
        else
        {
            this.txtCodiceErrore.Text = response.Error.Code;
            this.txtDescrizioneErrore.Text = response.Error.Description;
        }
    }
}