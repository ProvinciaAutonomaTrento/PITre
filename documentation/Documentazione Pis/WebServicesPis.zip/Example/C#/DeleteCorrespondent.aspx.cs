﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DeleteCorrespondent : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }

    protected void btn_GetProject_Click(object sender, EventArgs e)
    {
        AddressBook.AddressBookClient services = new AddressBook.AddressBookClient();
        AddressBook.DeleteCorrespondentRequest request = new AddressBook.DeleteCorrespondentRequest();

        //if (this.Session["UserName"] != null && this.Session["AuthenticationToken"] != null)
        //{
        //    request.UserName = this.Session["UserName"].ToString();
        //    request.AuthenticationToken = this.Session["AuthenticationToken"].ToString();
        //}

        request.UserName = this.txt_username.Text;
        request.CodeAdm = this.txt_codAmm.Text;
        request.CodeRoleLogin = this.txt_codice_ruolo.Text;

        request.CorrespondentId = this.txtIdCorrispondente.Text;

        this.txtRequest.Text = this.SerializeAsXml(request);

        AddressBook.DeleteCorrespondentResponse response = services.DeleteCorrespondent(request);

        this.txtResponse.Text = this.SerializeAsXml(response);

        if (response.Success)
        {
            this.txtCodiceErrore.Text = string.Empty;
            this.txtDescrizioneErrore.Text = string.Empty;
        }
        else
        {
            this.txtCodiceErrore.Text = response.Error.Code;
            this.txtDescrizioneErrore.Text = response.Error.Description;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
    private string SerializeAsXml(object data)
    {
        System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(data.GetType());

        using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
        {
            serializer.Serialize(ms, data);
            ms.Position = 0;

            byte[] buffer = new byte[ms.Length];
            ms.Read(buffer, 0, buffer.Length);

            return System.Text.UnicodeEncoding.Default.GetString(buffer);
        }

    }
}