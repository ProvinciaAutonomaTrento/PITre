﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SearchCorrespondents : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {

        AddressBook.AddressBookClient services = new AddressBook.AddressBookClient();
        AddressBook.SearchCorrespondentsRequest request = new AddressBook.SearchCorrespondentsRequest();

        //if (this.Session["UserName"] != null && this.Session["AuthenticationToken"] != null)
        //{
        //    request.UserName = this.Session["UserName"].ToString();
        //    request.AuthenticationToken = this.Session["AuthenticationToken"].ToString();
        //}

        request.UserName = this.txt_username.Text;
        request.CodeAdm = this.txt_codAmm.Text;
        request.CodeRoleLogin = this.txt_codice_ruolo.Text;

        request.Filters = new AddressBook.Filter[11];
        AddressBook.Filter filter = new AddressBook.Filter();
        int indice = 0;

        filter = new AddressBook.Filter();
        filter.Name = "OFFICES";
        filter.Value = this.chk_uo.Checked.ToString();
        request.Filters.SetValue(filter, indice);
        indice++;

        filter = new AddressBook.Filter();
        filter.Name = "USERS";
        filter.Value = this.chk_utente.Checked.ToString();
        request.Filters.SetValue(filter, indice);
        indice++;

        filter = new AddressBook.Filter();
        filter.Name = "ROLES";
        filter.Value = this.chk_ruoli.Checked.ToString();
        request.Filters.SetValue(filter, indice);
        indice++;

        if (!string.IsNullOrEmpty(rbl_tipo_corr.SelectedValue))
        {
            filter = new AddressBook.Filter();
            filter.Name = "TYPE";
            filter.Value = rbl_tipo_corr.SelectedValue;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        filter = new AddressBook.Filter();
        filter.Name = "COMMON_ADDRESSBOOK";
        filter.Value = this.chk_rubrica_comune.Checked.ToString();
        request.Filters.SetValue(filter, indice);
        indice++;

        filter = new AddressBook.Filter();
        filter.Name = "RF";
        filter.Value = this.chk_rf.Checked.ToString();
        request.Filters.SetValue(filter, indice);
        indice++;

        if (!string.IsNullOrEmpty(txt_code.Text))
        {
            filter = new AddressBook.Filter();
            filter.Name = "CODE";
            filter.Value = txt_code.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(txt_descrione.Text))
        {
            filter = new AddressBook.Filter();
            filter.Name = "DESCRIPTION";
            filter.Value = txt_descrione.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(txt_citta.Text))
        {
            filter = new AddressBook.Filter();
            filter.Name = "CITY";
            filter.Value = txt_citta.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(txt_localita.Text))
        {
            filter = new AddressBook.Filter();
            filter.Name = "LOCALITY";
            filter.Value = txt_localita.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(txt_mail.Text))
        {
            filter = new AddressBook.Filter();
            filter.Name = "MAIL";
            filter.Value = txt_mail.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(txt_nat.Text))
        {
            filter = new AddressBook.Filter();
            filter.Name = "NAT";
            filter.Value = txt_nat.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(txt_cod_reg.Text))
        {
            filter = new AddressBook.Filter();
            filter.Name = "REGISTRY_OR_RF";
            filter.Value = txt_cod_reg.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        this.txtRequest.Text = this.SerializeAsXml(request);
        AddressBook.SearchCorrespondentsResponse response = services.SearchCorrespondents(request);

        this.txtResponse.Text = this.SerializeAsXml(response);

        if (response.Success)
        {
            AddressBook.Correspondent[] result = response.Correspondents;
            this.txtCodiceErrore.Text = string.Empty;
            this.txtDescrizioneErrore.Text = string.Empty;
        }
        else
        {
            this.txtCodiceErrore.Text = response.Error.Code;
            this.txtDescrizioneErrore.Text = response.Error.Description;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
    private string SerializeAsXml(object data)
    {
        System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(data.GetType());

        using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
        {
            serializer.Serialize(ms, data);
            ms.Position = 0;

            byte[] buffer = new byte[ms.Length];
            ms.Read(buffer, 0, buffer.Length);

            return System.Text.UnicodeEncoding.Default.GetString(buffer);
        }

    }
}