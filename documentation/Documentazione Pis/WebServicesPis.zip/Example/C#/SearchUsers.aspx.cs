﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SearchUsers : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {

        AddressBook.AddressBookClient services = new AddressBook.AddressBookClient();
        AddressBook.SearchUsersRequest request = new AddressBook.SearchUsersRequest();
       
        //if (this.Session["UserName"] != null && this.Session["AuthenticationToken"] != null)
        //{
        //    request.UserName = this.Session["UserName"].ToString();
        //    request.AuthenticationToken = this.Session["AuthenticationToken"].ToString();
        //}

        request.UserName = this.txt_username.Text;
        request.CodeAdm = this.txt_codAmm.Text;
        request.CodeRoleLogin = this.txt_codice_ruolo.Text;

        request.Filters = new AddressBook.Filter[4];

        int indice = 0;

        if (!string.IsNullOrEmpty(txtCodFisc.Text))
        {
            AddressBook.Filter filter = new AddressBook.Filter();
            filter.Name = "NATIONAL_IDENTIFICATION_NUMBER";
            filter.Value = txtCodFisc.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }
        if (!string.IsNullOrEmpty(txtMail.Text))
        {
            AddressBook.Filter filter = new AddressBook.Filter();
            filter.Name = "USER_MAIL";
            filter.Value = txtMail.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }
        if (!string.IsNullOrEmpty(txtNome.Text))
        {
            AddressBook.Filter filter = new AddressBook.Filter();
            filter.Name = "USER_NAME";
            filter.Value = txtNome.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }
        if (!string.IsNullOrEmpty(txtCognome.Text))
        {
            AddressBook.Filter filter = new AddressBook.Filter();
            filter.Name = "USER_SURNAME";
            filter.Value = txtCognome.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        this.txtRequest.Text = this.SerializeAsXml(request);
        AddressBook.SearchUsersResponse response = services.SearchUsers(request);

        this.txtResponse.Text = this.SerializeAsXml(response);

        if (response.Success)
        {
            AddressBook.User[] result = response.Users;
            this.txtCodiceErrore.Text = string.Empty;
            this.txtDescrizioneErrore.Text = string.Empty;
        }
        else
        {
            this.txtCodiceErrore.Text = response.Error.Code;
            this.txtDescrizioneErrore.Text = response.Error.Description;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
    private string SerializeAsXml(object data)
    {
        System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(data.GetType());

        using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
        {
            serializer.Serialize(ms, data);
            ms.Position = 0;

            byte[] buffer = new byte[ms.Length];
            ms.Read(buffer, 0, buffer.Length);

            return System.Text.UnicodeEncoding.Default.GetString(buffer);
        }

    }
}