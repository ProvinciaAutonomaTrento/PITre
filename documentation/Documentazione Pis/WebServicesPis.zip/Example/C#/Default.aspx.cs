﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        Response.Redirect("LoginPage.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Response.Redirect("LogOut.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnChangePassword_Click(object sender, EventArgs e)
    {
        Response.Redirect("ChangePassword.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSearchUsers_Click(object sender, EventArgs e)
    {
        Response.Redirect("SearchUsers.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGetRole_Click(object sender, EventArgs e)
    {
        Response.Redirect("GetRole.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGetRoles_Click(object sender, EventArgs e)
    {
        Response.Redirect("GetRoles.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGetUsersInRole_Click(object sender, EventArgs e)
    {
        Response.Redirect("GetUsersInRole.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGetRegistersOrRF_Click(object sender, EventArgs e)
    {
        Response.Redirect("GetRegistersOrRF.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGetRegiterOrRF_Click(object sender, EventArgs e)
    {
        Response.Redirect("GetRegisterOrRF.aspx");
    }


    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGetActiveClassificationScheme_Click(object sender, EventArgs e)
    {
        Response.Redirect("GetActiveClassificationScheme.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGetAllClassificationSchemes_Click(object sender, EventArgs e)
    {
        Response.Redirect("GetAllClassificationSchemes.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGetClassificationSchemeById_Click(object sender, EventArgs e)
    {
        Response.Redirect("GetClassificationSchemeById.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnAddDocInProject_Click(object sender, EventArgs e)
    {
        Response.Redirect("AddDocInProject.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGetTemplateDoc_Click(object sender, EventArgs e)
    {
        Response.Redirect("GetTemplateDoc.aspx");
    }

        /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGetTemplatesDocuments_Click(object sender, EventArgs e)
    {
        Response.Redirect("GetTemplatesDocuments.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGetDocument_Click(object sender, EventArgs e)
    {
        Response.Redirect("GetDocument.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGetDocumentStateDiagram_Click(object sender, EventArgs e)
    {
        Response.Redirect("GetDocumentStateDiagram.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSendDocument_Click(object sender, EventArgs e)
    {
        Response.Redirect("SendDocument.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnEditDocStateDiagram_Click(object sender, EventArgs e)
    {
        Response.Redirect("EditDocStateDiagram.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGetFileDocumentById_Click(object sender, EventArgs e)
    {
        Response.Redirect("GetFileDocumentById.aspx");
    }

     /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnUploadFileToDocument_Click(object sender, EventArgs e)
    {
        Response.Redirect("UploadFileToDocument.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGetDocumentsInProject_Click(object sender, EventArgs e)
    {
        Response.Redirect("GetDocumentsInProject.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSearchDocuments_Click(object sender, EventArgs e)
    {
        Response.Redirect("SearchDocuments.aspx");
    }


    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnCreateDocument_Click(object sender, EventArgs e)
    {
        Response.Redirect("CreateDocument.aspx");
    }
    
        /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGetFileWithSignatureOrStamp_Click(object sender, EventArgs e)
    {
        Response.Redirect("GetFileWithSignatureOrStamp.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnEditDocument_Click(object sender, EventArgs e)
    {
        Response.Redirect("EditDocument.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGetTemplatesProjects_Click(object sender, EventArgs e)
    {
        Response.Redirect("GetTemplatesProjects.aspx");
    }


    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGetTemplatePrj_Click(object sender, EventArgs e)
    {
        Response.Redirect("GetTemplatePrj.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGetProjectStateDiagram_Click(object sender, EventArgs e)
    {
        Response.Redirect("GetProjectStateDiagram.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnEditPrjStateDiagram_Click(object sender, EventArgs e)
    {
        Response.Redirect("EditPrjStateDiagram.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnOpenCloseProject_Click(object sender, EventArgs e)
    {
        Response.Redirect("OpenCloseProject.aspx");
    }


    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGetProject_Click(object sender, EventArgs e)
    {
        Response.Redirect("GetProject.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSearchtProject_Click(object sender, EventArgs e)
    {
        Response.Redirect("SearchProjects.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGetProjectsByDocument_Click(object sender, EventArgs e)
    {
        Response.Redirect("GetProjectsByDocument.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnCreateProject_Click(object sender, EventArgs e)
    {
        Response.Redirect("CreateProject.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnEditProject_Click(object sender, EventArgs e)
    {
        Response.Redirect("EditProject.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGetCorrespondent_Click(object sender, EventArgs e)
    {
        Response.Redirect("GetCorrespondent.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnAddCorrespondent_Click(object sender, EventArgs e)
    {
        Response.Redirect("AddCorrespondent.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnDeleteCorrespondent_Click(object sender, EventArgs e)
    {
        Response.Redirect("DeleteCorrespondent.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnEditCorrespondent_Click(object sender, EventArgs e)
    {
        Response.Redirect("EditCorrespondent.aspx");
    }

        /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSearchCorrespondents_Click(object sender, EventArgs e)
    {
        Response.Redirect("SearchCorrespondents.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnExecuteTransmDocModel_Click(object sender, EventArgs e)
    {
        Response.Redirect("ExecuteTransmDocModel.aspx");
    }


    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGetTransmissionsModels_Click(object sender, EventArgs e)
    {
        Response.Redirect("GetTransmissionsModels.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGetTransmissionModel_Click(object sender, EventArgs e)
    {
        Response.Redirect("GetTransmissionModel.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnExecuteTransmPrjModel_Click(object sender, EventArgs e)
    {
        Response.Redirect("ExecuteTransmPrjModel.aspx");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGetStampAndSignature_Click(object sender, EventArgs e)
    {
        Response.Redirect("GetStampAndSignature.aspx");
    }
    
    
    
    
}