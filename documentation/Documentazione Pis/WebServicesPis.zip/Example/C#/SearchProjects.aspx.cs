﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;

public partial class SearchProjects : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            Projects.ProjectsClient services = new Projects.ProjectsClient();
            Projects.GetTemplatesProjectsRequest request = new Projects.GetTemplatesProjectsRequest();

            //if (this.Session["UserName"] != null && this.Session["AuthenticationToken"] != null)
            //{
            //    request.UserName = this.Session["UserName"].ToString();
            //    request.AuthenticationToken = this.Session["AuthenticationToken"].ToString();
            //}

            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["username"]) && !string.IsNullOrEmpty(ConfigurationManager.AppSettings["amministrazione"]))
            {
                request.UserName = ConfigurationManager.AppSettings["username"].ToString();
                request.CodeAdm = ConfigurationManager.AppSettings["amministrazione"].ToString();
            }

            Projects.GetTemplatesProjectsResponse response = services.GetTemplatesProjects(request);

            if (response.Success)
            {
                this.cboProfili.DataSource = response.Templates;
                this.cboProfili.DataBind();
                this.cboProfili.Items.Insert(0, "");
            }
        }
    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }

    protected void btnSearchProjects_Click(object sender, EventArgs e)
    {
        Projects.ProjectsClient services = new Projects.ProjectsClient();
        Projects.SearchProjectsRequest request = new Projects.SearchProjectsRequest();

        //if (this.Session["UserName"] != null && this.Session["AuthenticationToken"] != null)
        //{
        //    request.UserName = this.Session["UserName"].ToString();
        //    request.AuthenticationToken = this.Session["AuthenticationToken"].ToString();
        //}

        request.UserName = this.txt_username.Text;
        request.CodeAdm = this.txt_codAmm.Text;
        request.CodeRoleLogin = this.txt_codice_ruolo.Text;

        request.Filters = new Projects.Filter[15];

        int indice = 0;

        Projects.Filter filter = new Projects.Filter();

        if (!string.IsNullOrEmpty(this.txtAnno.Text))
        {
            filter.Name = "YEAR";
            filter.Value = this.txtAnno.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(this.txt_data_creazione_dal.Text))
        {
            filter = new Projects.Filter();
            filter.Name = "CREATION_DATE_FROM";
            filter.Value = this.txt_data_creazione_dal.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(this.txt_data_creazione_al.Text))
        {
            filter = new Projects.Filter();
            filter.Name = "CREATION_DATE_TO";
            filter.Value = this.txt_data_creazione_al.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(this.txt_data_chiusura_dal.Text))
        {
            filter = new Projects.Filter();
            filter.Name = "CLOSING_DATE_FROM";
            filter.Value = this.txt_data_chiusura_dal.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(this.txt_data_chiusura_al.Text))
        {
            filter = new Projects.Filter();
            filter.Name = "CLOSING_DATE_TO";
            filter.Value = this.txt_data_chiusura_al.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(this.txt_data_apertura_dal.Text))
        {
            filter = new Projects.Filter();
            filter.Name = "OPENING_DATE_FROM";
            filter.Value = this.txt_data_apertura_dal.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(this.txt_data_apertura_al.Text))
        {
            filter = new Projects.Filter();
            filter.Name = "OPENING_DATE_TO";
            filter.Value = this.txt_data_apertura_al.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(rbl_stato.SelectedValue))
        {
            filter = new Projects.Filter();
            filter.Name = "STATE";
            filter.Value = this.rbl_stato.SelectedValue;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(rbl_tipo.SelectedValue))
        {
            filter = new Projects.Filter();
            filter.Name = "TYPE_PROJECT";
            filter.Value = this.rbl_tipo.SelectedValue;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(this.txt_numero.Text))
        {
            filter = new Projects.Filter();
            filter.Name = "PROJECT_NUMBER";
            filter.Value = this.txt_numero.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(this.txt_descrizione.Text))
        {
            filter = new Projects.Filter();
            filter.Name = "PROJECT_DESCRIPTION";
            filter.Value = txt_descrizione.Text;
            request.Filters.SetValue(filter, indice);
            indice++; 
        }

        if (!string.IsNullOrEmpty(this.txt_class.Text))
        {
            filter = new Projects.Filter();
            filter.Name = "CLASSIFICATION_CODE";
            filter.Value = txt_class.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(this.txt_titolario.Text))
        {
            filter = new Projects.Filter();
            filter.Name = "CLASSIFICATION_SCHEME";
            filter.Value = this.txt_titolario.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(this.txt_registro.Text))
        {
            filter = new Projects.Filter();
            filter.Name = "REGISTER";
            filter.Value = this.txt_registro.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(cboProfili.SelectedValue))
        {
            filter = new Projects.Filter();

            Projects.Template template = new Projects.Template();
            template.Id = cboProfili.SelectedValue;
            template.Name = cboProfili.SelectedItem.Text;

            List<Projects.Field> campiProfilo = new List<Projects.Field>();

            foreach (DataGridItem itm in this.grdDatiProfilati.Items)
            {
                if (itm.ItemType != ListItemType.Header)
                {
                    campiProfilo.Add(new Projects.Field
                    {
                        Name = ((Label)itm.FindControl("lblNomeCampo")).Text,
                        Required = ((CheckBox)itm.FindControl("chkObbligatorio")).Checked,
                        Value = ((TextBox)itm.FindControl("txtValoreCampo")).Text,
                        CodeRegisterOrRF = ((TextBox)itm.FindControl("txtValoreCampo")).Text
                    });
                }
            }

            filter.Template = template;
            filter.Template.Fields = campiProfilo.ToArray();
            filter.Name = "TEMPLATE";
            filter.Value = template.Id;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        request.PageNumber = this.txtNumPage.Text;
        request.ElementsInPage = this.txtElemPage.Text;

        this.txtRequest.Text = this.SerializeAsXml(request);
        Projects.SearchProjectsResponse response = services.SearchProjects(request);

        this.txtResponse.Text = this.SerializeAsXml(response);

        if (response.Success)
        {
            Projects.Project[] result = response.Projects;
            this.txtCodiceErrore.Text = string.Empty;
            this.txtDescrizioneErrore.Text = string.Empty;
        }
        else
        {
            this.txtCodiceErrore.Text = response.Error.Code;
            this.txtDescrizioneErrore.Text = response.Error.Description;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void cboProfili_OnSelectedIndexChanged(object sender, EventArgs e)
    {
        Projects.ProjectsClient services = new Projects.ProjectsClient();
        Projects.GetTemplatePrjRequest request = new Projects.GetTemplatePrjRequest();

        //if (this.Session["UserName"] != null && this.Session["AuthenticationToken"] != null)
        //{
        //    request.UserName = this.Session["UserName"].ToString();
        //    request.AuthenticationToken = this.Session["AuthenticationToken"].ToString();
        //}

        if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["username"]) && !string.IsNullOrEmpty(ConfigurationManager.AppSettings["amministrazione"]))
        {
            request.UserName = ConfigurationManager.AppSettings["username"].ToString();
            request.CodeAdm = ConfigurationManager.AppSettings["amministrazione"].ToString();
        }

        request.IdTemplate = this.cboProfili.SelectedValue;
        Projects.Project docRequest = new Projects.Project();

        Projects.GetTemplatePrjResponse response = services.GetTemplatePrj(request);

        if (response.Success)
        {
            this.grdDatiProfilati.DataSource = response.Template.Fields;
            this.grdDatiProfilati.DataBind();
        }
        else
        {
            this.grdDatiProfilati.DataSource = null;
            this.grdDatiProfilati.DataBind();
        }

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
    private string SerializeAsXml(object data)
    {
        System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(data.GetType());

        using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
        {
            serializer.Serialize(ms, data);
            ms.Position = 0;

            byte[] buffer = new byte[ms.Length];
            ms.Read(buffer, 0, buffer.Length);

            return System.Text.UnicodeEncoding.Default.GetString(buffer);
        }

    }
}