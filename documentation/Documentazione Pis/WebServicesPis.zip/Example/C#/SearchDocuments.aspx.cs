﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;

public partial class SearchDocuments : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            Documents.DocumentsClient services = new Documents.DocumentsClient();
            Documents.GetTemplatesDocumentsRequest request = new Documents.GetTemplatesDocumentsRequest();

            //if (this.Session["UserName"] != null && this.Session["AuthenticationToken"] != null)
            //{
            //    request.UserName = this.Session["UserName"].ToString();
            //    request.AuthenticationToken = this.Session["AuthenticationToken"].ToString();
            //}

            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["username"]) && !string.IsNullOrEmpty(ConfigurationManager.AppSettings["amministrazione"]))
            {
                request.UserName = ConfigurationManager.AppSettings["username"].ToString();
                request.CodeAdm = ConfigurationManager.AppSettings["amministrazione"].ToString();
            }

            Documents.GetTemplatesDocumentsResponse response = services.GetTemplatesDocuments(request);

            if (response.Success)
            {
                this.cboProfili.DataSource = response.Templates;
                this.cboProfili.DataBind();
                this.cboProfili.Items.Insert(0, "");
            }
        }
    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }

    protected void btnSearchDocuments_Click(object sender, EventArgs e)
    {
        Documents.DocumentsClient services = new Documents.DocumentsClient();
        Documents.SearchDocumentsRequest request = new Documents.SearchDocumentsRequest();

        //if (this.Session["UserName"] != null && this.Session["AuthenticationToken"] != null)
        //{
        //    request.UserName = this.Session["UserName"].ToString();
        //    request.AuthenticationToken = this.Session["AuthenticationToken"].ToString();
        //}

        request.UserName = this.txt_username.Text;
        request.CodeAdm = this.txt_codAmm.Text;
        request.CodeRoleLogin = this.txt_codice_ruolo.Text;

        request.Filters = new Documents.Filter[10];

        int indice = 0;

        Documents.Filter filter = new Documents.Filter();

        if (!string.IsNullOrEmpty(this.txtAnno.Text))
        {
            filter.Name = "YEAR";
            filter.Value = this.txtAnno.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        filter = new Documents.Filter();
        filter.Name = "IN_PROTOCOL";
        filter.Value = this.chkArr.Checked.ToString();
        request.Filters.SetValue(filter, indice);
        indice++;

        filter = new Documents.Filter();
        filter.Name = "OUT_PROTOCOL";
        filter.Value = this.chkPar.Checked.ToString();
        request.Filters.SetValue(filter, indice);
        indice++;

        filter = new Documents.Filter();
        filter.Name = "INTERNAL_PROTOCOL";
        filter.Value = this.chkInt.Checked.ToString();
        request.Filters.SetValue(filter, indice);
        indice++;

        filter = new Documents.Filter();
        filter.Name = "NOT_PROTOCOL";
        filter.Value = this.chkGrigio.Checked.ToString();
        request.Filters.SetValue(filter, indice);
        indice++;

        filter = new Documents.Filter();
        filter.Name = "PREDISPOSED";
        filter.Value = this.chkPre.Checked.ToString();
        request.Filters.SetValue(filter, indice);
        indice++;

        filter = new Documents.Filter();
        filter.Name = "ATTACHMENTS";
        filter.Value = this.chkAll.Checked.ToString();
        request.Filters.SetValue(filter, indice);
        indice++;

        filter = new Documents.Filter();
        filter.Name = "PRINTS";
        filter.Value = this.chkAll.Checked.ToString();
        request.Filters.SetValue(filter, indice);
        indice++;

        if (!string.IsNullOrEmpty(txt_num_proto_dal.Text))
        {
            filter = new Documents.Filter();
            filter.Name = "NUM_PROTOCOL_FROM";
            filter.Value = txt_num_proto_dal.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(txt_num_proto_al.Text))
        {
            filter = new Documents.Filter();
            filter.Name = "NUM_PROTOCOL_TO";
            filter.Value = txt_num_proto_al.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(txt_data_creazione_dal.Text))
        {
            filter = new Documents.Filter();
            filter.Name = "CREATION_DATE_FROM";
            filter.Value = txt_data_creazione_dal.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(txt_data_creazione_al.Text))
        {
            filter = new Documents.Filter();
            filter.Name = "CREATION_DATE_TO";
            filter.Value = txt_data_creazione_al.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(txt_mitt_dest.Text))
        {
            filter = new Documents.Filter();
            filter.Name = "SENDER_RECIPIENT";
            filter.Value = txt_mitt_dest.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(txt_doc_dal.Text))
        {
            filter = new Documents.Filter();
            filter.Name = "DOCNUMBER_FROM";
            filter.Value = txt_doc_dal.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(txt_doc_al.Text))
        {
            filter = new Documents.Filter();
            filter.Name = "DOCNUMBER_TO";
            filter.Value = txt_doc_al.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(txt_registro.Text))
        {
            filter = new Documents.Filter();
            filter.Name = "REGISTER";
            filter.Value = txt_registro.Text;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        if (!string.IsNullOrEmpty(cboProfili.SelectedValue))
        {
            filter = new Documents.Filter();

            Documents.Template template = new Documents.Template();
            template.Id = cboProfili.SelectedValue;
            template.Name = cboProfili.SelectedItem.Text;

            List<Documents.Field> campiProfilo = new List<Documents.Field>();

            foreach (DataGridItem itm in this.grdDatiProfilati.Items)
            {
                if (itm.ItemType != ListItemType.Header)
                {
                    campiProfilo.Add(new Documents.Field
                    {
                        Name = ((Label)itm.FindControl("lblNomeCampo")).Text,
                        Required = ((CheckBox)itm.FindControl("chkObbligatorio")).Checked,
                        Value = ((TextBox)itm.FindControl("txtValoreCampo")).Text,
                        CodeRegisterOrRF = ((TextBox)itm.FindControl("txtValoreCampo")).Text
                    });
                }
            }

            filter.Template = template;
            filter.Template.Fields = campiProfilo.ToArray();
            filter.Name = "TEMPLATE";
            filter.Value = template.Id;
            request.Filters.SetValue(filter, indice);
            indice++;
        }

        request.PageNumber = this.txtNumPage.Text;
        request.ElementsInPage = this.txtElemPage.Text;

        this.txtRequest.Text = this.SerializeAsXml(request);
        Documents.SearchDocumentsResponse response = services.SearchDocuments(request);

        this.txtResponse.Text = this.SerializeAsXml(response);

        if (response.Success)
        {
            Documents.Document[] result = response.Documents;
            this.txtCodiceErrore.Text = string.Empty;
            this.txtDescrizioneErrore.Text = string.Empty;
        }
        else
        {
            this.txtCodiceErrore.Text = response.Error.Code;
            this.txtDescrizioneErrore.Text = response.Error.Description;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void cboProfili_OnSelectedIndexChanged(object sender, EventArgs e)
    {
        Documents.DocumentsClient services = new Documents.DocumentsClient();
        Documents.GetTemplateDocRequest request = new Documents.GetTemplateDocRequest();

        //if (this.Session["UserName"] != null && this.Session["AuthenticationToken"] != null)
        //{
        //    request.UserName = this.Session["UserName"].ToString();
        //    request.AuthenticationToken = this.Session["AuthenticationToken"].ToString();
        //}

        if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["username"]) && !string.IsNullOrEmpty(ConfigurationManager.AppSettings["amministrazione"]))
        {
            request.UserName = ConfigurationManager.AppSettings["username"].ToString();
            request.CodeAdm = ConfigurationManager.AppSettings["amministrazione"].ToString();
        }

        request.IdTemplate = this.cboProfili.SelectedValue;
        Documents.Document docRequest = new Documents.Document();

        Documents.GetTemplateDocResponse response = services.GetTemplateDoc(request);

        if (response.Success)
        {
            this.grdDatiProfilati.DataSource = response.Template.Fields;
            this.grdDatiProfilati.DataBind();
        }
        else
        {
            this.grdDatiProfilati.DataSource = null;
            this.grdDatiProfilati.DataBind();
        }

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
    private string SerializeAsXml(object data)
    {
        System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(data.GetType());

        using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
        {
            serializer.Serialize(ms, data);
            ms.Position = 0;

            byte[] buffer = new byte[ms.Length];
            ms.Read(buffer, 0, buffer.Length);

            return System.Text.UnicodeEncoding.Default.GetString(buffer);
        }

    }
}