﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddCorrespondent : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }

    protected void btnAddCorrespondent_Click(object sender, EventArgs e)
    {
        AddressBook.AddressBookClient services = new AddressBook.AddressBookClient();
        AddressBook.AddCorrespondentRequest request = new AddressBook.AddCorrespondentRequest();

        //if (this.Session["UserName"] != null && this.Session["AuthenticationToken"] != null)
        //{
        //    request.UserName = this.Session["UserName"].ToString();
        //    request.AuthenticationToken = this.Session["AuthenticationToken"].ToString();
        //}

        request.UserName = this.txt_username.Text;
        request.CodeAdm = this.txt_codAmm.Text;
        request.CodeRoleLogin = this.txt_codice_ruolo.Text;

        //Popolo corrispondente
        request.Correspondent = new AddressBook.Correspondent();

        request.Correspondent.Address = this.txt_indirizzo.Text;
        request.Correspondent.AdmCode = this.txt_codAmm.Text;
        request.Correspondent.AOOCode = this.text_cod_aoo.Text;
        request.Correspondent.Cap = this.txt_cap.Text;
        request.Correspondent.City = this.txt_citta.Text;
        request.Correspondent.Code = this.txt_codice.Text;
        request.Correspondent.CodeRegisterOrRF = this.txt_registro.Text;
        request.Correspondent.CorrespondentType = this.ddl_tipo.SelectedValue;
        request.Correspondent.Description = this.txt_descrizione.Text;
        request.Correspondent.Email = this.txt_mail.Text;
        request.Correspondent.Fax = this.txt_fax.Text;
        request.Correspondent.Location = this.txt_localita.Text;
        request.Correspondent.Nation = this.txt_nazione.Text;
        request.Correspondent.NationalIdentificationNumber = this.text_codice_fiscale.Text;
        request.Correspondent.Note = this.txt_note.Text;
        request.Correspondent.PhoneNumber = this.txt_telefono.Text;
        request.Correspondent.PreferredChannel = this.ddl_canale.SelectedValue;
        request.Correspondent.Province = this.txt_provincia.Text;
        request.Correspondent.Type = this.ddl_tipo.SelectedValue;


        this.txtRequest.Text = this.SerializeAsXml(request);

        AddressBook.AddCorrespondentResponse response = services.AddCorrespondent(request);

        this.txtResponse.Text = this.SerializeAsXml(response);

        if (response.Success)
        {
            AddressBook.Correspondent result = response.Correspondent;
            this.txtCodiceErrore.Text = string.Empty;
            this.txtDescrizioneErrore.Text = string.Empty;
        }
        else
        {
            this.txtCodiceErrore.Text = response.Error.Code;
            this.txtDescrizioneErrore.Text = response.Error.Description;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
    private string SerializeAsXml(object data)
    {
        System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(data.GetType());

        using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
        {
            serializer.Serialize(ms, data);
            ms.Position = 0;

            byte[] buffer = new byte[ms.Length];
            ms.Read(buffer, 0, buffer.Length);

            return System.Text.UnicodeEncoding.Default.GetString(buffer);
        }

    }
}