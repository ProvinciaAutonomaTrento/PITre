﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;

public partial class CreateDocument : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            Documents.DocumentsClient services = new Documents.DocumentsClient();
            Documents.GetTemplatesDocumentsRequest request = new Documents.GetTemplatesDocumentsRequest();

            //if (this.Session["UserName"] != null && this.Session["AuthenticationToken"] != null)
            //{
            //    request.UserName = this.Session["UserName"].ToString();
            //    request.AuthenticationToken = this.Session["AuthenticationToken"].ToString();
            //}

          
            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["username"]) && !string.IsNullOrEmpty(ConfigurationManager.AppSettings["amministrazione"]))
            {
                request.UserName = ConfigurationManager.AppSettings["username"].ToString();
                request.CodeAdm = ConfigurationManager.AppSettings["amministrazione"].ToString();
            }


            Documents.GetTemplatesDocumentsResponse response = services.GetTemplatesDocuments(request);

            if (response.Success)
            {
                this.cboProfili.DataSource = response.Templates;
                this.cboProfili.DataBind();
                this.cboProfili.Items.Insert(0, "");
            }
        }

    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }

    protected void btnCreateDocument_Click(object sender, EventArgs e)
    {
        Documents.DocumentsClient services = new Documents.DocumentsClient();
        Documents.CreateDocumentRequest request = new Documents.CreateDocumentRequest();

        //if (this.Session["UserName"] != null && this.Session["AuthenticationToken"] != null)
        //{
        //    request.UserName = this.Session["UserName"].ToString();
        //    request.AuthenticationToken = this.Session["AuthenticationToken"].ToString();
        //}



        Documents.Document docRequest = new Documents.Document();
        docRequest.Object = txtOggetto.Text;
        docRequest.PrivateDocument = chkPrivato.Checked;
        if (!string.IsNullOrEmpty(txtNota.Text))
        {
            docRequest.Note = new Documents.Note[1];
            docRequest.Note[0] = new Documents.Note();
            docRequest.Note[0].Description = this.txtNota.Text;
        }
        docRequest.DocumentType = rbl_radio.SelectedItem.Value;
       
        if (this.rbl_radio.SelectedValue.Equals("G"))
        {

        }
        else
        {
            if (!string.IsNullOrEmpty(this.txtDescrizioneMitt.Text))
            {
                docRequest.Predisposed = chkPre.Checked;
                docRequest.Sender = new Documents.Correspondent();
                docRequest.Sender.Description = this.txtDescrizioneMitt.Text;
                docRequest.Sender.CorrespondentType = "O";

                if (!string.IsNullOrEmpty(txt_codReg.Text))
                {
                    request.CodeRegister = this.txt_codReg.Text;
                }

                if (!string.IsNullOrEmpty(txt_rf.Text))
                {
                    request.CodeRF = this.txt_rf.Text;
                }

                if (this.rbl_radio.SelectedValue.Equals("A"))
                {
                    if (!string.IsNullOrEmpty(this.txtDescrizioneMittMultiplo.Text))
                    {
                        docRequest.MultipleSenders = new Documents.Correspondent[1];
                        docRequest.MultipleSenders[0] = new Documents.Correspondent();
                        docRequest.MultipleSenders[0].Description = this.txtDescrizioneMittMultiplo.Text;
                        docRequest.MultipleSenders[0].CorrespondentType = "O";
                    }

                    if (!string.IsNullOrEmpty(this.txt_mezzo.Text))
                    {
                        docRequest.MeansOfSending = this.txt_mezzo.Text;
                    }

                    if (!string.IsNullOrEmpty(this.txtProtocolloMittente.Text))
                    {
                        docRequest.ProtocolSender = this.txtProtocolloMittente.Text;
                    }

                    if (!string.IsNullOrEmpty(this.txtDataProtMittente.Text))
                    {
                        docRequest.DataProtocolSender = this.txtDataProtMittente.Text;
                    }
                }
                if (this.rbl_radio.SelectedValue.Equals("P") || this.rbl_radio.SelectedValue.Equals("I"))
                {
                    if (!string.IsNullOrEmpty(this.txt_dest.Text))
                    {
                        docRequest.Recipients = new Documents.Correspondent[1];
                        docRequest.Recipients[0] = new Documents.Correspondent();
                        docRequest.Recipients[0].Description = this.txt_dest.Text;
                        docRequest.Recipients[0].Id = this.txt_dest.Text;
                    }

                    if (!string.IsNullOrEmpty(this.txt_dest_cc.Text))
                    {
                        docRequest.RecipientsCC = new Documents.Correspondent[1];
                        docRequest.RecipientsCC[0] = new Documents.Correspondent();
                        docRequest.RecipientsCC[0].Description = this.txt_dest_cc.Text;
                        docRequest.RecipientsCC[0].Id = this.txt_dest_cc.Text;
                    }
                }
            }
        }

        request.Document = docRequest;

        request.UserName = this.txt_username.Text;
        request.CodeAdm = this.txt_codAmm.Text;
        request.CodeRoleLogin = this.txt_codice_ruolo.Text;

        if (!string.IsNullOrEmpty(cboProfili.SelectedValue))
        {
            Documents.Template template = new Documents.Template();
            template.Id = cboProfili.SelectedValue;
            template.Name = cboProfili.SelectedItem.Text;

            List<Documents.Field> campiProfilo = new List<Documents.Field>();

            foreach (DataGridItem itm in this.grdDatiProfilati.Items)
            {
                if (itm.ItemType != ListItemType.Header)
                {
                    campiProfilo.Add(new Documents.Field
                    {
                        Name = ((Label)itm.FindControl("lblNomeCampo")).Text,
                        Required = ((CheckBox)itm.FindControl("chkObbligatorio")).Checked,
                        Value = ((TextBox)itm.FindControl("txtValoreCampo")).Text,
                        CodeRegisterOrRF = ((TextBox)itm.FindControl("txtValoreCampo")).Text
                    });
                }
            }
            request.Document.Template = template;
            request.Document.Template.Fields = campiProfilo.ToArray();
        }

        if (this.uploadFile != null && uploadFile.PostedFile != null && uploadFile.PostedFile.InputStream != null && this.uploadFile.PostedFile.InputStream.Length > 0)
        {
            byte[] content = new byte[this.uploadFile.PostedFile.InputStream.Length];
            this.uploadFile.PostedFile.InputStream.Read(content, 0, content.Length);

            request.Document.MainDocument = new Documents.File();

            request.Document.MainDocument.Content = content;
            request.Document.MainDocument.Name = this.uploadFile.PostedFile.FileName;
            request.Document.MainDocument.MimeType = this.uploadFile.PostedFile.ContentType;
        }

        this.txtRequest.Text = this.SerializeAsXml(request);

        Documents.CreateDocumentResponse response = services.CreateDocument(request);

        this.txtResponse.Text = this.SerializeAsXml(response);

        if (response.Success)
        {
            Documents.Document result = response.Document;
            this.txtCodiceErrore.Text = string.Empty;
            this.txtDescrizioneErrore.Text = string.Empty;
        }
        else
        {
            this.txtCodiceErrore.Text = response.Error.Code;
            this.txtDescrizioneErrore.Text = response.Error.Description;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void cboProfili_OnSelectedIndexChanged(object sender, EventArgs e)
    {
        Documents.DocumentsClient services = new Documents.DocumentsClient();
        Documents.GetTemplateDocRequest request = new Documents.GetTemplateDocRequest();

        //if (this.Session["UserName"] != null && this.Session["AuthenticationToken"] != null)
        //{
        //    request.UserName = this.Session["UserName"].ToString();
        //    request.AuthenticationToken = this.Session["AuthenticationToken"].ToString();
        //}

        if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["username"]) && !string.IsNullOrEmpty(ConfigurationManager.AppSettings["amministrazione"]))
        {
            request.UserName = ConfigurationManager.AppSettings["username"].ToString();
            request.CodeAdm = ConfigurationManager.AppSettings["amministrazione"].ToString();
        }

        request.IdTemplate = this.cboProfili.SelectedValue;
        Documents.Document docRequest = new Documents.Document();

        Documents.GetTemplateDocResponse response = services.GetTemplateDoc(request);

        if (response.Success)
        {
            this.grdDatiProfilati.DataSource = response.Template.Fields;
            this.grdDatiProfilati.DataBind();
        }

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void rbl_radio_OnSelectedIndexChanged(object sender, EventArgs e)
    {
        if (!string.IsNullOrEmpty(rbl_radio.SelectedValue))
        {
            if (this.rbl_radio.SelectedValue.Equals("G"))
            {
                this.pnl_predisposto.Visible = false;
                this.pnl_mittente.Visible = false;
                this.pnl_registor.Visible = false;
                this.pnl_rf.Visible = false;
            }
            else
            {
                this.pnl_predisposto.Visible = true;
                this.pnl_mittente.Visible = true;
                this.pnl_registor.Visible = true;
                this.pnl_rf.Visible = true;
            }

            if (this.rbl_radio.SelectedValue.Equals("A"))
            {
                this.pnl_multipli.Visible = true;
                this.pnl_protMitt.Visible = true;
                this.pnl_mezzo_spe.Visible = true;
                this.pnl_data_prot.Visible = true;
            }
            else
            {
                this.pnl_multipli.Visible = false;
                this.pnl_protMitt.Visible = false;
                this.pnl_mezzo_spe.Visible = false;
                this.pnl_data_prot.Visible = false;
            }

            if (this.rbl_radio.SelectedValue.Equals("P") || this.rbl_radio.SelectedValue.Equals("I"))
            {
                this.pnl_destinatari.Visible = true;
                this.pnl_destinatari_cc.Visible = true;
            }
            else
            {
                this.pnl_destinatari.Visible = false;
                this.pnl_destinatari_cc.Visible = false;
            }
        }

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
    private string SerializeAsXml(object data)
    {
        System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(data.GetType());

        using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
        {
            serializer.Serialize(ms, data);
            ms.Position = 0;

            byte[] buffer = new byte[ms.Length];
            ms.Read(buffer, 0, buffer.Length);

            return System.Text.UnicodeEncoding.Default.GetString(buffer);
        }

    }
}